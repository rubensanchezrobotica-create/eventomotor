module.exports=[79713,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_evento_%5Bslug%5D_page_actions_07o1wpx.js.map