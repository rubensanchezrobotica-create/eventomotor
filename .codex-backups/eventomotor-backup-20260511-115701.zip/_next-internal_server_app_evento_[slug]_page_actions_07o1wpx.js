module.exports = [
"[project]/.next-internal/server/app/evento/[slug]/page/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_evento_%5Bslug%5D_page_actions_07o1wpx.js.map