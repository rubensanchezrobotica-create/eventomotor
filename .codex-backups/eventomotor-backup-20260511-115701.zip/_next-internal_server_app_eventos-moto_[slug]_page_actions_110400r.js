module.exports=[8599,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_eventos-moto_%5Bslug%5D_page_actions_110400r.js.map