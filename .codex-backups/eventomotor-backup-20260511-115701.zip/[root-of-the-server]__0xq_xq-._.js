module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/event-classification.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEHICLE_TYPE_LABELS",
    ()=>VEHICLE_TYPE_LABELS,
    "VEHICLE_TYPE_OPTIONS",
    ()=>VEHICLE_TYPE_OPTIONS,
    "getVehicleType",
    ()=>getVehicleType,
    "matchesVehicleFilter",
    ()=>matchesVehicleFilter
]);
const VEHICLE_TYPE_OPTIONS = [
    "moto",
    "coche",
    "mixto",
    "karting",
    "otros"
];
const VEHICLE_TYPE_LABELS = {
    moto: "Moto",
    coche: "Coche",
    mixto: "Mixto",
    karting: "Karting",
    otros: "Otros"
};
const MOTO_TERMS = [
    "fim",
    "fim world championship",
    "fim juniorgp",
    "fim europe",
    "fim enduro",
    "fim motocross",
    "fim trial",
    "fim supermoto",
    "fim minivelocidad",
    "fim moto",
    "rfme",
    "motogp",
    "superbike",
    "esbk",
    "motocross",
    "enduro",
    "trial",
    "supermoto",
    "minivelocidad",
    "mototurismo",
    "motociclismo",
    "moto",
    "moto-ocasion",
    "concentracionesdemotos",
    "concentracion motera",
    "concentracion de motos",
    "motos",
    "motera",
    "moteras",
    "motero",
    "moteros",
    "motoristas",
    "motoalmuerzo",
    "matinal motera",
    "ruta motera",
    "biker",
    "bikers",
    "motoclub",
    "harley",
    "vespa",
    "scooter",
    "custom",
    "tandas para motos",
    "worldsbk",
    "juniorgp"
];
const COCHE_TERMS = [
    "automovilismo",
    "gt winter series",
    "racing weekend",
    "rfeda",
    "rally",
    "rallye",
    "rallysprint",
    "drift",
    "tuning",
    "4x4",
    "coches",
    "turismos",
    "gt",
    "subida",
    "montana",
    "trackday coche",
    "todoterreno"
];
const KARTING_TERMS = [
    "karting",
    "kart"
];
const MIXTO_TERMS = [
    "coches y motos clasicos",
    "coches y motos",
    "vehiculos clasicos",
    "vehiculos clasicos y tuneados",
    "coches clasicos",
    "retro matinal clasicos",
    "concentracion de vehiculos"
];
function normalizeText(value) {
    return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function isVehicleType(value) {
    return Boolean(value && VEHICLE_TYPE_OPTIONS.includes(value));
}
function includesAny(text, terms) {
    return terms.some((term)=>{
        const normalizedTerm = normalizeText(term);
        if (/^[a-z0-9]+$/.test(normalizedTerm)) {
            return new RegExp(`(^|[^a-z0-9])${normalizedTerm}([^a-z0-9]|$)`).test(text);
        }
        return text.includes(normalizedTerm);
    });
}
function hasAll(text, terms) {
    return terms.every((term)=>text.includes(term));
}
function getVehicleType(event) {
    const explicitType = normalizeText(String(event.vehicleType || event.vehicle_type || "").trim());
    const titleText = normalizeText(String(event.title || ""));
    const tagsText = normalizeText(Array.isArray(event.tags) ? event.tags.join(" ") : "");
    const sourceText = normalizeText(String(event.source || ""));
    const searchableText = normalizeText([
        event.title,
        event.championship,
        event.discipline,
        event.source,
        tagsText
    ].filter(Boolean).join(" "));
    const isKarting = includesAny(searchableText, KARTING_TERMS);
    const isCanalDifusionMixed = sourceText.includes("canal difusion") && hasAll(tagsText, [
        "coches",
        "motos",
        "clasicos"
    ]);
    const isMixto = includesAny(`${titleText} ${tagsText}`, MIXTO_TERMS) || isCanalDifusionMixed;
    const isMoto = includesAny(searchableText, MOTO_TERMS);
    const isCoche = includesAny(searchableText, COCHE_TERMS);
    if (isVehicleType(explicitType)) {
        if (explicitType === "moto" && isCoche && !isMoto) return "coche";
        if (explicitType === "coche" && isMoto && !isCoche) return "moto";
        return explicitType;
    }
    if (isKarting) return "karting";
    if (isMixto) return "mixto";
    if (isCoche) return "coche";
    if (isMoto) return "moto";
    return "otros";
}
function matchesVehicleFilter(event, filter) {
    if (filter === "todos") {
        return true;
    }
    const vehicleType = getVehicleType(event);
    return vehicleType === filter || vehicleType === "mixto";
}
}),
"[project]/lib/slug.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-classification.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    const vehicleType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVehicleType"])({
        title: row.title,
        championship: row.championship || undefined,
        discipline: row.discipline || undefined,
        tags: row.tags || undefined,
        source: row.source || undefined,
        vehicle_type: row.vehicle_type
    });
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        vehicleType,
        vehicle_type: vehicleType,
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/app/api/admin/events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "PATCH",
    ()=>PATCH,
    "POST",
    ()=>POST,
    "PUT",
    ()=>PUT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-classification.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
;
const ADMIN_EVENT_SELECT = "id,slug,title,championship,discipline,start_date,end_date,venue,city,province,region,level,source,source_url,ticket_url,tags,vehicle_type,featured,visible,import_method,data_quality,notes";
const DATA_QUALITY_OPTIONS = [
    "needs_review",
    "draft",
    "reviewed",
    "published",
    "cancelled",
    "pending_date"
];
function jsonError(message, status) {
    return Response.json({
        ok: false,
        error: message
    }, {
        status
    });
}
function validateAdminSecret(request) {
    const adminSecret = process.env.ADMIN_SECRET;
    if (!adminSecret) {
        return {
            ok: false,
            status: 500,
            error: "ADMIN_SECRET is not configured. Add ADMIN_SECRET to your environment."
        };
    }
    if (request.headers.get("authorization") !== `Bearer ${adminSecret}`) {
        return {
            ok: false,
            status: 401,
            error: "Unauthorized. Send Authorization: Bearer ADMIN_SECRET."
        };
    }
    return {
        ok: true
    };
}
function createAdminClient() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        throw new Error("Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.");
    }
    return supabase;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function requireString(body, field) {
    const value = body[field];
    if (typeof value !== "string" || !value.trim()) {
        throw new Error(`${field} is required.`);
    }
    return value.trim();
}
function optionalString(body, field) {
    const value = body[field];
    return typeof value === "string" && value.trim() ? value.trim() : null;
}
function requireIsoDate(body, field) {
    const value = requireString(body, field);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        throw new Error(`${field} must use YYYY-MM-DD format.`);
    }
    return value;
}
function parseTags(value) {
    if (Array.isArray(value)) {
        return value.filter((tag)=>typeof tag === "string").map((tag)=>tag.trim()).filter(Boolean);
    }
    if (typeof value === "string") {
        return value.split(",").map((tag)=>tag.trim()).filter(Boolean);
    }
    return [];
}
function parseDataQuality(value) {
    if (typeof value === "string" && DATA_QUALITY_OPTIONS.includes(value)) {
        return value;
    }
    return "reviewed";
}
function parseVehicleType(value, fallbackEvent) {
    if (typeof value === "string" && __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["VEHICLE_TYPE_OPTIONS"].includes(value)) {
        return value;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVehicleType"])(fallbackEvent);
}
function parseAdminEventBody(value) {
    if (!isRecord(value)) {
        throw new Error("Request body must be an object.");
    }
    const id = requireString(value, "id");
    const title = requireString(value, "title");
    const discipline = optionalString(value, "discipline") || "";
    const startDate = requireIsoDate(value, "start");
    const endDate = requireIsoDate(value, "end");
    const venue = optionalString(value, "venue") || "";
    const city = optionalString(value, "city") || "";
    const province = optionalString(value, "province") || "";
    const sourceUrl = optionalString(value, "sourceUrl") || "";
    const tags = parseTags(value.tags);
    const vehicle_type = parseVehicleType(value.vehicleType || value.vehicle_type, {
        title,
        championship: optionalString(value, "championship") || title,
        discipline,
        tags,
        source: optionalString(value, "source") || "Admin"
    });
    return {
        id,
        slug: optionalString(value, "slug") || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(title, startDate),
        title,
        championship: optionalString(value, "championship") || title,
        discipline,
        start_date: startDate,
        end_date: endDate,
        venue,
        city,
        province,
        region: optionalString(value, "region") || province,
        level: optionalString(value, "level") || "Publicado",
        source: optionalString(value, "source") || "Admin",
        source_url: sourceUrl,
        ticket_url: optionalString(value, "ticketUrl") || "",
        tags,
        vehicle_type,
        featured: typeof value.featured === "boolean" ? value.featured : false,
        visible: typeof value.visible === "boolean" ? value.visible : true,
        import_method: optionalString(value, "importMethod"),
        data_quality: parseDataQuality(value.dataQuality),
        notes: optionalString(value, "notes"),
        updated_at: new Date().toISOString()
    };
}
async function GET(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").select(ADMIN_EVENT_SELECT).order("start_date", {
            ascending: true
        });
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            events: data || []
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 500);
    }
}
async function POST(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const payload = parseAdminEventBody(await request.json());
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").insert(payload).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        }, {
            status: 201
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 400);
    }
}
async function PUT(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const payload = parseAdminEventBody(await request.json());
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").update(payload).eq("id", payload.id).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 400);
    }
}
async function PATCH(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const body = await request.json();
        if (typeof body.id !== "string" || !body.id.trim()) {
            return jsonError("Missing event id.", 400);
        }
        const update = {
            updated_at: new Date().toISOString()
        };
        if ("featured" in body) {
            if (typeof body.featured !== "boolean") {
                return jsonError("featured must be a boolean.", 400);
            }
            update.featured = body.featured;
        }
        if ("visible" in body) {
            if (typeof body.visible !== "boolean") {
                return jsonError("visible must be a boolean.", 400);
            }
            update.visible = body.visible;
        }
        if ("dataQuality" in body) {
            if (typeof body.dataQuality !== "string" || !DATA_QUALITY_OPTIONS.includes(body.dataQuality)) {
                return jsonError("dataQuality is invalid.", 400);
            }
            update.data_quality = body.dataQuality;
        }
        if ("vehicleType" in body || "vehicle_type" in body) {
            const value = body.vehicleType ?? body.vehicle_type;
            if (typeof value !== "string" || !__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["VEHICLE_TYPE_OPTIONS"].includes(value)) {
                return jsonError("vehicleType is invalid.", 400);
            }
            update.vehicle_type = value;
        }
        if ("notes" in body) {
            if (typeof body.notes !== "string") {
                return jsonError("notes must be a string.", 400);
            }
            update.notes = body.notes.trim() || null;
        }
        if (!("featured" in update) && !("visible" in update) && !("data_quality" in update) && !("vehicle_type" in update) && !("notes" in update)) {
            return jsonError("No supported fields to update.", 400);
        }
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").update(update).eq("id", body.id).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 500);
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0xq_xq-._.js.map