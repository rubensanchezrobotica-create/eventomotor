module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/app/api/admin/events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "PATCH",
    ()=>PATCH,
    "POST",
    ()=>POST,
    "PUT",
    ()=>PUT
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
;
const ADMIN_EVENT_SELECT = "id,title,championship,discipline,start_date,end_date,venue,city,province,region,level,source,source_url,ticket_url,tags,featured,visible,import_method,data_quality,notes";
const DATA_QUALITY_OPTIONS = [
    "draft",
    "reviewed",
    "published",
    "cancelled",
    "pending_date"
];
function jsonError(message, status) {
    return Response.json({
        ok: false,
        error: message
    }, {
        status
    });
}
function validateAdminSecret(request) {
    const adminSecret = process.env.ADMIN_SECRET;
    if (!adminSecret) {
        return {
            ok: false,
            status: 500,
            error: "ADMIN_SECRET is not configured. Add ADMIN_SECRET to your environment."
        };
    }
    if (request.headers.get("authorization") !== `Bearer ${adminSecret}`) {
        return {
            ok: false,
            status: 401,
            error: "Unauthorized. Send Authorization: Bearer ADMIN_SECRET."
        };
    }
    return {
        ok: true
    };
}
function createAdminClient() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        throw new Error("Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.");
    }
    return supabase;
}
function isRecord(value) {
    return typeof value === "object" && value !== null && !Array.isArray(value);
}
function requireString(body, field) {
    const value = body[field];
    if (typeof value !== "string" || !value.trim()) {
        throw new Error(`${field} is required.`);
    }
    return value.trim();
}
function optionalString(body, field) {
    const value = body[field];
    return typeof value === "string" && value.trim() ? value.trim() : null;
}
function requireIsoDate(body, field) {
    const value = requireString(body, field);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
        throw new Error(`${field} must use YYYY-MM-DD format.`);
    }
    return value;
}
function parseTags(value) {
    if (Array.isArray(value)) {
        return value.filter((tag)=>typeof tag === "string").map((tag)=>tag.trim()).filter(Boolean);
    }
    if (typeof value === "string") {
        return value.split(",").map((tag)=>tag.trim()).filter(Boolean);
    }
    return [];
}
function parseDataQuality(value) {
    if (typeof value === "string" && DATA_QUALITY_OPTIONS.includes(value)) {
        return value;
    }
    return "reviewed";
}
function parseAdminEventBody(value) {
    if (!isRecord(value)) {
        throw new Error("Request body must be an object.");
    }
    const id = requireString(value, "id");
    const title = requireString(value, "title");
    const discipline = requireString(value, "discipline");
    const startDate = requireIsoDate(value, "start");
    const endDate = requireIsoDate(value, "end");
    const venue = requireString(value, "venue");
    const city = requireString(value, "city");
    const province = requireString(value, "province");
    const sourceUrl = requireString(value, "sourceUrl");
    return {
        id,
        title,
        championship: optionalString(value, "championship") || title,
        discipline,
        start_date: startDate,
        end_date: endDate,
        venue,
        city,
        province,
        region: optionalString(value, "region") || province,
        level: optionalString(value, "level") || "Publicado",
        source: optionalString(value, "source") || "Admin",
        source_url: sourceUrl,
        ticket_url: optionalString(value, "ticketUrl") || "",
        tags: parseTags(value.tags),
        featured: typeof value.featured === "boolean" ? value.featured : false,
        visible: typeof value.visible === "boolean" ? value.visible : true,
        import_method: optionalString(value, "importMethod"),
        data_quality: parseDataQuality(value.dataQuality),
        notes: optionalString(value, "notes"),
        updated_at: new Date().toISOString()
    };
}
async function GET(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").select(ADMIN_EVENT_SELECT).order("start_date", {
            ascending: true
        });
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            events: data || []
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 500);
    }
}
async function POST(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const payload = parseAdminEventBody(await request.json());
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").insert(payload).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        }, {
            status: 201
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 400);
    }
}
async function PUT(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const payload = parseAdminEventBody(await request.json());
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").update(payload).eq("id", payload.id).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 400);
    }
}
async function PATCH(request) {
    const auth = validateAdminSecret(request);
    if (!auth.ok) {
        return jsonError(auth.error, auth.status);
    }
    try {
        const body = await request.json();
        if (typeof body.id !== "string" || !body.id.trim()) {
            return jsonError("Missing event id.", 400);
        }
        if (typeof body.featured !== "boolean") {
            return jsonError("Missing featured boolean.", 400);
        }
        const supabase = createAdminClient();
        const { data, error } = await supabase.from("events").update({
            featured: body.featured,
            updated_at: new Date().toISOString()
        }).eq("id", body.id).select(ADMIN_EVENT_SELECT).single();
        if (error) {
            return jsonError(error.message, 500);
        }
        return Response.json({
            ok: true,
            event: data
        });
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        return jsonError(message, 500);
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0h6cz8-._.js.map