"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { MONTHS, TODAY, WEEK_DAYS, formatRange, getDisciplineColor, isOnDay } from "@/lib/date-utils";
import type { EventItem } from "@/types/event";
import type { ConceptZone } from "./concept-model";
import { dayLabel, eventHref } from "./concept-model";

type VehicleMainFilter = "todos" | "moto" | "coche";

type ConceptCalendarProps = {
  year: number;
  month: number;
  setMonth: (updater: (current: number) => number) => void;
  days: Date[];
  agendaDay: Date;
  selectedDayEvents: EventItem[];
  fallbackEvents: EventItem[];
  monthEventCount: number;
  monthDisciplineCount: number;
  filtered: EventItem[];
  activeLabel: string;
  hasActiveFilters: boolean;
  query: string;
  discipline: string;
  zone: string;
  vehicleFilter: VehicleMainFilter;
  disciplines: string[];
  zones: ConceptZone[];
  setQuery: (value: string) => void;
  setDiscipline: (value: string) => void;
  onVehicle: (filter: VehicleMainFilter) => void;
  onZoneSelect: (value: string) => void;
  onThisMonth: () => void;
  onDay: (day: Date) => void;
  onClearFilters: () => void;
};

function vehicleLabel(event: EventItem) {
  const value = event.vehicleType || event.vehicle_type;
  if (value === "moto") return "Moto";
  if (value === "coche") return "Coche";
  if (value === "mixto") return "Mixto";
  return value || "";
}

export default function ConceptCalendar({
  year,
  month,
  setMonth,
  days,
  agendaDay,
  monthEventCount,
  monthDisciplineCount,
  filtered,
  activeLabel,
  hasActiveFilters,
  onThisMonth,
  onDay,
  onClearFilters,
}: ConceptCalendarProps) {
  const [modalDay, setModalDay] = useState<Date | null>(null);

  const modalEvents = useMemo(() => {
    if (!modalDay) return [];
    return filtered.filter((event) => isOnDay(event, modalDay));
  }, [filtered, modalDay]);

  const modalDateLabel = modalDay
    ? new Intl.DateTimeFormat("es-ES", { day: "numeric", month: "long" }).format(modalDay)
    : "";

  function openDay(day: Date, dayEvents: EventItem[]) {
    if (!dayEvents.length) return;
    onDay(day);
    setModalDay(day);
  }

  return (
    <div className="emc-calendar-embed" id="calendario-vista">
      <div className="emc-calendar-wrap">
        <div className="emc-panel emc-calendar-panel">
          <div className="emc-filter-status emc-calendar-summary">
            <div className="emc-filter-status-head">
              <div>
                <span className="emc-kicker">Calendario</span>
                <strong>{activeLabel}</strong>
                <p>{filtered.length} próximos eventos disponibles.</p>
              </div>
              <div className="emc-calendar-filter-actions">
                <button className="emc-btn emc-btn-dark" onClick={onThisMonth} type="button">
                  Este mes
                </button>
                {hasActiveFilters ? (
                  <button className="emc-btn emc-btn-light" onClick={onClearFilters} type="button">
                    Ver todos
                  </button>
                ) : null}
              </div>
            </div>
          </div>

          <div className="emc-calendar-toolbar">
            <div className="emc-month-title">
              <h3>
                {MONTHS[month]} {year}
              </h3>
              <p>
                {monthEventCount} eventos / {monthDisciplineCount} disciplinas
              </p>
            </div>
            <div className="emc-month-actions">
              <button className="emc-icon" onClick={() => setMonth((current) => (current + 11) % 12)} type="button">
                ‹
              </button>
              <button className="emc-icon" onClick={() => setMonth((current) => (current + 1) % 12)} type="button">
                ›
              </button>
              <button className="emc-btn emc-btn-dark" onClick={() => setMonth(() => TODAY.getMonth())} type="button">
                Este mes
              </button>
            </div>
          </div>

          <div className="emc-weekdays">
            {WEEK_DAYS.map((day) => (
              <div key={day}>{day}</div>
            ))}
          </div>
          <div className="emc-month">
            {days.map((day) => {
              const dayEvents = filtered.filter((event) => isOnDay(event, day));
              const isFocused = agendaDay.toDateString() === day.toDateString() && dayEvents.length > 0;
              const isToday = TODAY.toDateString() === day.toDateString();

              return (
                <button
                  aria-label={
                    dayEvents.length
                      ? `${day.getDate()} de ${MONTHS[day.getMonth()]}, ${dayEvents.length} eventos`
                      : `${day.getDate()} de ${MONTHS[day.getMonth()]}, sin eventos`
                  }
                  className={`emc-day ${dayEvents.length ? "emc-has" : ""} ${isFocused ? "emc-focus" : ""} ${isToday ? "emc-today" : ""}`}
                  key={day.toISOString()}
                  onClick={() => openDay(day, dayEvents)}
                  type="button"
                >
                  <span className="emc-day-number">{day.getDate()}</span>
                  {dayEvents.length ? <small>{dayEvents.length}</small> : null}
                  <span className="emc-dots">
                    {dayEvents.slice(0, 5).map((event) => (
                      <span
                        className="emc-edot"
                        key={event.id}
                        style={{ background: getDisciplineColor(event.discipline).accent }}
                      />
                    ))}
                  </span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {modalDay && modalEvents.length ? (
        <div
          className="emc-day-modal"
          onClick={(event) => {
            if (event.target === event.currentTarget) setModalDay(null);
          }}
          role="presentation"
        >
          <section aria-labelledby="emc-day-modal-title" aria-modal="true" className="emc-day-modal-panel" role="dialog">
            <button
              aria-label="Cerrar eventos del día"
              className="emc-day-modal-close"
              onClick={() => setModalDay(null)}
              type="button"
            >
              ×
            </button>
            <div className="emc-day-modal-head">
              <div>
                <span className="emc-kicker">Agenda del día</span>
                <h3 id="emc-day-modal-title">Eventos del {modalDateLabel}</h3>
              </div>
              <span className="emc-badge">{modalEvents.length} eventos</span>
            </div>
            <div className="emc-day-modal-list">
              {modalEvents.map((event) => {
                const label = dayLabel(event);
                const type = vehicleLabel(event);

                return (
                  <article className="emc-event-row emc-modal-event-row" key={event.id}>
                    <div className="emc-datebox">
                      {label.day}
                      <small>{label.month}</small>
                    </div>
                    <div>
                      <div className="emc-event-chipline">
                        <span className="emc-badge">{event.discipline}</span>
                        {type ? <span className="emc-vehicle-mini">{type}</span> : null}
                      </div>
                      <h4>{event.title}</h4>
                      <p>
                        {formatRange(event)} / {event.city}, {event.province}
                      </p>
                    </div>
                    <div className="emc-event-actions">
                      <Link className="emc-card-action" href={eventHref(event)}>
                        Ver evento
                      </Link>
                      {event.ticketUrl ? (
                        <a className="emc-ticket-action" href={event.ticketUrl} rel="noreferrer" target="_blank">
                          Entradas
                        </a>
                      ) : null}
                    </div>
                  </article>
                );
              })}
            </div>
          </section>
        </div>
      ) : null}
    </div>
  );
}
