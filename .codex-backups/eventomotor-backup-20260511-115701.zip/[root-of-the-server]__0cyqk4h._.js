module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/sync/dedupe-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dedupeEvents",
    ()=>dedupeEvents
]);
function dedupeKey(event) {
    return [
        event.title,
        event.start_date,
        event.venue || ""
    ].map((value)=>value.trim().toLowerCase()).join("|");
}
function dedupeEvents(events) {
    const seen = new Set();
    const deduped = [];
    for (const event of events){
        const key = dedupeKey(event);
        if (seen.has(key)) {
            continue;
        }
        seen.add(key);
        deduped.push(event);
    }
    return deduped;
}
}),
"[project]/lib/sync/normalize-sync-event.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "normalizeSyncEvent",
    ()=>normalizeSyncEvent
]);
function normalizeText(value) {
    return value.trim().replace(/\s+/g, " ");
}
function slugify(value) {
    return normalizeText(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}
function buildEventId(event) {
    if (event.id) {
        return event.id;
    }
    const source = slugify(event.source || "external");
    const title = slugify(event.title);
    const start = slugify(event.start);
    const venue = slugify(event.venue || "venue-pending");
    return [
        source,
        title,
        start,
        venue
    ].filter(Boolean).join("-");
}
function normalizeSyncEvent(event) {
    const title = normalizeText(event.title);
    const discipline = event.discipline?.trim() || "Motociclismo";
    const venue = event.venue?.trim() || "Por confirmar";
    const tags = event.tags?.map((tag)=>tag.trim()).filter(Boolean);
    return {
        id: buildEventId({
            ...event,
            title,
            discipline,
            venue
        }),
        title,
        championship: event.championship?.trim() || discipline,
        discipline,
        start_date: event.start,
        end_date: event.end || event.start,
        venue,
        city: event.city?.trim() || null,
        province: event.province?.trim() || null,
        region: event.region?.trim() || event.province?.trim() || null,
        level: event.level?.trim() || "Publicado",
        source: event.source.trim(),
        source_id: event.sourceId?.trim() || null,
        source_url: event.sourceUrl?.trim() || "",
        ticket_url: event.ticketUrl?.trim() || "",
        tags: tags?.length ? tags : [
            discipline
        ],
        featured: Boolean(event.featured),
        updated_at: new Date().toISOString()
    };
}
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured)
    };
}
}),
"[project]/lib/sync/upsert-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "upsertEvents",
    ()=>upsertEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
;
async function upsertEvents(events) {
    if (!events.length) {
        return 0;
    }
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        throw new Error("Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.");
    }
    const { data, error } = await supabase.from("events").upsert(events, {
        onConflict: "id"
    }).select("id");
    if (error) {
        throw new Error(error.message);
    }
    return data?.length ?? 0;
}
}),
"[project]/app/api/sync-events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
(()=>{
    const e = new Error("Cannot find module '@/lib/scrapers/rfme'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$dedupe$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/dedupe-events.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$normalize$2d$sync$2d$event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/normalize-sync-event.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$upsert$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/upsert-events.ts [app-route] (ecmascript)");
;
;
;
;
function jsonResponse(body, status = 200) {
    return Response.json(body, {
        status
    });
}
function validateCronSecret(request) {
    const cronSecret = process.env.CRON_SECRET;
    if (!cronSecret) {
        return {
            ok: false,
            status: 500,
            error: "CRON_SECRET is not configured. Add CRON_SECRET to your environment."
        };
    }
    const authorization = request.headers.get("authorization");
    if (authorization !== `Bearer ${cronSecret}`) {
        return {
            ok: false,
            status: 401,
            error: "Unauthorized. Send Authorization: Bearer CRON_SECRET."
        };
    }
    return {
        ok: true
    };
}
async function GET(request) {
    const auth = validateCronSecret(request);
    if (!auth.ok) {
        return jsonResponse({
            ok: false,
            sources: [],
            insertedOrUpdated: 0,
            errors: [
                auth.error
            ]
        }, auth.status);
    }
    const sources = [];
    const errors = [];
    let insertedOrUpdated = 0;
    try {
        sources.push("rfme");
        const rawEvents = await scrapeRfmeEvents();
        const normalizedEvents = rawEvents.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$normalize$2d$sync$2d$event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["normalizeSyncEvent"]);
        const dedupedEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$dedupe$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dedupeEvents"])(normalizedEvents);
        if (dedupedEvents.length) {
            insertedOrUpdated = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$upsert$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["upsertEvents"])(dedupedEvents);
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        errors.push(message);
    }
    return jsonResponse({
        ok: errors.length === 0,
        sources,
        insertedOrUpdated,
        errors
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0cyqk4h._.js.map