module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[project]/lib/slug.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/event-listing-slugs.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DISCIPLINE_SLUGS",
    ()=>DISCIPLINE_SLUGS,
    "getDisciplineSlug",
    ()=>getDisciplineSlug,
    "getListingLinks",
    ()=>getListingLinks,
    "getRegionSlug",
    ()=>getRegionSlug,
    "resolveEventListing",
    ()=>resolveEventListing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
const DISCIPLINE_SLUGS = {
    motogp: "MotoGP",
    motocross: "Motocross",
    trial: "Trial",
    enduro: "Enduro",
    superbike: "Superbike",
    velocidad: "Velocidad",
    minivelocidad: "MiniVelocidad",
    mototurismo: "Mototurismo"
};
const REGION_ALIASES = {
    andalucia: [
        "andalucia",
        "andalusia"
    ],
    catalunya: [
        "catalunya",
        "cataluna",
        "catalonia"
    ],
    aragon: [
        "aragon"
    ],
    navarra: [
        "navarra"
    ],
    valencia: [
        "valencia",
        "comunitat-valenciana",
        "comunidad-valenciana"
    ],
    murcia: [
        "murcia",
        "region-de-murcia"
    ]
};
function getDisciplineSlug(name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function getRegionSlug(name) {
    const slug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slugify"])(name);
    const alias = Object.entries(REGION_ALIASES).find(([, values])=>values.includes(slug));
    return alias?.[0] || slug;
}
function sameDiscipline(event, name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slugify"])(event.discipline) === (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function sameRegion(event, slug) {
    const candidates = [
        event.region,
        event.province
    ].map(getRegionSlug);
    const aliases = REGION_ALIASES[slug] || [
        slug
    ];
    return candidates.some((candidate)=>candidate === slug || aliases.includes(candidate));
}
function resolveEventListing(slug, events) {
    const normalizedSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["slugify"])(slug);
    const disciplineName = DISCIPLINE_SLUGS[normalizedSlug];
    if (disciplineName) {
        const listingEvents = events.filter((event)=>sameDiscipline(event, disciplineName));
        return listingEvents.length ? {
            kind: "discipline",
            slug: normalizedSlug,
            name: disciplineName,
            events: listingEvents
        } : null;
    }
    const regionEvents = events.filter((event)=>sameRegion(event, normalizedSlug));
    if (!regionEvents.length) {
        return null;
    }
    return {
        kind: "region",
        slug: normalizedSlug,
        name: regionEvents[0].region,
        events: regionEvents
    };
}
function getListingLinks(events) {
    const disciplineLinks = Object.entries(DISCIPLINE_SLUGS).map(([slug, name])=>({
            kind: "discipline",
            slug,
            name,
            count: events.filter((event)=>sameDiscipline(event, name)).length
        })).filter((link)=>link.count > 0);
    const regionMap = new Map();
    for (const event of events){
        const slug = getRegionSlug(event.region);
        const current = regionMap.get(slug);
        if (current) {
            current.count += 1;
        } else {
            regionMap.set(slug, {
                kind: "region",
                slug,
                name: event.region,
                count: 1
            });
        }
    }
    return {
        disciplines: disciplineLinks,
        regions: [
            ...regionMap.values()
        ].sort((a, b)=>a.name.localeCompare(b.name))
    };
}
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/lib/sources.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SOURCES",
    ()=>SOURCES,
    "SOURCE_FEEDS",
    ()=>SOURCE_FEEDS
]);
const SOURCES = {
    RFME: "https://rfme.com/calendario-campeonatos/",
    MotoGP: "https://www.motogp.com/es/calendar/2026",
    CircuitCat: "https://www.circuitcat.com/",
    MotorLand: "https://www.motorlandaragon.com/",
    RicardoTormo: "https://entradas.circuitvalencia.com/circuitvalencia/events"
};
const SOURCE_FEEDS = [
    {
        id: "rfme",
        name: "RFME",
        url: SOURCES.RFME,
        type: "Calendario oficial"
    },
    {
        id: "motogp",
        name: "MotoGP",
        url: SOURCES.MotoGP,
        type: "Calendario oficial"
    },
    {
        id: "circuitcat",
        name: "Circuit de Barcelona-Catalunya",
        url: SOURCES.CircuitCat,
        type: "Circuito"
    },
    {
        id: "motorland",
        name: "MotorLand Aragón",
        url: SOURCES.MotorLand,
        type: "Circuito"
    },
    {
        id: "ricardotormo",
        name: "Circuit Ricardo Tormo",
        url: SOURCES.RicardoTormo,
        type: "Entradas"
    }
];
}),
"[project]/lib/fallback-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FALLBACK_EVENTS",
    ()=>FALLBACK_EVENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sources.ts [app-route] (ecmascript)");
;
const FALLBACK_EVENTS = [
    {
        id: "motogp-jerez-2026",
        title: "Gran Premio de España de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-04-24",
        end: "2026-04-26",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Mundial",
        source: "MotoGP",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotoGP,
        ticketUrl: "https://www.circuitodejerez.com/",
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-catalunya-2026",
        title: "Gran Premi de Catalunya de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-05-15",
        end: "2026-05-17",
        venue: "Circuit de Barcelona-Catalunya",
        city: "Montmeló",
        province: "Barcelona",
        region: "Catalunya",
        level: "Mundial",
        source: "Circuit de Barcelona-Catalunya",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-aragon-2026",
        title: "Gran Premio de Aragón de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-08-28",
        end: "2026-08-30",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Mundial",
        source: "MotorLand Aragón",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-valencia-2026",
        title: "Gran Premio Motul de la Comunitat Valenciana",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-11-27",
        end: "2026-11-29",
        venue: "Circuit Ricardo Tormo",
        city: "Cheste",
        province: "Valencia",
        region: "Comunitat Valenciana",
        level: "Mundial",
        source: "Circuit Ricardo Tormo",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        tags: [
            "MotoGP",
            "final"
        ],
        featured: true
    },
    {
        id: "esbk-navarra-2026",
        title: "ESBK Navarra",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-05-07",
        end: "2026-05-10",
        venue: "Circuito de Navarra",
        city: "Los Arcos",
        province: "Navarra",
        region: "Navarra",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: "https://www.circuitodenavarra.com/",
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: true
    },
    {
        id: "esbk-motorland-2026",
        title: "ESBK MotorLand Aragón",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-07-16",
        end: "2026-07-19",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: false
    },
    {
        id: "copa-velocidad-jerez-2026",
        title: "Copa de España de Velocidad - Jerez",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad",
        start: "2026-05-29",
        end: "2026-05-31",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        ticketUrl: "",
        tags: [
            "velocidad"
        ],
        featured: false
    },
    {
        id: "mx-osuna-2026",
        title: "Campeonato de España de Motocross - Osuna",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-05-02",
        end: "2026-05-03",
        venue: "Circuito de Osuna",
        city: "Osuna",
        province: "Sevilla",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: "",
        tags: [
            "MX",
            "offroad"
        ],
        featured: true
    },
    {
        id: "mx-motorland-2026",
        title: "Campeonato de España de Motocross - MotorLand",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MX",
            "offroad"
        ],
        featured: false
    },
    {
        id: "trial-gironella-2026",
        title: "Campeonato de España de Trial - Gironella",
        championship: "Campeonato de España de Trial",
        discipline: "Trial",
        start: "2026-05-30",
        end: "2026-05-31",
        venue: "Gironella",
        city: "Gironella",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        ticketUrl: "",
        tags: [
            "trial"
        ],
        featured: false
    },
    {
        id: "enduro-orista-2026",
        title: "Campeonato de España de Enduro - Oristà",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "Torre d'Oristà",
        city: "Oristà",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        ticketUrl: "",
        tags: [
            "enduro"
        ],
        featured: false
    },
    {
        id: "mini-cartagena-2026",
        title: "Copa de España de MiniVelocidad - Cartagena",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad",
        start: "2026-05-01",
        end: "2026-05-03",
        venue: "Circuito de Cartagena",
        city: "Cartagena",
        province: "Murcia",
        region: "Región de Murcia",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        ticketUrl: "https://www.circuitocartagena.com/",
        tags: [
            "minivelocidad"
        ],
        featured: false
    },
    {
        id: "tour-penitentes-2026",
        title: "RFME Mototurismo Touring - Penitentes",
        championship: "RFME Mototurismo Touring Challenge",
        discipline: "Mototurismo",
        start: "2026-05-01",
        end: "2026-05-01",
        venue: "Penitentes",
        city: "Pirineo aragonés",
        province: "Huesca",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        ticketUrl: "",
        tags: [
            "mototurismo"
        ],
        featured: false
    }
];
}),
"[project]/lib/public-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVisibleEvents",
    ()=>getVisibleEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fallback-events.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
;
function fallbackVisibleEvents() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FALLBACK_EVENTS"].filter((event)=>event.visible !== false).map((event)=>({
            ...event,
            slug: event.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(event.title, event.start)
        }));
}
async function getVisibleEvents() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        return fallbackVisibleEvents();
    }
    const { data, error } = await supabase.from("events").select("*").eq("visible", true).order("start_date", {
        ascending: true
    });
    if (error || !data) {
        return fallbackVisibleEvents();
    }
    const events = data.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mapEventRowToEventItem"]);
    return events.length ? events : fallbackVisibleEvents();
}
}),
"[project]/lib/site-url.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSiteUrl",
    ()=>getSiteUrl
]);
function getSiteUrl() {
    const configuredUrl = ("TURBOPACK compile-time value", "https://www.eventomotor.com");
    const vercelUrl = process.env.VERCEL_URL;
    if ("TURBOPACK compile-time truthy", 1) {
        return configuredUrl.replace(/\/$/, "");
    }
    //TURBOPACK unreachable
    ;
}
}),
"[project]/app/sitemap.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>sitemap
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-listing-slugs.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/public-events.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/site-url.ts [app-route] (ecmascript)");
;
;
;
function sitemapEntry(path, lastModified, changeFrequency, priority) {
    return {
        url: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getSiteUrl"])()}${path}`,
        lastModified,
        changeFrequency,
        priority
    };
}
async function sitemap() {
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVisibleEvents"])();
    const links = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getListingLinks"])(events);
    const now = new Date();
    const staticEntries = [
        sitemapEntry("/", now, "daily", 1),
        sitemapEntry("/eventos-moto", now, "daily", 0.9)
    ];
    const listingEntries = [
        ...links.disciplines,
        ...links.regions
    ].map((link)=>sitemapEntry(`/eventos-moto/${link.slug}`, now, "weekly", 0.8));
    const eventEntries = events.filter((event)=>Boolean(event.slug)).map((event)=>sitemapEntry(`/evento/${event.slug}`, new Date(event.start), "weekly", 0.7));
    return [
        ...staticEntries,
        ...listingEntries,
        ...eventEntries
    ];
}
}),
"[project]/app/sitemap--route-entry.js [app-route] (ecmascript) <locals>", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/sitemap.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$metadata$2f$resolve$2d$route$2d$data$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/build/webpack/loaders/metadata/resolve-route-data.js [app-route] (ecmascript)");
;
;
;
const contentType = "application/xml";
const cacheControl = "public, max-age=0, must-revalidate";
const fileType = "sitemap";
if (typeof __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"] !== 'function') {
    throw new Error('Default export is missing in "./sitemap.ts"');
}
async function GET() {
    const data = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"])();
    const content = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$webpack$2f$loaders$2f$metadata$2f$resolve$2d$route$2d$data$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["resolveRouteData"])(data, fileType);
    return new __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"](content, {
        headers: {
            'Content-Type': contentType,
            'Cache-Control': cacheControl
        }
    });
}
;
}),
"[project]/app/sitemap--route-entry.js [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2d2d$route$2d$entry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["GET"]
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2d2d$route$2d$entry$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/app/sitemap--route-entry.js [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$sitemap$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/sitemap.ts [app-route] (ecmascript)");
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__08ike9e._.js.map