module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.0x3dzn~oxb6tn.ico" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 256,
    height: 256
};
}),
"[project]/lib/date-utils.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_EVENTS_URL",
    ()=>API_EVENTS_URL,
    "AUTO_REFRESH_MS",
    ()=>AUTO_REFRESH_MS,
    "COLORS",
    ()=>COLORS,
    "DISCIPLINE_COLORS",
    ()=>DISCIPLINE_COLORS,
    "MONTHS",
    ()=>MONTHS,
    "TODAY",
    ()=>TODAY,
    "WEEK_DAYS",
    ()=>WEEK_DAYS,
    "addDays",
    ()=>addDays,
    "cleanIcs",
    ()=>cleanIcs,
    "cls",
    ()=>cls,
    "daysForMonth",
    ()=>daysForMonth,
    "downloadCalendar",
    ()=>downloadCalendar,
    "formatRange",
    ()=>formatRange,
    "formatStatus",
    ()=>formatStatus,
    "getDisciplineColor",
    ()=>getDisciplineColor,
    "isDateText",
    ()=>isDateText,
    "isOnDay",
    ()=>isOnDay,
    "parseDate",
    ()=>parseDate,
    "statusOf",
    ()=>statusOf,
    "toIcsDate",
    ()=>toIcsDate
]);
const API_EVENTS_URL = "/api/events";
const AUTO_REFRESH_MS = 15 * 60 * 1000;
const TODAY = new Date(2026, 3, 27);
const COLORS = {
    MotoGP: "bg-red-500 text-white border-red-300",
    Superbike: "bg-orange-500 text-white border-orange-300",
    Velocidad: "bg-amber-400 text-zinc-950 border-amber-200",
    Motocross: "bg-lime-400 text-zinc-950 border-lime-200",
    Trial: "bg-emerald-400 text-zinc-950 border-emerald-200",
    Enduro: "bg-green-500 text-white border-green-300",
    MiniVelocidad: "bg-sky-400 text-zinc-950 border-sky-200",
    Mototurismo: "bg-violet-500 text-white border-violet-300",
    Motociclismo: "bg-zinc-500 text-white border-zinc-300"
};
const DISCIPLINE_COLORS = {
    MotoGP: {
        name: "rojo",
        accent: "#E10600",
        badge: "border-red-500/25 bg-red-500/10 text-red-100",
        calendar: "border-l-red-500 bg-red-500/[0.08] text-red-50",
        dot: "bg-red-500"
    },
    Superbike: {
        name: "naranja",
        accent: "#F97316",
        badge: "border-orange-400/25 bg-orange-400/10 text-orange-100",
        calendar: "border-l-orange-400 bg-orange-400/[0.08] text-orange-50",
        dot: "bg-orange-400"
    },
    Velocidad: {
        name: "ambar",
        accent: "#F59E0B",
        badge: "border-amber-400/25 bg-amber-400/10 text-amber-100",
        calendar: "border-l-amber-400 bg-amber-400/[0.08] text-amber-50",
        dot: "bg-amber-400"
    },
    Motocross: {
        name: "verde lima",
        accent: "#A3E635",
        badge: "border-lime-400/25 bg-lime-400/10 text-lime-100",
        calendar: "border-l-lime-400 bg-lime-400/[0.08] text-lime-50",
        dot: "bg-lime-400"
    },
    Enduro: {
        name: "verde",
        accent: "#22C55E",
        badge: "border-green-400/25 bg-green-400/10 text-green-100",
        calendar: "border-l-green-400 bg-green-400/[0.08] text-green-50",
        dot: "bg-green-400"
    },
    Trial: {
        name: "turquesa",
        accent: "#2DD4BF",
        badge: "border-teal-400/25 bg-teal-400/10 text-teal-100",
        calendar: "border-l-teal-400 bg-teal-400/[0.08] text-teal-50",
        dot: "bg-teal-400"
    },
    Mototurismo: {
        name: "violeta",
        accent: "#A78BFA",
        badge: "border-violet-400/25 bg-violet-400/10 text-violet-100",
        calendar: "border-l-violet-400 bg-violet-400/[0.08] text-violet-50",
        dot: "bg-violet-400"
    },
    MiniVelocidad: {
        name: "cyan",
        accent: "#22D3EE",
        badge: "border-cyan-400/25 bg-cyan-400/10 text-cyan-100",
        calendar: "border-l-cyan-400 bg-cyan-400/[0.08] text-cyan-50",
        dot: "bg-cyan-400"
    },
    Supermoto: {
        name: "fucsia",
        accent: "#E879F9",
        badge: "border-fuchsia-400/25 bg-fuchsia-400/10 text-fuchsia-100",
        calendar: "border-l-fuchsia-400 bg-fuchsia-400/[0.08] text-fuchsia-50",
        dot: "bg-fuchsia-400"
    },
    "Cross Country": {
        name: "esmeralda",
        accent: "#34D399",
        badge: "border-emerald-400/25 bg-emerald-400/10 text-emerald-100",
        calendar: "border-l-emerald-400 bg-emerald-400/[0.08] text-emerald-50",
        dot: "bg-emerald-400"
    },
    Freestyle: {
        name: "rosa",
        accent: "#F472B6",
        badge: "border-pink-400/25 bg-pink-400/10 text-pink-100",
        calendar: "border-l-pink-400 bg-pink-400/[0.08] text-pink-50",
        dot: "bg-pink-400"
    },
    "Hard Enduro": {
        name: "verde oscuro",
        accent: "#16A34A",
        badge: "border-green-600/25 bg-green-600/10 text-green-100",
        calendar: "border-l-green-600 bg-green-600/[0.08] text-green-50",
        dot: "bg-green-600"
    },
    Motociclismo: {
        name: "gris",
        accent: "#A1A1AA",
        badge: "border-white/[0.08] bg-white/[0.035] text-zinc-200",
        calendar: "border-l-zinc-500 bg-white/[0.035] text-zinc-100",
        dot: "bg-zinc-400"
    }
};
function getDisciplineColor(discipline) {
    return DISCIPLINE_COLORS[discipline] || DISCIPLINE_COLORS.Motociclismo;
}
const MONTHS = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
];
const WEEK_DAYS = [
    "L",
    "M",
    "X",
    "J",
    "V",
    "S",
    "D"
];
function cls(...parts) {
    return parts.filter(Boolean).join(" ");
}
function parseDate(value) {
    const parts = String(value || "").slice(0, 10).split("-").map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
}
function isDateText(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "").slice(0, 10));
}
function addDays(date, days) {
    const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    copy.setDate(copy.getDate() + days);
    return copy;
}
function toIcsDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}${month}${day}`;
}
function cleanIcs(text) {
    const slash = String.fromCharCode(92);
    const newline = String.fromCharCode(10);
    return String(text || "").split(slash).join(slash + slash).split(",").join(slash + ",").split(";").join(slash + ";").split(newline).join(slash + "n");
}
function statusOf(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const today = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());
    if (end < today) return "finalizado";
    if (start <= today && end >= today) return "en directo";
    return "proximo";
}
function formatStatus(status) {
    return status === "proximo" ? "próximo" : status;
}
function formatRange(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const formatter = new Intl.DateTimeFormat("es-ES", {
        day: "numeric",
        month: "short"
    });
    if (start.toDateString() === end.toDateString()) {
        return formatter.format(start);
    }
    if (start.getMonth() === end.getMonth()) {
        const monthName = formatter.format(end).split(" ").slice(1).join(" ");
        return `${start.getDate()}-${end.getDate()} ${monthName}`;
    }
    return `${formatter.format(start)} - ${formatter.format(end)}`;
}
function isOnDay(event, day) {
    const current = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    return parseDate(event.start).getTime() <= current.getTime() && parseDate(event.end).getTime() >= current.getTime();
}
function daysForMonth(year, month) {
    const first = new Date(year, month, 1);
    const last = new Date(year, month + 1, 0);
    const offset = (first.getDay() + 6) % 7;
    const days = [];
    for(let i = offset; i > 0; i -= 1){
        days.push(addDays(first, -i));
    }
    for(let d = 1; d <= last.getDate(); d += 1){
        days.push(new Date(year, month, d));
    }
    while(days.length % 7 !== 0){
        days.push(addDays(days[days.length - 1], 1));
    }
    return days;
}
function downloadCalendar(items) {
    const lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//MotoCalendario Espana//ES"
    ];
    items.forEach((event)=>{
        const location = `${event.venue}, ${event.city}, ${event.province}`;
        const description = `${event.championship} - ${event.discipline} - Fuente: ${event.sourceUrl}`;
        lines.push("BEGIN:VEVENT");
        lines.push(`UID:${event.id}@motocalendario.es`);
        lines.push("DTSTAMP:20260427T090000Z");
        lines.push(`DTSTART;VALUE=DATE:${toIcsDate(parseDate(event.start))}`);
        lines.push(`DTEND;VALUE=DATE:${toIcsDate(addDays(parseDate(event.end), 1))}`);
        lines.push(`SUMMARY:${cleanIcs(event.title)}`);
        lines.push(`LOCATION:${cleanIcs(location)}`);
        lines.push(`DESCRIPTION:${cleanIcs(description)}`);
        lines.push("END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    const blob = new Blob([
        lines.join(String.fromCharCode(13, 10))
    ], {
        type: "text/calendar;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "moto-calendario-espana-2026.ics";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}
}),
"[project]/components/EventBadge.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-rsc] (ecmascript)");
;
;
function EventBadge({ discipline }) {
    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getDisciplineColor"])(discipline);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `rounded-full border px-2 py-1 text-[11px] font-semibold ${color.badge}`,
        children: discipline
    }, void 0, false, {
        fileName: "[project]/components/EventBadge.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ui/primitives.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "Card",
    ()=>Card,
    "Chip",
    ()=>Chip,
    "SearchInput",
    ()=>SearchInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function cx(...classes) {
    return classes.filter(Boolean).join(" ");
}
function Button({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: cx("inline-flex min-h-12 items-center justify-center rounded-md bg-[#E10600] px-6 py-3 text-sm font-black uppercase tracking-[0.16em] text-white shadow-[0_18px_38px_rgba(225,6,0,0.2)] transition hover:bg-[#ff1710] focus:outline-none focus:ring-2 focus:ring-[#E10600] focus:ring-offset-2 focus:ring-offset-[#0D0D0F] disabled:cursor-not-allowed disabled:opacity-55", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
function Card({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: cx("rounded-lg border border-white/10 bg-[#15161A] shadow-[0_26px_80px_rgba(0,0,0,0.36)]", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
function Chip({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: cx("inline-flex items-center rounded-full border border-white/10 bg-white/[0.035] px-3.5 py-1.5 text-[0.68rem] font-bold uppercase tracking-[0.18em] text-[#A6A6A6]", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
function SearchInput({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        className: cx("min-h-12 w-full rounded-md border border-white/10 bg-[#15161A] px-4 text-sm text-white outline-none transition placeholder:text-[#A6A6A6]/70 focus:border-[#E10600] focus:ring-2 focus:ring-[#E10600]/25", className),
        type: "search",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/UnderConstruction.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UnderConstruction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/components/brand/EventomotorLogo'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/primitives.tsx [app-rsc] (ecmascript)");
;
;
;
const STATUS_ITEMS = [
    "Diseño en progreso",
    "Carga de eventos en marcha",
    "Lanzamiento próximamente"
];
function UnderConstruction() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen overflow-hidden bg-[#0D0D0F] text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative isolate flex min-h-screen items-center px-4 py-10 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-20 bg-[#0D0D0F]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_24%_22%,rgba(225,6,0,0.18),transparent_28%),radial-gradient(circle_at_86%_62%,rgba(225,6,0,0.12),transparent_24%),linear-gradient(135deg,rgba(255,255,255,0.045),transparent_38%)]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-10 opacity-[0.045] bg-[linear-gradient(90deg,rgba(255,255,255,0.82)_1px,transparent_1px),linear-gradient(0deg,rgba(255,255,255,0.82)_1px,transparent_1px)] bg-[size:76px_76px]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute left-[6%] top-[14%] -z-10 hidden h-px w-64 bg-gradient-to-r from-transparent via-[#E10600]/45 to-transparent lg:block"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute right-[8%] top-[22%] -z-10 hidden h-px w-48 bg-gradient-to-r from-transparent via-white/20 to-transparent lg:block"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute bottom-0 left-0 -z-10 h-40 w-full bg-gradient-to-t from-black/45 to-transparent"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative mx-auto grid w-full max-w-6xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(EventomotorLogo, {}, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 23,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-12 flex flex-wrap gap-2.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Chip"], {
                                            children: "Motor España"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 26,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Chip"], {
                                            className: "border-[#E10600]/25 bg-[#E10600]/[0.06] text-white",
                                            children: "Modo construcción"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 27,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "mt-7 max-w-4xl text-4xl font-black leading-[0.97] tracking-tight text-white sm:text-6xl lg:text-[4.7rem]",
                                    children: "EventoMotor está calentando motores"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 32,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-6 max-w-2xl text-lg leading-8 text-white/85 sm:text-xl",
                                    children: "Estamos preparando el calendario definitivo para descubrir eventos del motor en España."
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-4 max-w-2xl text-base leading-7 text-[#A6A6A6]",
                                    children: "Trackdays, motocross, concentraciones, ferias, competiciones y mucho más. Muy pronto, todos los eventos en un solo sitio."
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-9",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                        type: "button",
                                        children: "Vuelve pronto"
                                    }, void 0, false, {
                                        fileName: "[project]/components/UnderConstruction.tsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UnderConstruction.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "relative overflow-hidden p-6 sm:p-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#E10600]/70 to-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute -right-16 -top-16 h-44 w-44 rounded-full bg-[#E10600]/10 blur-3xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative flex items-center justify-between border-b border-white/10 pb-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-black uppercase tracking-[0.3em] text-[#A6A6A6]",
                                                    children: "Estado"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 53,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "mt-2 text-3xl font-black tracking-tight text-white",
                                                    children: "En boxes"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 56,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 52,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex h-8 w-8 items-center justify-center rounded-full border border-[#E10600]/30 bg-[#E10600]/10",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "h-2.5 w-2.5 rounded-full bg-[#E10600] shadow-[0_0_22px_rgba(225,6,0,0.75)]"
                                            }, void 0, false, {
                                                fileName: "[project]/components/UnderConstruction.tsx",
                                                lineNumber: 59,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 58,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-6 space-y-3",
                                    children: STATUS_ITEMS.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4 rounded-md border border-white/[0.08] bg-[#0D0D0F]/70 px-4 py-4 transition hover:border-white/15",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "grid h-9 w-9 shrink-0 place-items-center rounded-md border border-[#E10600]/30 bg-[#E10600]/10 text-xs font-black text-[#E10600]",
                                                    children: [
                                                        "0",
                                                        index + 1
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 69,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-bold text-zinc-100",
                                                    children: item
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 72,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, item, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 65,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-end justify-between gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-black uppercase tracking-[0.24em] text-[#A6A6A6]",
                                                    children: "Preparación"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 79,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-black text-white",
                                                    children: "68%"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 78,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 h-2 overflow-hidden rounded-full bg-white/10",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-full w-[68%] rounded-full bg-gradient-to-r from-[#E10600] to-[#ff3b34] shadow-[0_0_20px_rgba(225,6,0,0.42)]"
                                            }, void 0, false, {
                                                fileName: "[project]/components/UnderConstruction.tsx",
                                                lineNumber: 85,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-8 border-t border-white/10 pt-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-0 top-5 h-px w-24 bg-gradient-to-r from-[#E10600]/70 to-transparent"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 90,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs font-black uppercase tracking-[0.24em] text-[#A6A6A6]",
                                            children: "Próxima salida: muy pronto"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 91,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 89,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UnderConstruction.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/UnderConstruction.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/UnderConstruction.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/slug.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/supabase.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/lib/under-construction.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isUnderConstruction",
    ()=>isUnderConstruction
]);
function isUnderConstruction() {
    return ("TURBOPACK compile-time value", "true") === "true";
}
}),
"[project]/app/evento/[slug]/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventPage,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$api$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/next/dist/api/navigation.react-server.js [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/components/navigation.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/EventBadge.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$UnderConstruction$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/UnderConstruction.tsx [app-rsc] (ecmascript)");
(()=>{
    const e = new Error("Cannot find module '@/components/brand/EventomotorLogo'");
    e.code = 'MODULE_NOT_FOUND';
    throw e;
})();
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$under$2d$construction$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/under-construction.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
function getSiteUrl() {
    const configuredUrl = ("TURBOPACK compile-time value", "https://www.eventomotor.com");
    const vercelUrl = process.env.VERCEL_URL;
    if ("TURBOPACK compile-time truthy", 1) {
        return configuredUrl.replace(/\/$/, "");
    }
    //TURBOPACK unreachable
    ;
}
async function getEventBySlug(slug) {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        return null;
    }
    const { data, error } = await supabase.from("events").select("*").eq("slug", slug).eq("visible", true).single();
    if (error || !data) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapEventRowToEventItem"])(data);
}
function buildDescription(event) {
    return `${event.title}: ${event.discipline} en ${event.venue}, ${event.city} (${event.province}), del ${event.start} al ${event.end}.`;
}
function buildJsonLd(event, url) {
    return {
        "@context": "https://schema.org",
        "@type": "SportsEvent",
        name: event.title,
        description: buildDescription(event),
        startDate: event.start,
        endDate: event.end,
        eventStatus: "https://schema.org/EventScheduled",
        eventAttendanceMode: "https://schema.org/OfflineEventAttendanceMode",
        url,
        location: {
            "@type": "Place",
            name: event.venue,
            address: {
                "@type": "PostalAddress",
                addressLocality: event.city,
                addressRegion: event.province,
                addressCountry: "ES"
            }
        },
        organizer: event.source ? {
            "@type": "Organization",
            name: event.source,
            url: event.sourceUrl || undefined
        } : undefined
    };
}
async function generateMetadata({ params }) {
    const { slug } = await params;
    const event = await getEventBySlug(slug);
    if (!event) {
        return {};
    }
    const url = `${getSiteUrl()}/evento/${event.slug || slug}`;
    const description = buildDescription(event);
    return {
        title: `${event.title} | EventoMotor`,
        description,
        alternates: {
            canonical: url
        },
        openGraph: {
            title: `${event.title} | EventoMotor`,
            description,
            url,
            siteName: "EventoMotor",
            type: "website"
        }
    };
}
async function EventPage({ params }) {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$under$2d$construction$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isUnderConstruction"])()) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$UnderConstruction$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/evento/[slug]/page.tsx",
            lineNumber: 116,
            columnNumber: 12
        }, this);
    }
    const { slug } = await params;
    const event = await getEventBySlug(slug);
    if (!event) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$navigation$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["notFound"])();
    }
    const url = `${getSiteUrl()}/evento/${event.slug || slug}`;
    const jsonLd = buildJsonLd(event, url);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-[#0D0D0F] px-4 py-6 text-white sm:px-6 lg:px-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: JSON.stringify(jsonLd)
                }
            }, void 0, false, {
                fileName: "[project]/app/evento/[slug]/page.tsx",
                lineNumber: 131,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                className: "mx-auto max-w-5xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                        className: "flex items-center justify-between border-b border-white/[0.06] pb-5",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                href: "/",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(EventomotorLogo, {
                                    markClassName: "h-10 w-10"
                                }, void 0, false, {
                                    fileName: "[project]/app/evento/[slug]/page.tsx",
                                    lineNumber: 138,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 137,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                className: "rounded-md border border-white/[0.08] bg-white/[0.035] px-3 py-2 text-sm font-semibold text-white hover:border-white/[0.16]",
                                href: "/",
                                children: "Volver al calendario"
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 140,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/evento/[slug]/page.tsx",
                        lineNumber: 136,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "relative mt-8 overflow-hidden rounded-2xl border border-white/[0.08] bg-[#15161A] p-6 shadow-[0_30px_100px_rgba(0,0,0,0.28)] sm:p-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute inset-0 bg-[radial-gradient(circle_at_80%_10%,rgba(225,6,0,0.18),transparent_35%)]"
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 149,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "relative",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "mb-4 flex flex-wrap gap-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                discipline: event.discipline
                                            }, void 0, false, {
                                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                                lineNumber: 152,
                                                columnNumber: 13
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full border border-white/[0.08] bg-white/[0.035] px-2 py-1 text-[11px] font-semibold text-zinc-300",
                                                children: event.level
                                            }, void 0, false, {
                                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                                lineNumber: 153,
                                                columnNumber: 13
                                            }, this),
                                            event.featured ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "rounded-full border border-amber-400/20 bg-amber-400/10 px-2 py-1 text-[11px] font-semibold text-amber-100",
                                                children: "Destacado"
                                            }, void 0, false, {
                                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                                lineNumber: 157,
                                                columnNumber: 15
                                            }, this) : null
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/evento/[slug]/page.tsx",
                                        lineNumber: 151,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                        className: "max-w-4xl text-4xl font-semibold leading-tight text-white sm:text-5xl",
                                        children: event.title
                                    }, void 0, false, {
                                        fileName: "[project]/app/evento/[slug]/page.tsx",
                                        lineNumber: 163,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "mt-4 max-w-3xl text-lg text-[#A6A6A6]",
                                        children: event.championship
                                    }, void 0, false, {
                                        fileName: "[project]/app/evento/[slug]/page.tsx",
                                        lineNumber: 166,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 150,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/evento/[slug]/page.tsx",
                        lineNumber: 148,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Fecha",
                                value: `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["formatRange"])(event)} de ${event.start.slice(0, 4)}`
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 171,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Disciplina",
                                value: event.discipline
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 172,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Sede",
                                value: event.venue
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 173,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Ubicacion",
                                value: `${event.city}, ${event.province}`
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 174,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Region",
                                value: event.region
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 175,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(Info, {
                                label: "Fuente",
                                value: event.source
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 176,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/evento/[slug]/page.tsx",
                        lineNumber: 170,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-6 flex flex-wrap gap-3",
                        children: [
                            event.sourceUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                className: "rounded-lg bg-white px-4 py-3 text-sm font-bold text-zinc-950 hover:bg-red-100",
                                href: event.sourceUrl,
                                rel: "noreferrer",
                                target: "_blank",
                                children: "Fuente oficial"
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 181,
                                columnNumber: 13
                            }, this) : null,
                            event.ticketUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                className: "rounded-lg border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-100 hover:border-red-400/60",
                                href: event.ticketUrl,
                                rel: "noreferrer",
                                target: "_blank",
                                children: "Entradas / info"
                            }, void 0, false, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 191,
                                columnNumber: 13
                            }, this) : null
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/evento/[slug]/page.tsx",
                        lineNumber: 179,
                        columnNumber: 9
                    }, this),
                    event.tags.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-8 flex flex-wrap gap-2",
                        children: event.tags.map((tag)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "rounded-full bg-white/5 px-3 py-1 text-sm text-zinc-400",
                                children: [
                                    "#",
                                    tag
                                ]
                            }, `${event.id}-${tag}`, true, {
                                fileName: "[project]/app/evento/[slug]/page.tsx",
                                lineNumber: 205,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/evento/[slug]/page.tsx",
                        lineNumber: 203,
                        columnNumber: 11
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/app/evento/[slug]/page.tsx",
                lineNumber: 135,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/evento/[slug]/page.tsx",
        lineNumber: 130,
        columnNumber: 5
    }, this);
}
function Info({ label, value }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "rounded-xl border border-white/[0.08] bg-[#15161A] p-4",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-[11px] font-semibold uppercase tracking-wide text-zinc-500",
                children: label
            }, void 0, false, {
                fileName: "[project]/app/evento/[slug]/page.tsx",
                lineNumber: 222,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "mt-2 text-sm font-semibold text-white",
                children: value
            }, void 0, false, {
                fileName: "[project]/app/evento/[slug]/page.tsx",
                lineNumber: 223,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/evento/[slug]/page.tsx",
        lineNumber: 221,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/evento/[slug]/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/evento/[slug]/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0pq7m60._.js.map