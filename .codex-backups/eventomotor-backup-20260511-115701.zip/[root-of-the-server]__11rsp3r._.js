module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/sources.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SOURCES",
    ()=>SOURCES,
    "SOURCE_FEEDS",
    ()=>SOURCE_FEEDS
]);
const SOURCES = {
    RFME: "https://rfme.com/calendario-campeonatos/",
    MotoGP: "https://www.motogp.com/es/calendar/2026",
    CircuitCat: "https://www.circuitcat.com/",
    MotorLand: "https://www.motorlandaragon.com/",
    RicardoTormo: "https://entradas.circuitvalencia.com/circuitvalencia/events"
};
const SOURCE_FEEDS = [
    {
        id: "rfme",
        name: "RFME",
        url: SOURCES.RFME,
        type: "Calendario oficial"
    },
    {
        id: "motogp",
        name: "MotoGP",
        url: SOURCES.MotoGP,
        type: "Calendario oficial"
    },
    {
        id: "circuitcat",
        name: "Circuit de Barcelona-Catalunya",
        url: SOURCES.CircuitCat,
        type: "Circuito"
    },
    {
        id: "motorland",
        name: "MotorLand Aragón",
        url: SOURCES.MotorLand,
        type: "Circuito"
    },
    {
        id: "ricardotormo",
        name: "Circuit Ricardo Tormo",
        url: SOURCES.RicardoTormo,
        type: "Entradas"
    }
];
}),
"[project]/lib/fallback-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FALLBACK_EVENTS",
    ()=>FALLBACK_EVENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sources.ts [app-route] (ecmascript)");
;
const FALLBACK_EVENTS = [
    {
        id: "motogp-jerez-2026",
        title: "Gran Premio de España de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-04-24",
        end: "2026-04-26",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Mundial",
        source: "MotoGP",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotoGP,
        ticketUrl: "https://www.circuitodejerez.com/",
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-catalunya-2026",
        title: "Gran Premi de Catalunya de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-05-15",
        end: "2026-05-17",
        venue: "Circuit de Barcelona-Catalunya",
        city: "Montmeló",
        province: "Barcelona",
        region: "Catalunya",
        level: "Mundial",
        source: "Circuit de Barcelona-Catalunya",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-aragon-2026",
        title: "Gran Premio de Aragón de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-08-28",
        end: "2026-08-30",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Mundial",
        source: "MotorLand Aragón",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-valencia-2026",
        title: "Gran Premio Motul de la Comunitat Valenciana",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-11-27",
        end: "2026-11-29",
        venue: "Circuit Ricardo Tormo",
        city: "Cheste",
        province: "Valencia",
        region: "Comunitat Valenciana",
        level: "Mundial",
        source: "Circuit Ricardo Tormo",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        tags: [
            "MotoGP",
            "final"
        ],
        featured: true
    },
    {
        id: "esbk-navarra-2026",
        title: "ESBK Navarra",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-05-07",
        end: "2026-05-10",
        venue: "Circuito de Navarra",
        city: "Los Arcos",
        province: "Navarra",
        region: "Navarra",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: "https://www.circuitodenavarra.com/",
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: true
    },
    {
        id: "esbk-motorland-2026",
        title: "ESBK MotorLand Aragón",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-07-16",
        end: "2026-07-19",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: false
    },
    {
        id: "copa-velocidad-jerez-2026",
        title: "Copa de España de Velocidad - Jerez",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad",
        start: "2026-05-29",
        end: "2026-05-31",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        ticketUrl: "",
        tags: [
            "velocidad"
        ],
        featured: false
    },
    {
        id: "mx-osuna-2026",
        title: "Campeonato de España de Motocross - Osuna",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-05-02",
        end: "2026-05-03",
        venue: "Circuito de Osuna",
        city: "Osuna",
        province: "Sevilla",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: "",
        tags: [
            "MX",
            "offroad"
        ],
        featured: true
    },
    {
        id: "mx-motorland-2026",
        title: "Campeonato de España de Motocross - MotorLand",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MX",
            "offroad"
        ],
        featured: false
    },
    {
        id: "trial-gironella-2026",
        title: "Campeonato de España de Trial - Gironella",
        championship: "Campeonato de España de Trial",
        discipline: "Trial",
        start: "2026-05-30",
        end: "2026-05-31",
        venue: "Gironella",
        city: "Gironella",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        ticketUrl: "",
        tags: [
            "trial"
        ],
        featured: false
    },
    {
        id: "enduro-orista-2026",
        title: "Campeonato de España de Enduro - Oristà",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "Torre d'Oristà",
        city: "Oristà",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        ticketUrl: "",
        tags: [
            "enduro"
        ],
        featured: false
    },
    {
        id: "mini-cartagena-2026",
        title: "Copa de España de MiniVelocidad - Cartagena",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad",
        start: "2026-05-01",
        end: "2026-05-03",
        venue: "Circuito de Cartagena",
        city: "Cartagena",
        province: "Murcia",
        region: "Región de Murcia",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        ticketUrl: "https://www.circuitocartagena.com/",
        tags: [
            "minivelocidad"
        ],
        featured: false
    },
    {
        id: "tour-penitentes-2026",
        title: "RFME Mototurismo Touring - Penitentes",
        championship: "RFME Mototurismo Touring Challenge",
        discipline: "Mototurismo",
        start: "2026-05-01",
        end: "2026-05-01",
        venue: "Penitentes",
        city: "Pirineo aragonés",
        province: "Huesca",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        ticketUrl: "",
        tags: [
            "mototurismo"
        ],
        featured: false
    }
];
}),
"[project]/app/api/events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fallback-events.ts [app-route] (ecmascript)");
;
async function GET() {
    const response = {
        updatedAt: new Date().toISOString(),
        events: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FALLBACK_EVENTS"]
    };
    return Response.json(response);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__11rsp3r._.js.map