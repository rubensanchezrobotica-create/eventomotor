module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.0x3dzn~oxb6tn.ico" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 256,
    height: 256
};
}),
"[project]/lib/date-utils.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_EVENTS_URL",
    ()=>API_EVENTS_URL,
    "AUTO_REFRESH_MS",
    ()=>AUTO_REFRESH_MS,
    "COLORS",
    ()=>COLORS,
    "MONTHS",
    ()=>MONTHS,
    "TODAY",
    ()=>TODAY,
    "WEEK_DAYS",
    ()=>WEEK_DAYS,
    "addDays",
    ()=>addDays,
    "cleanIcs",
    ()=>cleanIcs,
    "cls",
    ()=>cls,
    "daysForMonth",
    ()=>daysForMonth,
    "downloadCalendar",
    ()=>downloadCalendar,
    "formatRange",
    ()=>formatRange,
    "formatStatus",
    ()=>formatStatus,
    "isDateText",
    ()=>isDateText,
    "isOnDay",
    ()=>isOnDay,
    "parseDate",
    ()=>parseDate,
    "statusOf",
    ()=>statusOf,
    "toIcsDate",
    ()=>toIcsDate
]);
const API_EVENTS_URL = "/api/events";
const AUTO_REFRESH_MS = 15 * 60 * 1000;
const TODAY = new Date(2026, 3, 27);
const COLORS = {
    MotoGP: "bg-red-500 text-white border-red-300",
    Superbike: "bg-orange-500 text-white border-orange-300",
    Velocidad: "bg-amber-400 text-zinc-950 border-amber-200",
    Motocross: "bg-lime-400 text-zinc-950 border-lime-200",
    Trial: "bg-emerald-400 text-zinc-950 border-emerald-200",
    Enduro: "bg-green-500 text-white border-green-300",
    MiniVelocidad: "bg-sky-400 text-zinc-950 border-sky-200",
    Mototurismo: "bg-violet-500 text-white border-violet-300",
    Motociclismo: "bg-zinc-500 text-white border-zinc-300"
};
const MONTHS = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
];
const WEEK_DAYS = [
    "L",
    "M",
    "X",
    "J",
    "V",
    "S",
    "D"
];
function cls(...parts) {
    return parts.filter(Boolean).join(" ");
}
function parseDate(value) {
    const parts = String(value || "").slice(0, 10).split("-").map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
}
function isDateText(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "").slice(0, 10));
}
function addDays(date, days) {
    const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    copy.setDate(copy.getDate() + days);
    return copy;
}
function toIcsDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}${month}${day}`;
}
function cleanIcs(text) {
    const slash = String.fromCharCode(92);
    const newline = String.fromCharCode(10);
    return String(text || "").split(slash).join(slash + slash).split(",").join(slash + ",").split(";").join(slash + ";").split(newline).join(slash + "n");
}
function statusOf(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const today = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());
    if (end < today) return "finalizado";
    if (start <= today && end >= today) return "en directo";
    return "proximo";
}
function formatStatus(status) {
    return status === "proximo" ? "próximo" : status;
}
function formatRange(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const formatter = new Intl.DateTimeFormat("es-ES", {
        day: "numeric",
        month: "short"
    });
    if (start.toDateString() === end.toDateString()) {
        return formatter.format(start);
    }
    if (start.getMonth() === end.getMonth()) {
        const monthName = formatter.format(end).split(" ").slice(1).join(" ");
        return `${start.getDate()}-${end.getDate()} ${monthName}`;
    }
    return `${formatter.format(start)} - ${formatter.format(end)}`;
}
function isOnDay(event, day) {
    const current = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    return parseDate(event.start).getTime() <= current.getTime() && parseDate(event.end).getTime() >= current.getTime();
}
function daysForMonth(year, month) {
    const first = new Date(year, month, 1);
    const last = new Date(year, month + 1, 0);
    const offset = (first.getDay() + 6) % 7;
    const days = [];
    for(let i = offset; i > 0; i -= 1){
        days.push(addDays(first, -i));
    }
    for(let d = 1; d <= last.getDate(); d += 1){
        days.push(new Date(year, month, d));
    }
    while(days.length % 7 !== 0){
        days.push(addDays(days[days.length - 1], 1));
    }
    return days;
}
function downloadCalendar(items) {
    const lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//MotoCalendario Espana//ES"
    ];
    items.forEach((event)=>{
        const location = `${event.venue}, ${event.city}, ${event.province}`;
        const description = `${event.championship} - ${event.discipline} - Fuente: ${event.sourceUrl}`;
        lines.push("BEGIN:VEVENT");
        lines.push(`UID:${event.id}@motocalendario.es`);
        lines.push("DTSTAMP:20260427T090000Z");
        lines.push(`DTSTART;VALUE=DATE:${toIcsDate(parseDate(event.start))}`);
        lines.push(`DTEND;VALUE=DATE:${toIcsDate(addDays(parseDate(event.end), 1))}`);
        lines.push(`SUMMARY:${cleanIcs(event.title)}`);
        lines.push(`LOCATION:${cleanIcs(location)}`);
        lines.push(`DESCRIPTION:${cleanIcs(description)}`);
        lines.push("END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    const blob = new Blob([
        lines.join(String.fromCharCode(13, 10))
    ], {
        type: "text/calendar;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "moto-calendario-espana-2026.ics";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}
}),
"[project]/components/EventBadge.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-rsc] (ecmascript)");
;
;
function EventBadge({ discipline }) {
    const color = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["COLORS"][discipline] || __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["COLORS"].Motociclismo;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["cls"])("rounded-full border px-3 py-1 text-xs font-black", color),
        children: discipline
    }, void 0, false, {
        fileName: "[project]/components/EventBadge.tsx",
        lineNumber: 7,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/slug.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/event-listing-slugs.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DISCIPLINE_SLUGS",
    ()=>DISCIPLINE_SLUGS,
    "getDisciplineSlug",
    ()=>getDisciplineSlug,
    "getListingLinks",
    ()=>getListingLinks,
    "getRegionSlug",
    ()=>getRegionSlug,
    "resolveEventListing",
    ()=>resolveEventListing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
const DISCIPLINE_SLUGS = {
    motogp: "MotoGP",
    motocross: "Motocross",
    trial: "Trial",
    enduro: "Enduro",
    superbike: "Superbike",
    velocidad: "Velocidad",
    minivelocidad: "MiniVelocidad",
    mototurismo: "Mototurismo"
};
const REGION_ALIASES = {
    andalucia: [
        "andalucia",
        "andalusia"
    ],
    catalunya: [
        "catalunya",
        "cataluna",
        "catalonia"
    ],
    aragon: [
        "aragon"
    ],
    navarra: [
        "navarra"
    ],
    valencia: [
        "valencia",
        "comunitat-valenciana",
        "comunidad-valenciana"
    ],
    murcia: [
        "murcia",
        "region-de-murcia"
    ]
};
function getDisciplineSlug(name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function getRegionSlug(name) {
    const slug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
    const alias = Object.entries(REGION_ALIASES).find(([, values])=>values.includes(slug));
    return alias?.[0] || slug;
}
function sameDiscipline(event, name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(event.discipline) === (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function sameRegion(event, slug) {
    const candidates = [
        event.region,
        event.province
    ].map(getRegionSlug);
    const aliases = REGION_ALIASES[slug] || [
        slug
    ];
    return candidates.some((candidate)=>candidate === slug || aliases.includes(candidate));
}
function resolveEventListing(slug, events) {
    const normalizedSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(slug);
    const disciplineName = DISCIPLINE_SLUGS[normalizedSlug];
    if (disciplineName) {
        const listingEvents = events.filter((event)=>sameDiscipline(event, disciplineName));
        return listingEvents.length ? {
            kind: "discipline",
            slug: normalizedSlug,
            name: disciplineName,
            events: listingEvents
        } : null;
    }
    const regionEvents = events.filter((event)=>sameRegion(event, normalizedSlug));
    if (!regionEvents.length) {
        return null;
    }
    return {
        kind: "region",
        slug: normalizedSlug,
        name: regionEvents[0].region,
        events: regionEvents
    };
}
function getListingLinks(events) {
    const disciplineLinks = Object.entries(DISCIPLINE_SLUGS).map(([slug, name])=>({
            kind: "discipline",
            slug,
            name,
            count: events.filter((event)=>sameDiscipline(event, name)).length
        })).filter((link)=>link.count > 0);
    const regionMap = new Map();
    for (const event of events){
        const slug = getRegionSlug(event.region);
        const current = regionMap.get(slug);
        if (current) {
            current.count += 1;
        } else {
            regionMap.set(slug, {
                kind: "region",
                slug,
                name: event.region,
                count: 1
            });
        }
    }
    return {
        disciplines: disciplineLinks,
        regions: [
            ...regionMap.values()
        ].sort((a, b)=>a.name.localeCompare(b.name))
    };
}
}),
"[project]/lib/supabase.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/lib/sources.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SOURCES",
    ()=>SOURCES,
    "SOURCE_FEEDS",
    ()=>SOURCE_FEEDS
]);
const SOURCES = {
    RFME: "https://rfme.com/calendario-campeonatos/",
    MotoGP: "https://www.motogp.com/es/calendar/2026",
    CircuitCat: "https://www.circuitcat.com/",
    MotorLand: "https://www.motorlandaragon.com/",
    RicardoTormo: "https://entradas.circuitvalencia.com/circuitvalencia/events"
};
const SOURCE_FEEDS = [
    {
        id: "rfme",
        name: "RFME",
        url: SOURCES.RFME,
        type: "Calendario oficial"
    },
    {
        id: "motogp",
        name: "MotoGP",
        url: SOURCES.MotoGP,
        type: "Calendario oficial"
    },
    {
        id: "circuitcat",
        name: "Circuit de Barcelona-Catalunya",
        url: SOURCES.CircuitCat,
        type: "Circuito"
    },
    {
        id: "motorland",
        name: "MotorLand Aragón",
        url: SOURCES.MotorLand,
        type: "Circuito"
    },
    {
        id: "ricardotormo",
        name: "Circuit Ricardo Tormo",
        url: SOURCES.RicardoTormo,
        type: "Entradas"
    }
];
}),
"[project]/lib/fallback-events.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FALLBACK_EVENTS",
    ()=>FALLBACK_EVENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sources.ts [app-rsc] (ecmascript)");
;
const FALLBACK_EVENTS = [
    {
        id: "motogp-jerez-2026",
        title: "Gran Premio de España de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-04-24",
        end: "2026-04-26",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Mundial",
        source: "MotoGP",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotoGP,
        ticketUrl: "https://www.circuitodejerez.com/",
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-catalunya-2026",
        title: "Gran Premi de Catalunya de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-05-15",
        end: "2026-05-17",
        venue: "Circuit de Barcelona-Catalunya",
        city: "Montmeló",
        province: "Barcelona",
        region: "Catalunya",
        level: "Mundial",
        source: "Circuit de Barcelona-Catalunya",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-aragon-2026",
        title: "Gran Premio de Aragón de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-08-28",
        end: "2026-08-30",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Mundial",
        source: "MotorLand Aragón",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-valencia-2026",
        title: "Gran Premio Motul de la Comunitat Valenciana",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-11-27",
        end: "2026-11-29",
        venue: "Circuit Ricardo Tormo",
        city: "Cheste",
        province: "Valencia",
        region: "Comunitat Valenciana",
        level: "Mundial",
        source: "Circuit Ricardo Tormo",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        tags: [
            "MotoGP",
            "final"
        ],
        featured: true
    },
    {
        id: "esbk-navarra-2026",
        title: "ESBK Navarra",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-05-07",
        end: "2026-05-10",
        venue: "Circuito de Navarra",
        city: "Los Arcos",
        province: "Navarra",
        region: "Navarra",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: "https://www.circuitodenavarra.com/",
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: true
    },
    {
        id: "esbk-motorland-2026",
        title: "ESBK MotorLand Aragón",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-07-16",
        end: "2026-07-19",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: false
    },
    {
        id: "copa-velocidad-jerez-2026",
        title: "Copa de España de Velocidad - Jerez",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad",
        start: "2026-05-29",
        end: "2026-05-31",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        ticketUrl: "",
        tags: [
            "velocidad"
        ],
        featured: false
    },
    {
        id: "mx-osuna-2026",
        title: "Campeonato de España de Motocross - Osuna",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-05-02",
        end: "2026-05-03",
        venue: "Circuito de Osuna",
        city: "Osuna",
        province: "Sevilla",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: "",
        tags: [
            "MX",
            "offroad"
        ],
        featured: true
    },
    {
        id: "mx-motorland-2026",
        title: "Campeonato de España de Motocross - MotorLand",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MX",
            "offroad"
        ],
        featured: false
    },
    {
        id: "trial-gironella-2026",
        title: "Campeonato de España de Trial - Gironella",
        championship: "Campeonato de España de Trial",
        discipline: "Trial",
        start: "2026-05-30",
        end: "2026-05-31",
        venue: "Gironella",
        city: "Gironella",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        ticketUrl: "",
        tags: [
            "trial"
        ],
        featured: false
    },
    {
        id: "enduro-orista-2026",
        title: "Campeonato de España de Enduro - Oristà",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "Torre d'Oristà",
        city: "Oristà",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        ticketUrl: "",
        tags: [
            "enduro"
        ],
        featured: false
    },
    {
        id: "mini-cartagena-2026",
        title: "Copa de España de MiniVelocidad - Cartagena",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad",
        start: "2026-05-01",
        end: "2026-05-03",
        venue: "Circuito de Cartagena",
        city: "Cartagena",
        province: "Murcia",
        region: "Región de Murcia",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        ticketUrl: "https://www.circuitocartagena.com/",
        tags: [
            "minivelocidad"
        ],
        featured: false
    },
    {
        id: "tour-penitentes-2026",
        title: "RFME Mototurismo Touring - Penitentes",
        championship: "RFME Mototurismo Touring Challenge",
        discipline: "Mototurismo",
        start: "2026-05-01",
        end: "2026-05-01",
        venue: "Penitentes",
        city: "Pirineo aragonés",
        province: "Huesca",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        ticketUrl: "",
        tags: [
            "mototurismo"
        ],
        featured: false
    }
];
}),
"[project]/lib/public-events.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVisibleEvents",
    ()=>getVisibleEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fallback-events.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
;
;
function fallbackVisibleEvents() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["FALLBACK_EVENTS"].filter((event)=>event.visible !== false).map((event)=>({
            ...event,
            slug: event.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEventSlug"])(event.title, event.start)
        }));
}
async function getVisibleEvents() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        return fallbackVisibleEvents();
    }
    const { data, error } = await supabase.from("events").select("*").eq("visible", true).order("start_date", {
        ascending: true
    });
    if (error || !data) {
        return fallbackVisibleEvents();
    }
    const events = data.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapEventRowToEventItem"]);
    return events.length ? events : fallbackVisibleEvents();
}
}),
"[project]/lib/site-url.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSiteUrl",
    ()=>getSiteUrl
]);
function getSiteUrl() {
    const configuredUrl = ("TURBOPACK compile-time value", "https://www.eventomotor.com");
    const vercelUrl = process.env.VERCEL_URL;
    if ("TURBOPACK compile-time truthy", 1) {
        return configuredUrl.replace(/\/$/, "");
    }
    //TURBOPACK unreachable
    ;
}
}),
"[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventosMotoPage,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/EventBadge.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-listing-slugs.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/public-events.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/site-url.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
async function generateMetadata() {
    const url = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSiteUrl"])()}/eventos-moto`;
    const description = "Calendario de eventos de motociclismo en Espana por disciplina y region: MotoGP, motocross, trial, enduro, superbike y mas.";
    return {
        title: "Eventos de moto en Espana | EventoMotor",
        description,
        alternates: {
            canonical: url
        },
        openGraph: {
            title: "Eventos de moto en Espana | EventoMotor",
            description,
            url,
            siteName: "EventoMotor",
            type: "website"
        }
    };
}
async function EventosMotoPage() {
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getVisibleEvents"])();
    const links = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getListingLinks"])(events);
    const siteUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSiteUrl"])();
    const itemList = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        name: "Eventos de moto en Espana",
        itemListElement: events.map((event, index)=>({
                "@type": "ListItem",
                position: index + 1,
                name: event.title,
                url: `${siteUrl}/evento/${event.slug}`
            }))
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-zinc-950 px-4 py-8 text-white sm:px-6 lg:px-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: JSON.stringify(itemList)
                }
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-6xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-sm font-bold text-orange-200 hover:text-orange-100",
                        href: "/",
                        children: "Volver al calendario"
                    }, void 0, false, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 52,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "mt-8 border-b border-white/10 pb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-bold uppercase tracking-widest text-orange-200",
                                children: "EventoMotor"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 57,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "mt-3 text-4xl font-black leading-tight sm:text-6xl",
                                children: "Eventos de moto en Espana"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 60,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-4 max-w-3xl text-lg leading-8 text-zinc-300",
                                children: "Listados SEO de eventos visibles por disciplina y region, con fichas indexables para cada prueba."
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 56,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-8 grid gap-4 md:grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ListingGroup, {
                                title: "Por disciplina",
                                items: links.disciplines
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 70,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ListingGroup, {
                                title: "Por region",
                                items: links.regions
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 71,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 69,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-black",
                                children: "Ultimos eventos visibles"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 75,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 grid gap-3 md:grid-cols-2",
                                children: events.slice(0, 12).map((event)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        className: "rounded-2xl border border-white/10 bg-white/5 p-4 hover:bg-white/10",
                                        href: `/evento/${event.slug}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-2",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    discipline: event.discipline
                                                }, void 0, false, {
                                                    fileName: "[project]/app/eventos-moto/page.tsx",
                                                    lineNumber: 84,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 83,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-black text-white",
                                                children: event.title
                                            }, void 0, false, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 86,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-zinc-400",
                                                children: [
                                                    event.start,
                                                    " - ",
                                                    event.city,
                                                    ", ",
                                                    event.province
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 87,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, event.id, true, {
                                        fileName: "[project]/app/eventos-moto/page.tsx",
                                        lineNumber: 78,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 74,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 51,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/eventos-moto/page.tsx",
        lineNumber: 46,
        columnNumber: 5
    }, this);
}
function ListingGroup({ title, items }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-white/10 bg-white/5 p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-black",
                children: title
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 108,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 flex flex-wrap gap-2",
                children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        className: "rounded-full border border-white/10 bg-black/20 px-3 py-2 text-sm font-bold text-zinc-200 hover:bg-white/10",
                        href: `/eventos-moto/${item.slug}`,
                        children: [
                            item.name,
                            " (",
                            item.count,
                            ")"
                        ]
                    }, item.slug, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 111,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 109,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/eventos-moto/page.tsx",
        lineNumber: 107,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__01dxhlj._.js.map