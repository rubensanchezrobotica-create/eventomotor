module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/sources.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SOURCES",
    ()=>SOURCES,
    "SOURCE_FEEDS",
    ()=>SOURCE_FEEDS
]);
const SOURCES = {
    RFME: "https://rfme.com/calendario-campeonatos/",
    MotoGP: "https://www.motogp.com/es/calendar/2026",
    CircuitCat: "https://www.circuitcat.com/",
    MotorLand: "https://www.motorlandaragon.com/",
    RicardoTormo: "https://entradas.circuitvalencia.com/circuitvalencia/events"
};
const SOURCE_FEEDS = [
    {
        id: "rfme",
        name: "RFME",
        url: SOURCES.RFME,
        type: "Calendario oficial"
    },
    {
        id: "motogp",
        name: "MotoGP",
        url: SOURCES.MotoGP,
        type: "Calendario oficial"
    },
    {
        id: "circuitcat",
        name: "Circuit de Barcelona-Catalunya",
        url: SOURCES.CircuitCat,
        type: "Circuito"
    },
    {
        id: "motorland",
        name: "MotorLand Aragón",
        url: SOURCES.MotorLand,
        type: "Circuito"
    },
    {
        id: "ricardotormo",
        name: "Circuit Ricardo Tormo",
        url: SOURCES.RicardoTormo,
        type: "Entradas"
    }
];
}),
"[project]/lib/fallback-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FALLBACK_EVENTS",
    ()=>FALLBACK_EVENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sources.ts [app-route] (ecmascript)");
;
const FALLBACK_EVENTS = [
    {
        id: "motogp-jerez-2026",
        title: "Gran Premio de España de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-04-24",
        end: "2026-04-26",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Mundial",
        source: "MotoGP",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotoGP,
        ticketUrl: "https://www.circuitodejerez.com/",
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-catalunya-2026",
        title: "Gran Premi de Catalunya de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-05-15",
        end: "2026-05-17",
        venue: "Circuit de Barcelona-Catalunya",
        city: "Montmeló",
        province: "Barcelona",
        region: "Catalunya",
        level: "Mundial",
        source: "Circuit de Barcelona-Catalunya",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-aragon-2026",
        title: "Gran Premio de Aragón de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-08-28",
        end: "2026-08-30",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Mundial",
        source: "MotorLand Aragón",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-valencia-2026",
        title: "Gran Premio Motul de la Comunitat Valenciana",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-11-27",
        end: "2026-11-29",
        venue: "Circuit Ricardo Tormo",
        city: "Cheste",
        province: "Valencia",
        region: "Comunitat Valenciana",
        level: "Mundial",
        source: "Circuit Ricardo Tormo",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        tags: [
            "MotoGP",
            "final"
        ],
        featured: true
    },
    {
        id: "esbk-navarra-2026",
        title: "ESBK Navarra",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-05-07",
        end: "2026-05-10",
        venue: "Circuito de Navarra",
        city: "Los Arcos",
        province: "Navarra",
        region: "Navarra",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: "https://www.circuitodenavarra.com/",
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: true
    },
    {
        id: "esbk-motorland-2026",
        title: "ESBK MotorLand Aragón",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-07-16",
        end: "2026-07-19",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: false
    },
    {
        id: "copa-velocidad-jerez-2026",
        title: "Copa de España de Velocidad - Jerez",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad",
        start: "2026-05-29",
        end: "2026-05-31",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        ticketUrl: "",
        tags: [
            "velocidad"
        ],
        featured: false
    },
    {
        id: "mx-osuna-2026",
        title: "Campeonato de España de Motocross - Osuna",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-05-02",
        end: "2026-05-03",
        venue: "Circuito de Osuna",
        city: "Osuna",
        province: "Sevilla",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: "",
        tags: [
            "MX",
            "offroad"
        ],
        featured: true
    },
    {
        id: "mx-motorland-2026",
        title: "Campeonato de España de Motocross - MotorLand",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MX",
            "offroad"
        ],
        featured: false
    },
    {
        id: "trial-gironella-2026",
        title: "Campeonato de España de Trial - Gironella",
        championship: "Campeonato de España de Trial",
        discipline: "Trial",
        start: "2026-05-30",
        end: "2026-05-31",
        venue: "Gironella",
        city: "Gironella",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        ticketUrl: "",
        tags: [
            "trial"
        ],
        featured: false
    },
    {
        id: "enduro-orista-2026",
        title: "Campeonato de España de Enduro - Oristà",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "Torre d'Oristà",
        city: "Oristà",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        ticketUrl: "",
        tags: [
            "enduro"
        ],
        featured: false
    },
    {
        id: "mini-cartagena-2026",
        title: "Copa de España de MiniVelocidad - Cartagena",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad",
        start: "2026-05-01",
        end: "2026-05-03",
        venue: "Circuito de Cartagena",
        city: "Cartagena",
        province: "Murcia",
        region: "Región de Murcia",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        ticketUrl: "https://www.circuitocartagena.com/",
        tags: [
            "minivelocidad"
        ],
        featured: false
    },
    {
        id: "tour-penitentes-2026",
        title: "RFME Mototurismo Touring - Penitentes",
        championship: "RFME Mototurismo Touring Challenge",
        discipline: "Mototurismo",
        start: "2026-05-01",
        end: "2026-05-01",
        venue: "Penitentes",
        city: "Pirineo aragonés",
        province: "Huesca",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        ticketUrl: "",
        tags: [
            "mototurismo"
        ],
        featured: false
    }
];
}),
"[project]/lib/event-classification.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEHICLE_TYPE_LABELS",
    ()=>VEHICLE_TYPE_LABELS,
    "VEHICLE_TYPE_OPTIONS",
    ()=>VEHICLE_TYPE_OPTIONS,
    "getVehicleType",
    ()=>getVehicleType,
    "matchesVehicleFilter",
    ()=>matchesVehicleFilter
]);
const VEHICLE_TYPE_OPTIONS = [
    "moto",
    "coche",
    "mixto",
    "karting",
    "otros"
];
const VEHICLE_TYPE_LABELS = {
    moto: "Moto",
    coche: "Coche",
    mixto: "Mixto",
    karting: "Karting",
    otros: "Otros"
};
const MOTO_TERMS = [
    "fim",
    "fim world championship",
    "fim juniorgp",
    "fim europe",
    "fim enduro",
    "fim motocross",
    "fim trial",
    "fim supermoto",
    "fim minivelocidad",
    "fim moto",
    "rfme",
    "motogp",
    "superbike",
    "esbk",
    "motocross",
    "enduro",
    "trial",
    "supermoto",
    "minivelocidad",
    "mototurismo",
    "motociclismo",
    "moto",
    "moto-ocasion",
    "concentracionesdemotos",
    "concentracion motera",
    "concentracion de motos",
    "motos",
    "motera",
    "moteras",
    "motero",
    "moteros",
    "motoristas",
    "motoalmuerzo",
    "matinal motera",
    "ruta motera",
    "biker",
    "bikers",
    "motoclub",
    "harley",
    "vespa",
    "scooter",
    "custom",
    "tandas para motos",
    "worldsbk",
    "juniorgp"
];
const COCHE_TERMS = [
    "automovilismo",
    "gt winter series",
    "racing weekend",
    "rfeda",
    "rally",
    "rallye",
    "rallysprint",
    "drift",
    "tuning",
    "4x4",
    "coches",
    "turismos",
    "gt",
    "subida",
    "montana",
    "trackday coche",
    "todoterreno"
];
const KARTING_TERMS = [
    "karting",
    "kart"
];
const MIXTO_TERMS = [
    "coches y motos clasicos",
    "coches y motos",
    "vehiculos clasicos",
    "vehiculos clasicos y tuneados",
    "coches clasicos",
    "retro matinal clasicos",
    "concentracion de vehiculos"
];
function normalizeText(value) {
    return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function isVehicleType(value) {
    return Boolean(value && VEHICLE_TYPE_OPTIONS.includes(value));
}
function includesAny(text, terms) {
    return terms.some((term)=>{
        const normalizedTerm = normalizeText(term);
        if (/^[a-z0-9]+$/.test(normalizedTerm)) {
            return new RegExp(`(^|[^a-z0-9])${normalizedTerm}([^a-z0-9]|$)`).test(text);
        }
        return text.includes(normalizedTerm);
    });
}
function hasAll(text, terms) {
    return terms.every((term)=>text.includes(term));
}
function getVehicleType(event) {
    const explicitType = normalizeText(String(event.vehicleType || event.vehicle_type || "").trim());
    const titleText = normalizeText(String(event.title || ""));
    const tagsText = normalizeText(Array.isArray(event.tags) ? event.tags.join(" ") : "");
    const sourceText = normalizeText(String(event.source || ""));
    const searchableText = normalizeText([
        event.title,
        event.championship,
        event.discipline,
        event.source,
        tagsText
    ].filter(Boolean).join(" "));
    const isKarting = includesAny(searchableText, KARTING_TERMS);
    const isCanalDifusionMixed = sourceText.includes("canal difusion") && hasAll(tagsText, [
        "coches",
        "motos",
        "clasicos"
    ]);
    const isMixto = includesAny(`${titleText} ${tagsText}`, MIXTO_TERMS) || isCanalDifusionMixed;
    const isMoto = includesAny(searchableText, MOTO_TERMS);
    const isCoche = includesAny(searchableText, COCHE_TERMS);
    if (isVehicleType(explicitType)) {
        if (explicitType === "moto" && isCoche && !isMoto) return "coche";
        if (explicitType === "coche" && isMoto && !isCoche) return "moto";
        return explicitType;
    }
    if (isKarting) return "karting";
    if (isMixto) return "mixto";
    if (isCoche) return "coche";
    if (isMoto) return "moto";
    return "otros";
}
function matchesVehicleFilter(event, filter) {
    if (filter === "todos") {
        return true;
    }
    const vehicleType = getVehicleType(event);
    return vehicleType === filter || vehicleType === "mixto";
}
}),
"[project]/lib/slug.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-classification.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    const vehicleType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getVehicleType"])({
        title: row.title,
        championship: row.championship || undefined,
        discipline: row.discipline || undefined,
        tags: row.tags || undefined,
        source: row.source || undefined,
        vehicle_type: row.vehicle_type
    });
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        vehicleType,
        vehicle_type: vehicleType,
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/app/api/events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fallback-events.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
;
;
function fallbackResponse() {
    return {
        updatedAt: new Date().toISOString(),
        events: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["FALLBACK_EVENTS"]
    };
}
async function GET() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        return Response.json(fallbackResponse());
    }
    try {
        const { data, error } = await supabase.from("events").select("*").eq("visible", true).order("start_date", {
            ascending: true
        });
        if (error || !data?.length) {
            return Response.json(fallbackResponse());
        }
        const rows = data;
        const events = rows.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mapEventRowToEventItem"]);
        const updatedAt = rows.reduce((latest, row)=>{
            return row.updated_at > latest ? row.updated_at : latest;
        }, rows[0].updated_at);
        return Response.json({
            updatedAt,
            events
        });
    } catch  {
        return Response.json(fallbackResponse());
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__08a7770._.js.map