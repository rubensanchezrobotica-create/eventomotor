module.exports = [
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[project]/lib/date-utils.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "API_EVENTS_URL",
    ()=>API_EVENTS_URL,
    "AUTO_REFRESH_MS",
    ()=>AUTO_REFRESH_MS,
    "COLORS",
    ()=>COLORS,
    "DISCIPLINE_COLORS",
    ()=>DISCIPLINE_COLORS,
    "MONTHS",
    ()=>MONTHS,
    "TODAY",
    ()=>TODAY,
    "WEEK_DAYS",
    ()=>WEEK_DAYS,
    "addDays",
    ()=>addDays,
    "cleanIcs",
    ()=>cleanIcs,
    "cls",
    ()=>cls,
    "daysForMonth",
    ()=>daysForMonth,
    "downloadCalendar",
    ()=>downloadCalendar,
    "formatRange",
    ()=>formatRange,
    "formatStatus",
    ()=>formatStatus,
    "getDisciplineColor",
    ()=>getDisciplineColor,
    "isDateText",
    ()=>isDateText,
    "isOnDay",
    ()=>isOnDay,
    "parseDate",
    ()=>parseDate,
    "statusOf",
    ()=>statusOf,
    "toIcsDate",
    ()=>toIcsDate
]);
const API_EVENTS_URL = "/api/events";
const AUTO_REFRESH_MS = 15 * 60 * 1000;
const TODAY = new Date();
const COLORS = {
    MotoGP: "bg-red-500 text-white border-red-300",
    Superbike: "bg-orange-500 text-white border-orange-300",
    Velocidad: "bg-amber-400 text-zinc-950 border-amber-200",
    Motocross: "bg-lime-400 text-zinc-950 border-lime-200",
    Trial: "bg-emerald-400 text-zinc-950 border-emerald-200",
    Enduro: "bg-green-500 text-white border-green-300",
    MiniVelocidad: "bg-sky-400 text-zinc-950 border-sky-200",
    Mototurismo: "bg-violet-500 text-white border-violet-300",
    Motociclismo: "bg-zinc-500 text-white border-zinc-300"
};
const DISCIPLINE_COLORS = {
    MotoGP: {
        name: "rojo",
        accent: "#E10600",
        badge: "border-red-500/25 bg-red-500/10 text-red-100",
        calendar: "border-l-red-500 bg-red-500/[0.08] text-red-50",
        dot: "bg-red-500"
    },
    Superbike: {
        name: "naranja",
        accent: "#F97316",
        badge: "border-orange-400/25 bg-orange-400/10 text-orange-100",
        calendar: "border-l-orange-400 bg-orange-400/[0.08] text-orange-50",
        dot: "bg-orange-400"
    },
    Velocidad: {
        name: "ambar",
        accent: "#F59E0B",
        badge: "border-amber-400/25 bg-amber-400/10 text-amber-100",
        calendar: "border-l-amber-400 bg-amber-400/[0.08] text-amber-50",
        dot: "bg-amber-400"
    },
    Motocross: {
        name: "verde lima",
        accent: "#A3E635",
        badge: "border-lime-400/25 bg-lime-400/10 text-lime-100",
        calendar: "border-l-lime-400 bg-lime-400/[0.08] text-lime-50",
        dot: "bg-lime-400"
    },
    Enduro: {
        name: "verde",
        accent: "#22C55E",
        badge: "border-green-400/25 bg-green-400/10 text-green-100",
        calendar: "border-l-green-400 bg-green-400/[0.08] text-green-50",
        dot: "bg-green-400"
    },
    Trial: {
        name: "turquesa",
        accent: "#2DD4BF",
        badge: "border-teal-400/25 bg-teal-400/10 text-teal-100",
        calendar: "border-l-teal-400 bg-teal-400/[0.08] text-teal-50",
        dot: "bg-teal-400"
    },
    Mototurismo: {
        name: "violeta",
        accent: "#A78BFA",
        badge: "border-violet-400/25 bg-violet-400/10 text-violet-100",
        calendar: "border-l-violet-400 bg-violet-400/[0.08] text-violet-50",
        dot: "bg-violet-400"
    },
    MiniVelocidad: {
        name: "cyan",
        accent: "#22D3EE",
        badge: "border-cyan-400/25 bg-cyan-400/10 text-cyan-100",
        calendar: "border-l-cyan-400 bg-cyan-400/[0.08] text-cyan-50",
        dot: "bg-cyan-400"
    },
    Supermoto: {
        name: "fucsia",
        accent: "#E879F9",
        badge: "border-fuchsia-400/25 bg-fuchsia-400/10 text-fuchsia-100",
        calendar: "border-l-fuchsia-400 bg-fuchsia-400/[0.08] text-fuchsia-50",
        dot: "bg-fuchsia-400"
    },
    "Cross Country": {
        name: "esmeralda",
        accent: "#34D399",
        badge: "border-emerald-400/25 bg-emerald-400/10 text-emerald-100",
        calendar: "border-l-emerald-400 bg-emerald-400/[0.08] text-emerald-50",
        dot: "bg-emerald-400"
    },
    Freestyle: {
        name: "rosa",
        accent: "#F472B6",
        badge: "border-pink-400/25 bg-pink-400/10 text-pink-100",
        calendar: "border-l-pink-400 bg-pink-400/[0.08] text-pink-50",
        dot: "bg-pink-400"
    },
    "Hard Enduro": {
        name: "verde oscuro",
        accent: "#16A34A",
        badge: "border-green-600/25 bg-green-600/10 text-green-100",
        calendar: "border-l-green-600 bg-green-600/[0.08] text-green-50",
        dot: "bg-green-600"
    },
    Motociclismo: {
        name: "gris",
        accent: "#A1A1AA",
        badge: "border-white/[0.08] bg-white/[0.035] text-zinc-200",
        calendar: "border-l-zinc-500 bg-white/[0.035] text-zinc-100",
        dot: "bg-zinc-400"
    }
};
function getDisciplineColor(discipline) {
    return DISCIPLINE_COLORS[discipline] || DISCIPLINE_COLORS.Motociclismo;
}
const MONTHS = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre"
];
const WEEK_DAYS = [
    "L",
    "M",
    "X",
    "J",
    "V",
    "S",
    "D"
];
function cls(...parts) {
    return parts.filter(Boolean).join(" ");
}
function parseDate(value) {
    const parts = String(value || "").slice(0, 10).split("-").map(Number);
    return new Date(parts[0], parts[1] - 1, parts[2]);
}
function isDateText(value) {
    return /^\d{4}-\d{2}-\d{2}$/.test(String(value || "").slice(0, 10));
}
function addDays(date, days) {
    const copy = new Date(date.getFullYear(), date.getMonth(), date.getDate());
    copy.setDate(copy.getDate() + days);
    return copy;
}
function toIcsDate(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    return `${year}${month}${day}`;
}
function cleanIcs(text) {
    const slash = String.fromCharCode(92);
    const newline = String.fromCharCode(10);
    return String(text || "").split(slash).join(slash + slash).split(",").join(slash + ",").split(";").join(slash + ";").split(newline).join(slash + "n");
}
function statusOf(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const today = new Date(TODAY.getFullYear(), TODAY.getMonth(), TODAY.getDate());
    if (end < today) return "finalizado";
    if (start <= today && end >= today) return "en directo";
    return "proximo";
}
function formatStatus(status) {
    return status === "proximo" ? "próximo" : status;
}
function formatRange(event) {
    const start = parseDate(event.start);
    const end = parseDate(event.end);
    const formatter = new Intl.DateTimeFormat("es-ES", {
        day: "numeric",
        month: "short"
    });
    if (start.toDateString() === end.toDateString()) {
        return formatter.format(start);
    }
    if (start.getMonth() === end.getMonth()) {
        const monthName = formatter.format(end).split(" ").slice(1).join(" ");
        return `${start.getDate()}-${end.getDate()} ${monthName}`;
    }
    return `${formatter.format(start)} - ${formatter.format(end)}`;
}
function isOnDay(event, day) {
    const current = new Date(day.getFullYear(), day.getMonth(), day.getDate());
    return parseDate(event.start).getTime() <= current.getTime() && parseDate(event.end).getTime() >= current.getTime();
}
function daysForMonth(year, month) {
    const first = new Date(year, month, 1);
    const last = new Date(year, month + 1, 0);
    const offset = (first.getDay() + 6) % 7;
    const days = [];
    for(let i = offset; i > 0; i -= 1){
        days.push(addDays(first, -i));
    }
    for(let d = 1; d <= last.getDate(); d += 1){
        days.push(new Date(year, month, d));
    }
    while(days.length % 7 !== 0){
        days.push(addDays(days[days.length - 1], 1));
    }
    return days;
}
function downloadCalendar(items) {
    const lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//EventoMotor//ES"
    ];
    items.forEach((event)=>{
        const location = `${event.venue}, ${event.city}, ${event.province}`;
        const description = `${event.championship} - ${event.discipline} - Fuente: ${event.sourceUrl}`;
        lines.push("BEGIN:VEVENT");
        lines.push(`UID:${event.id}@eventomotor.com`);
        lines.push("DTSTAMP:20260427T090000Z");
        lines.push(`DTSTART;VALUE=DATE:${toIcsDate(parseDate(event.start))}`);
        lines.push(`DTEND;VALUE=DATE:${toIcsDate(addDays(parseDate(event.end), 1))}`);
        lines.push(`SUMMARY:${cleanIcs(event.title)}`);
        lines.push(`LOCATION:${cleanIcs(location)}`);
        lines.push(`DESCRIPTION:${cleanIcs(description)}`);
        lines.push("END:VEVENT");
    });
    lines.push("END:VCALENDAR");
    const blob = new Blob([
        lines.join(String.fromCharCode(13, 10))
    ], {
        type: "text/calendar;charset=utf-8"
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "eventomotor-calendario-2026.ics";
    document.body.appendChild(link);
    link.click();
    link.remove();
    URL.revokeObjectURL(url);
}
}),
"[project]/lib/slug.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/components/public/concept/concept-model.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "INTENT_DEFINITIONS",
    ()=>INTENT_DEFINITIONS,
    "ZONE_DEFINITIONS",
    ()=>ZONE_DEFINITIONS,
    "buildIntents",
    ()=>buildIntents,
    "buildZones",
    ()=>buildZones,
    "dayLabel",
    ()=>dayLabel,
    "eventHref",
    ()=>eventHref,
    "eventLine",
    ()=>eventLine,
    "eventText",
    ()=>eventText,
    "matchesTerms",
    ()=>matchesTerms,
    "unique",
    ()=>unique
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-ssr] (ecmascript)");
;
;
const ZONE_DEFINITIONS = [
    {
        name: "Norte",
        x: 260,
        y: 172,
        color: "var(--emc-blue)",
        terms: [
            "galicia",
            "asturias",
            "cantabria",
            "país vasco",
            "pais vasco",
            "navarra",
            "la rioja",
            "león",
            "leon",
            "burgos"
        ]
    },
    {
        name: "Centro",
        x: 462,
        y: 306,
        color: "var(--emc-orange)",
        terms: [
            "madrid",
            "castilla-la mancha",
            "castilla y león",
            "castilla y leon",
            "toledo",
            "guadalajara",
            "cuenca",
            "segovia",
            "avila",
            "ávila"
        ]
    },
    {
        name: "Cataluña / Aragón",
        x: 680,
        y: 214,
        color: "var(--emc-orange)",
        terms: [
            "cataluña",
            "catalunya",
            "cataluna",
            "aragón",
            "aragon",
            "barcelona",
            "girona",
            "lleida",
            "tarragona",
            "zaragoza",
            "huesca",
            "teruel"
        ]
    },
    {
        name: "Levante",
        x: 665,
        y: 410,
        color: "var(--emc-purple)",
        terms: [
            "comunidad valenciana",
            "valencia",
            "alicante",
            "castellón",
            "castellon",
            "murcia",
            "baleares",
            "illes balears",
            "mallorca"
        ]
    },
    {
        name: "Sur",
        x: 405,
        y: 468,
        color: "var(--emc-green)",
        terms: [
            "andalucía",
            "andalucia",
            "extremadura",
            "sevilla",
            "cádiz",
            "cadiz",
            "málaga",
            "malaga",
            "granada",
            "córdoba",
            "cordoba",
            "huelva",
            "almería",
            "almeria",
            "jaén",
            "jaen",
            "badajoz",
            "cáceres",
            "caceres"
        ]
    },
    {
        name: "Canarias",
        x: 312,
        y: 556,
        color: "var(--emc-green)",
        terms: [
            "canarias",
            "tenerife",
            "gran canaria",
            "palmas",
            "santa cruz"
        ]
    }
];
const INTENT_DEFINITIONS = [
    {
        label: "Quiero rodar",
        short: "Rodar",
        terms: [
            "trackday",
            "trackdays",
            "tandas",
            "velocidad",
            "minivelocidad"
        ],
        color: "var(--emc-orange)"
    },
    {
        label: "Quiero ruta",
        short: "Ruta",
        terms: [
            "ruta",
            "rutas",
            "mototurismo",
            "turismo"
        ],
        color: "var(--emc-blue)"
    },
    {
        label: "Quiero show",
        short: "Ver show",
        terms: [
            "feria",
            "ferias",
            "concentración",
            "concentracion",
            "concentraciones",
            "clásicos",
            "clasicos",
            "exhibición",
            "exhibicion"
        ],
        color: "var(--emc-purple)"
    },
    {
        label: "Quiero tierra",
        short: "Tierra",
        terms: [
            "enduro",
            "motocross",
            "trial",
            "cross country",
            "hard enduro",
            "offroad"
        ],
        color: "var(--emc-green)"
    }
];
function eventText(event) {
    return [
        event.title,
        event.championship,
        event.discipline,
        event.venue,
        event.city,
        event.province,
        event.region,
        event.tags.join(" ")
    ].join(" ").toLowerCase();
}
function unique(values) {
    return Array.from(new Set(values.filter(Boolean))).sort((a, b)=>a.localeCompare(b, "es"));
}
function matchesTerms(event, terms) {
    const text = eventText(event);
    return terms.some((term)=>text.includes(term.toLowerCase()));
}
function buildZones(events) {
    return ZONE_DEFINITIONS.map((zone)=>{
        const zoneEvents = events.filter((event)=>matchesTerms(event, zone.terms));
        return {
            ...zone,
            events: zoneEvents,
            upcoming: zoneEvents.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["statusOf"])(event) !== "finalizado"),
            provinces: unique(zoneEvents.map((event)=>event.province))
        };
    }).filter((zone)=>zone.events.length > 0);
}
function buildIntents(events) {
    return INTENT_DEFINITIONS.map((intent)=>({
            ...intent,
            events: events.filter((event)=>matchesTerms(event, intent.terms))
        }));
}
function eventHref(event) {
    return `/evento/${event.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createEventSlug"])(event.title, event.start)}`;
}
function dayLabel(event) {
    const date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(event.start);
    return {
        day: String(date.getDate()),
        month: new Intl.DateTimeFormat("es-ES", {
            month: "short"
        }).format(date).replace(".", "").toUpperCase()
    };
}
function eventLine(event) {
    return `${event.city} / ${event.province} / ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatRange"])(event)}`;
}
}),
"[project]/components/public/concept/ConceptCalendar.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptCalendar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/concept-model.ts [app-ssr] (ecmascript)");
;
;
;
;
const VEHICLE_FILTERS = [
    {
        id: "todos",
        label: "Todos"
    },
    {
        id: "moto",
        label: "Motos"
    },
    {
        id: "coche",
        label: "Coches"
    }
];
function ConceptCalendar({ year, month, setMonth, days, agendaDay, selectedDayEvents, fallbackEvents, monthEventCount, monthDisciplineCount, filtered, activeLabel, hasActiveFilters, query, discipline, zone, vehicleFilter, disciplines, zones, setQuery, setDiscipline, onVehicle, onZoneSelect, onThisMonth, onDay, onClearFilters }) {
    const fallbackAgenda = fallbackEvents.slice(0, 3);
    const dateLabel = new Intl.DateTimeFormat("es-ES", {
        day: "numeric",
        month: "long"
    }).format(agendaDay);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "emc-calendar-embed",
        id: "calendario-vista",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-calendar-wrap",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "emc-panel emc-calendar-panel",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-filter-status",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "emc-filter-status-head",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "emc-kicker",
                                                    children: "Calendario"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 83,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: activeLabel
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 84,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: [
                                                        filtered.length,
                                                        " próximos eventos."
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 85,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 82,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-calendar-filter-actions",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "emc-btn emc-btn-dark",
                                                    onClick: onThisMonth,
                                                    type: "button",
                                                    children: "Este mes"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 88,
                                                    columnNumber: 19
                                                }, this),
                                                hasActiveFilters ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: "emc-btn emc-btn-light",
                                                    onClick: onClearFilters,
                                                    type: "button",
                                                    children: "Ver todos"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 92,
                                                    columnNumber: 21
                                                }, this) : null
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 87,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 81,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "emc-calendar-vehicle-row",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: "Tipo"
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 100,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-vehicle-tabs emc-vehicle-tabs-calendar",
                                            "aria-label": "Tipo de vehículo",
                                            children: VEHICLE_FILTERS.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    className: vehicleFilter === item.id ? "emc-active" : "",
                                                    onClick: ()=>onVehicle(item.id),
                                                    type: "button",
                                                    children: item.label
                                                }, item.id, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 103,
                                                    columnNumber: 21
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 101,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 99,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "emc-calendar-fields",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-field",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    children: "Buscar"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 117,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                    onChange: (event)=>setQuery(event.target.value),
                                                    placeholder: "Evento, circuito, ciudad...",
                                                    value: query
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 118,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 116,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-field",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    children: "Disciplina"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 125,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    onChange: (event)=>setDiscipline(event.target.value),
                                                    value: discipline,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            children: "Todas"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                            lineNumber: 127,
                                                            columnNumber: 21
                                                        }, this),
                                                        disciplines.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: item
                                                            }, item, false, {
                                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                                lineNumber: 129,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 126,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 124,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-field",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                    children: "Zona"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 134,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                    onChange: (event)=>onZoneSelect(event.target.value),
                                                    value: zone,
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            children: "Toda España"
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                            lineNumber: 136,
                                                            columnNumber: 21
                                                        }, this),
                                                        zones.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                                children: item.name
                                                            }, item.name, false, {
                                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                                lineNumber: 138,
                                                                columnNumber: 23
                                                            }, this))
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 135,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 133,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 115,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 80,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-calendar-toolbar",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "emc-month-title",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            children: [
                                                __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["MONTHS"][month],
                                                " ",
                                                year
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 147,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            children: [
                                                monthEventCount,
                                                " eventos / ",
                                                monthDisciplineCount,
                                                " disciplinas"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 150,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 146,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "emc-month-actions",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "emc-icon",
                                            onClick: ()=>setMonth((current)=>(current + 11) % 12),
                                            type: "button",
                                            children: "‹"
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 155,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "emc-icon",
                                            onClick: ()=>setMonth((current)=>(current + 1) % 12),
                                            type: "button",
                                            children: "›"
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 158,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: "emc-btn emc-btn-dark",
                                            onClick: ()=>setMonth(()=>__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].getMonth()),
                                            type: "button",
                                            children: "Hoy"
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 161,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 154,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 145,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-weekdays",
                            children: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["WEEK_DAYS"].map((day)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: day
                                }, day, false, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 169,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 167,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-month",
                            children: days.map((day)=>{
                                const dayEvents = filtered.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isOnDay"])(event, day));
                                const isFocused = agendaDay.toDateString() === day.toDateString();
                                const isToday = __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].toDateString() === day.toDateString();
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: `emc-day ${dayEvents.length ? "emc-has" : ""} ${isFocused ? "emc-focus" : ""} ${isToday ? "emc-today" : ""}`,
                                    onClick: ()=>onDay(day),
                                    type: "button",
                                    children: [
                                        day.getDate(),
                                        dayEvents.length ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                            children: dayEvents.length
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 185,
                                            columnNumber: 41
                                        }, this) : null,
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "emc-dots",
                                            children: dayEvents.slice(0, 5).map((event)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "emc-edot",
                                                    style: {
                                                        background: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDisciplineColor"])(event.discipline).accent
                                                    }
                                                }, event.id, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 188,
                                                    columnNumber: 25
                                                }, this))
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 186,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, day.toISOString(), true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 178,
                                    columnNumber: 19
                                }, this);
                            })
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 172,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                    lineNumber: 79,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("aside", {
                    className: "emc-panel",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-agenda-head",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-kicker",
                                            children: "Agenda del día"
                                        }, void 0, false, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 204,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            children: [
                                                "Eventos del ",
                                                dateLabel
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 205,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 203,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "emc-badge",
                                    children: [
                                        selectedDayEvents.length,
                                        " eventos"
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 207,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 202,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-agenda",
                            children: selectedDayEvents.length ? selectedDayEvents.map((event)=>{
                                const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dayLabel"])(event);
                                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("article", {
                                    className: "emc-event-row",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-datebox",
                                            children: [
                                                label.day,
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                    children: label.month
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 217,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 215,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "emc-badge",
                                                    children: event.discipline
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 220,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                    children: event.title
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 221,
                                                    columnNumber: 25
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    children: [
                                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatRange"])(event),
                                                        " / ",
                                                        event.city,
                                                        ", ",
                                                        event.province
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 222,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 219,
                                            columnNumber: 23
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "emc-event-actions",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                    className: "emc-card-action",
                                                    href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventHref"])(event),
                                                    children: "Ver evento"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 227,
                                                    columnNumber: 25
                                                }, this),
                                                event.ticketUrl ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                                    className: "emc-ticket-action",
                                                    href: event.ticketUrl,
                                                    rel: "noreferrer",
                                                    target: "_blank",
                                                    children: "Entradas"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                    lineNumber: 231,
                                                    columnNumber: 27
                                                }, this) : null
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                            lineNumber: 226,
                                            columnNumber: 23
                                        }, this)
                                    ]
                                }, event.id, true, {
                                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                    lineNumber: 214,
                                    columnNumber: 21
                                }, this);
                            }) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-agenda-empty",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                        children: "No hay eventos este día"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                        lineNumber: 241,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "Estos son los próximos eventos disponibles con la búsqueda actual."
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                        lineNumber: 242,
                                        columnNumber: 19
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-agenda",
                                        children: fallbackAgenda.map((event)=>{
                                            const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dayLabel"])(event);
                                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                                className: "emc-event-row emc-event-row-compact",
                                                href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventHref"])(event),
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "emc-datebox",
                                                        children: [
                                                            label.day,
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                children: label.month
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                                lineNumber: 250,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                        lineNumber: 248,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h4", {
                                                                children: event.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                                lineNumber: 253,
                                                                columnNumber: 29
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                                children: [
                                                                    event.city,
                                                                    " / ",
                                                                    event.province
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                                lineNumber: 254,
                                                                columnNumber: 29
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                        lineNumber: 252,
                                                        columnNumber: 27
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "emc-badge",
                                                        children: event.discipline
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                        lineNumber: 258,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, event.id, true, {
                                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                                lineNumber: 247,
                                                columnNumber: 25
                                            }, this);
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                        lineNumber: 243,
                                        columnNumber: 19
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                                lineNumber: 240,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                            lineNumber: 209,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
                    lineNumber: 201,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
            lineNumber: 78,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptCalendar.tsx",
        lineNumber: 77,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/geo.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "calculateDistanceKm",
    ()=>calculateDistanceKm,
    "getEventDistanceKm",
    ()=>getEventDistanceKm,
    "getProvinceCoordinates",
    ()=>getProvinceCoordinates,
    "sortEventsByDistance",
    ()=>sortEventsByDistance
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
;
const PROVINCE_COORDINATES = {
    acoruna: {
        lat: 43.3623,
        lng: -8.4115
    },
    alava: {
        lat: 42.8467,
        lng: -2.6727
    },
    albacete: {
        lat: 38.9943,
        lng: -1.8585
    },
    alicante: {
        lat: 38.3452,
        lng: -0.481
    },
    almeria: {
        lat: 36.834,
        lng: -2.4637
    },
    asturias: {
        lat: 43.3619,
        lng: -5.8494
    },
    avila: {
        lat: 40.6565,
        lng: -4.6818
    },
    badajoz: {
        lat: 38.8794,
        lng: -6.9707
    },
    baleares: {
        lat: 39.5696,
        lng: 2.6502
    },
    barcelona: {
        lat: 41.3874,
        lng: 2.1686
    },
    burgos: {
        lat: 42.3439,
        lng: -3.6969
    },
    caceres: {
        lat: 39.4753,
        lng: -6.3724
    },
    cadiz: {
        lat: 36.5271,
        lng: -6.2886
    },
    cantabria: {
        lat: 43.4623,
        lng: -3.8099
    },
    castellon: {
        lat: 39.9864,
        lng: -0.0513
    },
    ceuta: {
        lat: 35.8894,
        lng: -5.3213
    },
    ciudadreal: {
        lat: 38.9861,
        lng: -3.9273
    },
    cordoba: {
        lat: 37.8882,
        lng: -4.7794
    },
    cuenca: {
        lat: 40.0704,
        lng: -2.1374
    },
    girona: {
        lat: 41.9794,
        lng: 2.8214
    },
    granada: {
        lat: 37.1773,
        lng: -3.5986
    },
    guadalajara: {
        lat: 40.6333,
        lng: -3.1667
    },
    gipuzkoa: {
        lat: 43.3183,
        lng: -1.9812
    },
    huelva: {
        lat: 37.2614,
        lng: -6.9447
    },
    huesca: {
        lat: 42.1401,
        lng: -0.4089
    },
    jaen: {
        lat: 37.7796,
        lng: -3.7849
    },
    larioja: {
        lat: 42.465,
        lng: -2.4456
    },
    laspalmas: {
        lat: 28.1235,
        lng: -15.4363
    },
    leon: {
        lat: 42.5987,
        lng: -5.5671
    },
    lleida: {
        lat: 41.6176,
        lng: 0.62
    },
    lugo: {
        lat: 43.0097,
        lng: -7.5568
    },
    madrid: {
        lat: 40.4168,
        lng: -3.7038
    },
    malaga: {
        lat: 36.7213,
        lng: -4.4214
    },
    melilla: {
        lat: 35.2923,
        lng: -2.9381
    },
    murcia: {
        lat: 37.9922,
        lng: -1.1307
    },
    navarra: {
        lat: 42.8125,
        lng: -1.6458
    },
    ourense: {
        lat: 42.3358,
        lng: -7.8639
    },
    palencia: {
        lat: 42.0097,
        lng: -4.5288
    },
    pontevedra: {
        lat: 42.431,
        lng: -8.6444
    },
    salamanca: {
        lat: 40.9701,
        lng: -5.6635
    },
    santacruztenerife: {
        lat: 28.4636,
        lng: -16.2518
    },
    segovia: {
        lat: 40.9429,
        lng: -4.1088
    },
    sevilla: {
        lat: 37.3891,
        lng: -5.9845
    },
    soria: {
        lat: 41.7666,
        lng: -2.479
    },
    tarragona: {
        lat: 41.1189,
        lng: 1.2445
    },
    teruel: {
        lat: 40.3456,
        lng: -1.1065
    },
    toledo: {
        lat: 39.8628,
        lng: -4.0273
    },
    valencia: {
        lat: 39.4699,
        lng: -0.3763
    },
    valladolid: {
        lat: 41.6523,
        lng: -4.7245
    },
    vizcaya: {
        lat: 43.263,
        lng: -2.935
    },
    zamora: {
        lat: 41.5035,
        lng: -5.7446
    },
    zaragoza: {
        lat: 41.6488,
        lng: -0.8891
    }
};
const PROVINCE_ALIASES = {
    "a-coruna": "acoruna",
    "a-coruna-la-coruna": "acoruna",
    "alava-araba": "alava",
    "araba": "alava",
    "balears": "baleares",
    "illes-balears": "baleares",
    "castello": "castellon",
    "castellon-castello": "castellon",
    "ciudad-real": "ciudadreal",
    "girona-gerona": "girona",
    "gerona": "girona",
    "guipuzcoa": "gipuzkoa",
    "la-rioja": "larioja",
    "las-palmas": "laspalmas",
    "lleida-lerida": "lleida",
    "lerida": "lleida",
    "santa-cruz-de-tenerife": "santacruztenerife",
    "valencia-valencia": "valencia",
    "bizkaia": "vizcaya"
};
function normalizeProvince(province) {
    const normalized = province.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return PROVINCE_ALIASES[normalized] || normalized.replace(/-/g, "");
}
function getEventCoordinates(event) {
    const eventWithCoordinates = event;
    const directLat = eventWithCoordinates.lat ?? eventWithCoordinates.latitude;
    const directLng = eventWithCoordinates.lng ?? eventWithCoordinates.longitude;
    if (typeof directLat === "number" && typeof directLng === "number") {
        return {
            lat: directLat,
            lng: directLng
        };
    }
    return getProvinceCoordinates(event.province);
}
function getProvinceCoordinates(province) {
    return PROVINCE_COORDINATES[normalizeProvince(province)] || null;
}
function calculateDistanceKm(lat1, lon1, lat2, lon2) {
    const earthRadiusKm = 6371;
    const toRadians = (degrees)=>degrees * Math.PI / 180;
    const dLat = toRadians(lat2 - lat1);
    const dLon = toRadians(lon2 - lon1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(toRadians(lat1)) * Math.cos(toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return earthRadiusKm * c;
}
function getEventDistanceKm(event, userLocation) {
    const coordinates = getEventCoordinates(event);
    if (!coordinates) {
        return null;
    }
    return calculateDistanceKm(userLocation.lat, userLocation.lng, coordinates.lat, coordinates.lng);
}
function sortEventsByDistance(events, userLocation) {
    return [
        ...events
    ].sort((left, right)=>{
        const leftDistance = getEventDistanceKm(left, userLocation);
        const rightDistance = getEventDistanceKm(right, userLocation);
        if (leftDistance !== null && rightDistance !== null) {
            return leftDistance - rightDistance || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(left.start).getTime() - (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(right.start).getTime();
        }
        if (leftDistance !== null) {
            return -1;
        }
        if (rightDistance !== null) {
            return 1;
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(left.start).getTime() - (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(right.start).getTime();
    });
}
}),
"[project]/components/public/concept/ConceptEventExplorer.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptEventExplorer
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/geo.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/concept-model.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
const VIEWS = [
    {
        id: "lista",
        label: "Lista"
    },
    {
        id: "calendario",
        label: "Calendario"
    },
    {
        id: "mapa",
        label: "Mapa"
    }
];
function ConceptEventExplorer({ activeLabel, calendar, filtered, hasActiveFilters, userLocation, view, zone, zones, onClearFilters, onView, onZone }) {
    const visibleEvents = filtered.slice(0, 9);
    const featured = filtered.slice(0, 4);
    function zoneClassName(name) {
        const normalized = name.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase();
        if (normalized.includes("norte")) return "emc-zone-norte";
        if (normalized.includes("centro")) return "emc-zone-centro";
        if (normalized.includes("cataluna") || normalized.includes("catalunya") || normalized.includes("aragon")) return "emc-zone-cataluna";
        if (normalized.includes("levante")) return "emc-zone-levante";
        if (normalized.includes("sur")) return "emc-zone-sur";
        if (normalized.includes("canarias")) return "emc-zone-canarias";
        return "emc-zone-centro";
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "emc-section emc-explorer-section",
        id: "calendario",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "emc-explorer-shell",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-explorer-head",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-kicker",
                                        children: "Explorador"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 68,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        children: "Próximos eventos"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 69,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: [
                                            activeLabel,
                                            ". ",
                                            filtered.length,
                                            " eventos visibles con los filtros actuales."
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 70,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 67,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-view-tabs",
                                "aria-label": "Cambiar vista",
                                children: VIEWS.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: view === item.id ? "emc-active" : "",
                                        onClick: ()=>onView(item.id),
                                        type: "button",
                                        children: item.label
                                    }, item.id, false, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 76,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 74,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                        lineNumber: 66,
                        columnNumber: 11
                    }, this),
                    hasActiveFilters ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-active-filter-bar",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Vista filtrada"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 90,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: activeLabel
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 91,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: onClearFilters,
                                type: "button",
                                children: "Ver todos"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 92,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                        lineNumber: 89,
                        columnNumber: 13
                    }, this) : null,
                    view === "lista" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-list-view",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-featured-column",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-list-section-title",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: "Destacados"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 100,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "Planes que se ven rápido"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 101,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 99,
                                        columnNumber: 17
                                    }, this),
                                    featured.map((event)=>{
                                        const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dayLabel"])(event);
                                        const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDisciplineColor"])(event.discipline);
                                        const distance = userLocation ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getEventDistanceKm"])(event, userLocation) : null;
                                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                            className: "emc-featured-event",
                                            href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventHref"])(event),
                                            style: {
                                                "--emc-card-accent": color.accent
                                            },
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "emc-datebox",
                                                    children: [
                                                        label.day,
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                            children: label.month
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                            lineNumber: 117,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                    lineNumber: 115,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "emc-badge",
                                                            children: event.discipline
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                            lineNumber: 120,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                            children: event.title
                                                        }, void 0, false, {
                                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                            lineNumber: 121,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                            children: [
                                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatRange"])(event),
                                                                " / ",
                                                                event.city,
                                                                ", ",
                                                                event.province
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                            lineNumber: 122,
                                                            columnNumber: 25
                                                        }, this),
                                                        distance !== null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                            children: [
                                                                "Aprox. ",
                                                                Math.round(distance),
                                                                " km"
                                                            ]
                                                        }, void 0, true, {
                                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                            lineNumber: 123,
                                                            columnNumber: 46
                                                        }, this) : null
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                    lineNumber: 119,
                                                    columnNumber: 23
                                                }, this)
                                            ]
                                        }, event.id, true, {
                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                            lineNumber: 109,
                                            columnNumber: 21
                                        }, this);
                                    })
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 98,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-event-list",
                                children: visibleEvents.map((event)=>{
                                    const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dayLabel"])(event);
                                    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDisciplineColor"])(event.discipline);
                                    const distance = userLocation ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getEventDistanceKm"])(event, userLocation) : null;
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        className: "emc-list-card",
                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventHref"])(event),
                                        style: {
                                            "--emc-card-accent": color.accent
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "emc-result-date",
                                                children: [
                                                    label.day,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                        children: label.month
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                        lineNumber: 143,
                                                        columnNumber: 67
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 143,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "emc-result-meta",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "emc-badge",
                                                                children: event.discipline
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                                lineNumber: 146,
                                                                columnNumber: 27
                                                            }, this),
                                                            distance !== null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "emc-distance",
                                                                children: [
                                                                    "Aprox. ",
                                                                    Math.round(distance),
                                                                    " km"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                                lineNumber: 147,
                                                                columnNumber: 48
                                                            }, this) : null
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                        lineNumber: 145,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        children: event.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                        lineNumber: 149,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: [
                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatRange"])(event),
                                                            " / ",
                                                            event.city,
                                                            ", ",
                                                            event.province
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                        lineNumber: 150,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 144,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "emc-card-action",
                                                children: "Ver evento"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 152,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, event.id, true, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 137,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 130,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                        lineNumber: 97,
                        columnNumber: 13
                    }, this) : null,
                    view === "calendario" ? calendar : null,
                    view === "mapa" ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-map-view",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-map-stage",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                        className: "emc-micro-spain",
                                        src: "/maps/spain-map.svg",
                                        alt: "",
                                        "aria-hidden": "true"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 165,
                                        columnNumber: 17
                                    }, this),
                                    zones.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: `emc-micro-dot ${zoneClassName(item.name)} ${zone === item.name ? "emc-active" : ""}`,
                                            onClick: ()=>onZone(item.name),
                                            style: {
                                                background: item.color
                                            },
                                            type: "button",
                                            children: item.events.length
                                        }, item.name, false, {
                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                            lineNumber: 167,
                                            columnNumber: 19
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 164,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-zone-list",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: zone === "Toda España" ? "emc-active" : "",
                                        onClick: ()=>onZone("Toda España"),
                                        type: "button",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                children: "Toda España"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 180,
                                                columnNumber: 19
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                children: [
                                                    filtered.length,
                                                    " eventos visibles"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                lineNumber: 181,
                                                columnNumber: 19
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                        lineNumber: 179,
                                        columnNumber: 17
                                    }, this),
                                    zones.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                            className: zone === item.name ? "emc-active" : "",
                                            onClick: ()=>onZone(item.name),
                                            type: "button",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                    children: item.name
                                                }, void 0, false, {
                                                    fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                    lineNumber: 185,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    children: [
                                                        item.upcoming.length,
                                                        " próximos / ",
                                                        item.provinces.slice(0, 3).join(", ")
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                                    lineNumber: 186,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, item.name, true, {
                                            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                            lineNumber: 184,
                                            columnNumber: 19
                                        }, this))
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                                lineNumber: 178,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                        lineNumber: 163,
                        columnNumber: 13
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
                lineNumber: 65,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
            lineNumber: 64,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptEventExplorer.tsx",
        lineNumber: 63,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/brand/EventomotorLogo.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventomotorLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
const DARK_HEADER_LOGO = "/brand/eventomotor-logo-horizontal-dark-header.png";
const LIGHT_BG_LOGO = "/brand/eventomotor-logo-horizontal-light-bg.png";
const MARK_LOGO = "/brand/eventomotor-logo-mark-transparent.png";
function EventomotorLogo({ className = "", compactOnMobile = false, iconOnly = false, surface = "dark" }) {
    const horizontalSrc = surface === "light" ? LIGHT_BG_LOGO : DARK_HEADER_LOGO;
    const logoClassName = `em-logo ${iconOnly ? "em-logo-mark" : "em-logo-horizontal"} ${className}`.trim();
    if (iconOnly) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
            alt: "EventoMotor",
            className: logoClassName,
            decoding: "async",
            src: MARK_LOGO
        }, void 0, false, {
            fileName: "[project]/components/brand/EventomotorLogo.tsx",
            lineNumber: 23,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("picture", {
        children: [
            compactOnMobile ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("source", {
                media: "(max-width: 640px)",
                srcSet: MARK_LOGO
            }, void 0, false, {
                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                lineNumber: 34,
                columnNumber: 26
            }, this) : null,
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                alt: "EventoMotor",
                className: logoClassName,
                decoding: "async",
                src: horizontalSrc
            }, void 0, false, {
                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/EventomotorLogo.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/public/concept/ConceptFooter.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptFooter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/EventomotorLogo.tsx [app-ssr] (ecmascript)");
;
;
function ConceptFooter() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("footer", {
        className: "emc-footer",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-container emc-footer-grid",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-footer-brand",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptFooter.tsx",
                                lineNumber: 9,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptFooter.tsx",
                            lineNumber: 8,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            children: "Concepto visual portado a React con datos reales de EventoMotor."
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptFooter.tsx",
                            lineNumber: 11,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/public/concept/ConceptFooter.tsx",
                    lineNumber: 7,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    children: [
                        "© ",
                        new Date().getFullYear(),
                        " EventoMotor / La brújula del motor"
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/public/concept/ConceptFooter.tsx",
                    lineNumber: 13,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/public/concept/ConceptFooter.tsx",
            lineNumber: 6,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptFooter.tsx",
        lineNumber: 5,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/public/concept/ConceptHeader.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptHeader
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/EventomotorLogo.tsx [app-ssr] (ecmascript)");
"use client";
;
;
;
function ConceptHeader({ onCalendar }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "emc-topline"
            }, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                lineNumber: 13,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                className: "emc-header-shell",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("nav", {
                    className: "emc-nav",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            className: "emc-brand-logo",
                            href: "/",
                            "aria-label": "EventoMotor inicio",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                compactOnMobile: true
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                                lineNumber: 17,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                            lineNumber: 16,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-navlinks",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "emc-navlink-button",
                                    onClick: onCalendar,
                                    type: "button",
                                    children: "Calendario"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                                    lineNumber: 21,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: "#calendario",
                                    children: "Zonas"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                                    lineNumber: 24,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                            lineNumber: 20,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "emc-nav-actions",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                className: "emc-btn emc-btn-primary",
                                href: "#organizadores",
                                children: "Publicar"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                                lineNumber: 28,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                            lineNumber: 27,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHeader.tsx",
                lineNumber: 14,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
}),
"[project]/components/public/concept/ConceptHero.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptHero
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
"use client";
;
const VEHICLE_FILTERS = [
    {
        id: "todos",
        label: "Todos"
    },
    {
        id: "moto",
        label: "Motos"
    },
    {
        id: "coche",
        label: "Coches"
    }
];
function ConceptHero({ zones, disciplines, query, discipline, zone, vehicleFilter, locationLabel, locationMessage, userLocationActive, onSearch, onQuery, onDiscipline, onZone, onVehicle, onUseLocation, onClearLocation }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
        className: "emc-hero",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-container emc-hero-grid",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "emc-hero-main",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-eyebrow",
                        children: "Eventos de motor en España"
                    }, void 0, false, {
                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                        lineNumber: 54,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                        children: [
                            "Encuentra tu próximo plan de motor. ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                children: "Por fecha, zona y tipo."
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                lineNumber: 56,
                                columnNumber: 49
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                        lineNumber: 55,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "emc-hero-copy",
                        children: "Filtra motos, coches o todo el calendario. Busca por ciudad, circuito, disciplina o usa tu ubicación para ver primero lo que tienes cerca."
                    }, void 0, false, {
                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                        lineNumber: 58,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("form", {
                        className: "emc-hero-search",
                        onSubmit: (event)=>{
                            event.preventDefault();
                            onSearch();
                        },
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-hero-decision-row",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "emc-control-label",
                                                children: "Tipo de evento"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 71,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "emc-vehicle-tabs emc-vehicle-tabs-hero",
                                                "aria-label": "Tipo de vehículo",
                                                children: VEHICLE_FILTERS.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: vehicleFilter === item.id ? "emc-active" : "",
                                                        onClick: ()=>onVehicle(item.id),
                                                        type: "button",
                                                        children: item.label
                                                    }, item.id, false, {
                                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                        lineNumber: 74,
                                                        columnNumber: 21
                                                    }, this))
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 72,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 70,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-hero-location-card",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "emc-control-label",
                                                children: userLocationActive ? "Ubicación activa" : "Ubicación"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 87,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "emc-hero-location-actions",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "emc-location-trigger",
                                                        onClick: onUseLocation,
                                                        type: "button",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                "aria-hidden": "true",
                                                                children: "⌖"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                                lineNumber: 90,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                                                children: userLocationActive ? "Cerca de ti" : "Usar mi ubicación"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                                lineNumber: 91,
                                                                columnNumber: 21
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                                children: locationLabel
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                                lineNumber: 92,
                                                                columnNumber: 21
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                        lineNumber: 89,
                                                        columnNumber: 19
                                                    }, this),
                                                    userLocationActive ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        className: "emc-location-clear",
                                                        onClick: onClearLocation,
                                                        type: "button",
                                                        children: "Quitar"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                        lineNumber: 95,
                                                        columnNumber: 21
                                                    }, this) : null
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 88,
                                                columnNumber: 17
                                            }, this),
                                            locationMessage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "emc-location-inline-message",
                                                children: locationMessage
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 100,
                                                columnNumber: 36
                                            }, this) : null
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 86,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                lineNumber: 69,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-hero-fields",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-field",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "emc-hero-query",
                                                children: "Buscar"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 106,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                                id: "emc-hero-query",
                                                onChange: (event)=>onQuery(event.target.value),
                                                placeholder: "Ciudad, circuito, rally...",
                                                value: query
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 107,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 105,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-field",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "emc-hero-zone",
                                                children: "Zona"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 115,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                id: "emc-hero-zone",
                                                onChange: (event)=>onZone(event.target.value),
                                                value: zone,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        value: "Toda España",
                                                        children: "Toda España"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                        lineNumber: 117,
                                                        columnNumber: 19
                                                    }, this),
                                                    zones.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            children: item.name
                                                        }, item.name, false, {
                                                            fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                            lineNumber: 119,
                                                            columnNumber: 21
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 116,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 114,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-field",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                                htmlFor: "emc-hero-discipline",
                                                children: "Disciplina"
                                            }, void 0, false, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 124,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                                id: "emc-hero-discipline",
                                                onChange: (event)=>onDiscipline(event.target.value),
                                                value: discipline,
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                        children: "Todas"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                        lineNumber: 126,
                                                        columnNumber: 19
                                                    }, this),
                                                    disciplines.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                                            children: item
                                                        }, item, false, {
                                                            fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                            lineNumber: 128,
                                                            columnNumber: 21
                                                        }, this))
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                                lineNumber: 125,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        className: "emc-btn emc-btn-primary",
                                        type: "submit",
                                        children: "Buscar eventos"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                        lineNumber: 132,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                                lineNumber: 104,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptHero.tsx",
                        lineNumber: 62,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/public/concept/ConceptHero.tsx",
                lineNumber: 53,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/public/concept/ConceptHero.tsx",
            lineNumber: 52,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptHero.tsx",
        lineNumber: 51,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/public/concept/ConceptLocationPanel.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LOCATION_STORAGE_KEY",
    ()=>LOCATION_STORAGE_KEY,
    "default",
    ()=>ConceptLocationPanel,
    "readStoredLocation",
    ()=>readStoredLocation,
    "removeStoredLocation",
    ()=>removeStoredLocation,
    "saveLocation",
    ()=>saveLocation
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/geo.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/concept-model.ts [app-ssr] (ecmascript)");
;
;
;
;
;
const LOCATION_STORAGE_KEY = "eventomotor:user-location";
function readStoredLocation() {
    try {
        const stored = window.localStorage.getItem(LOCATION_STORAGE_KEY);
        if (!stored) {
            return null;
        }
        const parsed = JSON.parse(stored);
        if (typeof parsed.lat === "number" && typeof parsed.lng === "number") {
            return {
                lat: parsed.lat,
                lng: parsed.lng
            };
        }
    } catch  {
        window.localStorage.removeItem(LOCATION_STORAGE_KEY);
    }
    return null;
}
function saveLocation(location) {
    window.localStorage.setItem(LOCATION_STORAGE_KEY, JSON.stringify(location));
}
function removeStoredLocation() {
    window.localStorage.removeItem(LOCATION_STORAGE_KEY);
}
function ConceptLocationPanel({ userLocation, nearbyEvents, locationMessage, onLocationChange, onLocationMessage }) {
    function requestLocation() {
        onLocationMessage("");
        if (!("geolocation" in navigator)) {
            onLocationMessage("No se ha podido activar la ubicación. Puedes seguir explorando eventos.");
            return;
        }
        navigator.geolocation.getCurrentPosition((position)=>{
            const location = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            saveLocation(location);
            onLocationChange(location);
            onLocationMessage("");
        }, ()=>{
            onLocationMessage("No se ha podido activar la ubicación. Puedes seguir explorando eventos.");
        }, {
            enableHighAccuracy: false,
            maximumAge: 1000 * 60 * 30,
            timeout: 10000
        });
    }
    function clearLocation() {
        removeStoredLocation();
        onLocationChange(null);
        onLocationMessage("");
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "emc-section emc-location-section",
        "aria-label": "Eventos cerca de ti",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "emc-location-panel",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-location-copy",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-location-icon",
                                "aria-hidden": "true",
                                children: "⌖"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                lineNumber: 93,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "emc-kicker",
                                        children: "Cerca de ti"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 95,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                        children: "Encuentra eventos cerca de ti"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 96,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        children: "Usa tu ubicación para priorizar eventos por zona."
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 97,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                        children: "Tu ubicación se usa solo en este navegador para ordenar eventos cercanos."
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 98,
                                        columnNumber: 15
                                    }, this),
                                    locationMessage ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "emc-location-message",
                                        children: locationMessage
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 99,
                                        columnNumber: 34
                                    }, this) : null
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                        lineNumber: 92,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-location-actions",
                        children: userLocation ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "emc-location-chip",
                                    children: "Ubicación activada"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                    lineNumber: 106,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "emc-btn emc-btn-light",
                                    onClick: requestLocation,
                                    type: "button",
                                    children: "Cambiar"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                    lineNumber: 107,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "emc-btn emc-btn-dark",
                                    onClick: clearLocation,
                                    type: "button",
                                    children: "Quitar ubicación"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                    lineNumber: 110,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "emc-btn emc-btn-primary",
                                    onClick: requestLocation,
                                    type: "button",
                                    children: "Usar mi ubicación"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                    lineNumber: 116,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    className: "emc-btn emc-btn-dark",
                                    onClick: ()=>onLocationMessage(""),
                                    type: "button",
                                    children: "Ahora no"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                    lineNumber: 119,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true)
                    }, void 0, false, {
                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                        lineNumber: 103,
                        columnNumber: 11
                    }, this),
                    userLocation ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-nearby",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-nearby-head",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Eventos cerca de ti"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 129,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: nearbyEvents.length ? "Ordenados por distancia aproximada" : "Sin coordenadas suficientes"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 130,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                lineNumber: 128,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-nearby-grid",
                                children: nearbyEvents.map((event)=>{
                                    const label = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["dayLabel"])(event);
                                    const color = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getDisciplineColor"])(event.discipline);
                                    const distance = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getEventDistanceKm"])(event, userLocation);
                                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                                        className: "emc-nearby-card",
                                        href: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventHref"])(event),
                                        style: {
                                            "--emc-card-accent": color.accent
                                        },
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "emc-result-date",
                                                children: [
                                                    label.day,
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("small", {
                                                        children: label.month
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                        lineNumber: 145,
                                                        columnNumber: 67
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                lineNumber: 145,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "emc-nearby-meta",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "emc-badge",
                                                                children: event.discipline
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                                lineNumber: 148,
                                                                columnNumber: 27
                                                            }, this),
                                                            distance !== null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "emc-distance",
                                                                children: [
                                                                    "Aprox. ",
                                                                    Math.round(distance),
                                                                    " km"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                                lineNumber: 149,
                                                                columnNumber: 48
                                                            }, this) : null
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                        lineNumber: 147,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                        children: event.title
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                        lineNumber: 151,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                        children: [
                                                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["formatRange"])(event),
                                                            " / ",
                                                            event.city,
                                                            ", ",
                                                            event.province
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                        lineNumber: 152,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "emc-card-action",
                                                        children: "Ver evento"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                        lineNumber: 153,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                                lineNumber: 146,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, event.id, true, {
                                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                        lineNumber: 139,
                                        columnNumber: 21
                                    }, this);
                                })
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                                lineNumber: 132,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                        lineNumber: 127,
                        columnNumber: 13
                    }, this) : null
                ]
            }, void 0, true, {
                fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
                lineNumber: 91,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
            lineNumber: 90,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptLocationPanel.tsx",
        lineNumber: 89,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/public/concept/ConceptResults.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptResults
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function ConceptResults() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "emc-section emc-organizer-section",
        id: "organizadores",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "emc-container",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "emc-panel emc-pro-panel",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-kicker",
                                children: "Para organizadores"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 7,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                children: "Publica tu evento donde el usuario ya está buscando"
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 8,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "emc-pro-copy",
                                children: "EventoMotor ordena los planes por fecha, zona, tipo de vehículo y disciplina para que el evento sea fácil de encontrar."
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 9,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-pro-actions",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    className: "emc-btn emc-btn-primary",
                                    href: "mailto:hola@eventomotor.com?subject=Publicar%20evento%20en%20EventoMotor",
                                    children: "Publicar evento"
                                }, void 0, false, {
                                    fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                    lineNumber: 13,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 12,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                        lineNumber: 6,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "emc-checks",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-check",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Fecha"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 19,
                                        columnNumber: 40
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "calendario claro"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 19,
                                        columnNumber: 62
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 19,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-check",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Zona"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 20,
                                        columnNumber: 40
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "búsqueda territorial"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 20,
                                        columnNumber: 61
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 20,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-check",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Tipo"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 21,
                                        columnNumber: 40
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "motos o coches"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 21,
                                        columnNumber: 61
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 21,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "emc-check",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                        children: "Ficha"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 22,
                                        columnNumber: 40
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        children: "detalle del evento"
                                    }, void 0, false, {
                                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                        lineNumber: 22,
                                        columnNumber: 62
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                                lineNumber: 22,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/public/concept/ConceptResults.tsx",
                        lineNumber: 18,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/public/concept/ConceptResults.tsx",
                lineNumber: 5,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/components/public/concept/ConceptResults.tsx",
            lineNumber: 4,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptResults.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/public/concept/ConceptStyles.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptStyles
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
;
function ConceptStyles() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("style", {
        children: `
.emc-page {
  --emc-bg: #050609;
  --emc-ink: #f8fafc;
  --emc-muted: #8d98aa;
  --emc-line: rgba(255,255,255,.10);
  --emc-line2: rgba(255,255,255,.18);
  --emc-orange: #ff3b00;
  --emc-orange2: #ff7b1a;
  --emc-amber: #ffb547;
  --emc-blue: #4ba3ff;
  --emc-green: #18d889;
  --emc-purple: #9b7cff;
  --emc-shadow: 0 34px 110px rgba(0,0,0,.50);
  min-height: 100vh;
  background:
    radial-gradient(circle at 9% -4%, rgba(255,59,0,.24), transparent 32%),
    radial-gradient(circle at 90% 2%, rgba(75,163,255,.16), transparent 30%),
    linear-gradient(180deg, #050609, #080b12 46%, #050609);
  color: var(--emc-ink);
  overflow-x: hidden;
  font-family: Inter, Arial, Helvetica, sans-serif;
  position: relative;
}
.emc-page:before {
  content: "";
  position: fixed;
  inset: 0;
  z-index: 0;
  pointer-events: none;
  opacity: .22;
  background-image:
    linear-gradient(rgba(255,255,255,.05) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.05) 1px, transparent 1px);
  background-size: 76px 76px;
  mask-image: linear-gradient(to bottom, black, transparent 78%);
}
.emc-page a { text-decoration: none; color: inherit; }
.emc-page button, .emc-page input, .emc-page select { font: inherit; }
.emc-page button { cursor: pointer; }
.emc-container { width: min(1320px, 92vw); margin: 0 auto; position: relative; z-index: 1; }
.emc-topline {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  z-index: 200;
  background: linear-gradient(90deg, var(--emc-orange), var(--emc-amber), var(--emc-blue), var(--emc-green), var(--emc-orange));
  background-size: 300% 100%;
  animation: emc-flow 8s linear infinite;
}
@keyframes emc-flow { to { background-position: 300% 0; } }

.emc-header-shell {
  position: sticky;
  top: 18px;
  width: min(1320px, 92vw);
  margin: 18px auto 0;
  z-index: 100;
  padding: 10px;
  background: rgba(8,11,17,.76);
  border: 1px solid var(--emc-line);
  backdrop-filter: blur(28px);
  border-radius: 28px;
  box-shadow: 0 18px 70px rgba(0,0,0,.38);
  transition: border-color .22s ease, background .22s ease;
}
.emc-nav {
  min-height: 60px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 20px;
  padding: 0 8px 0 12px;
}
.emc-brand-logo,
.emc-footer-brand {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-height: 48px;
  padding: 6px 12px;
  border-radius: 20px;
  background: linear-gradient(135deg, rgba(255,255,255,.105), rgba(255,255,255,.035));
  border: 1px solid rgba(255,255,255,.14);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.08), 0 18px 45px rgba(0,0,0,.24);
}
.em-logo {
  display: block;
  width: auto;
  object-fit: contain;
}
.em-logo-horizontal {
  height: 40px;
  max-width: 214px;
}
.em-logo-mark {
  height: 38px;
  width: 38px;
}
.emc-navlinks { display: flex; align-items: center; gap: 28px; color: #cbd2de; font-size: 14px; font-weight: 800; }
.emc-navlinks a:hover, .emc-navlink-button:hover { color: #fff; }
.emc-navlink-button { border: 0; background: transparent; color: #cbd2de; font-weight: 800; padding: 0; }
.emc-nav-actions { display: flex; gap: 10px; }
.emc-filter-rail {
  display: flex;
  justify-content: flex-start;
  align-items: center;
  gap: 14px;
  margin-top: 8px;
  padding: 9px 10px;
  border-top: 1px solid rgba(255,255,255,.08);
  max-height: 76px;
  opacity: 1;
  overflow: visible;
  transform: translateY(0);
  transition: max-height .24s ease, opacity .18s ease, transform .24s ease, margin .24s ease, padding .24s ease, border-color .24s ease;
}
.emc-header-shell:not(.emc-filter-pinned):not(:hover):not(:focus-within) .emc-filter-rail {
  max-height: 0;
  margin-top: 0;
  padding-top: 0;
  padding-bottom: 0;
  border-top-color: transparent;
  opacity: 0;
  pointer-events: none;
  transform: translateY(-8px);
}
.emc-location-menu { position: relative; }
.emc-filter-rail .emc-location-menu { margin-left: auto; }
.emc-location-menu summary {
  list-style: none;
  min-width: 270px;
  min-height: 50px;
  display: inline-flex;
  align-items: center;
  justify-content: flex-start;
  gap: 12px;
  padding: 6px 14px 6px 8px;
  border-radius: 18px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(255,255,255,.055);
  color: #f8fafc;
  font-size: 13px;
  font-weight: 950;
  cursor: pointer;
}
.emc-location-menu summary::-webkit-details-marker { display: none; }
.emc-location-menu summary:after { content: "⌄"; color: #aab3c3; font-size: 14px; margin-left: auto; }
.emc-location-pin {
  width: 36px;
  height: 36px;
  display: grid;
  place-items: center;
  flex: 0 0 36px;
  border-radius: 14px;
  background: linear-gradient(135deg, var(--emc-orange), var(--emc-orange2));
  color: #fff;
  font-size: 16px;
  box-shadow: 0 12px 26px rgba(255,59,0,.24);
}
.emc-location-summary-copy { display: grid; gap: 2px; min-width: 0; }
.emc-location-summary-copy span {
  color: #ffc7b5;
  font-size: 10px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.emc-location-summary-copy strong {
  color: #fff;
  font-size: 14px;
  font-weight: 950;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.emc-location-popover {
  position: absolute;
  right: 0;
  top: calc(100% + 10px);
  width: 260px;
  z-index: 20;
  display: grid;
  gap: 8px;
  padding: 10px;
  border-radius: 22px;
  border: 1px solid rgba(255,255,255,.13);
  background: rgba(8,11,17,.98);
  box-shadow: 0 22px 70px rgba(0,0,0,.44);
}
.emc-location-popover button {
  border: 0;
  border-radius: 16px;
  background: rgba(255,255,255,.065);
  color: #f8fafc;
  padding: 12px 13px;
  text-align: left;
  font-size: 13px;
  font-weight: 900;
}
.emc-location-popover button:hover { background: rgba(255,59,0,.14); }
.emc-location-popover small { color: #ffd0bf; font-size: 12px; font-weight: 850; line-height: 1.45; }
.emc-location-popover-head {
  padding: 8px 8px 6px;
  border-bottom: 1px solid rgba(255,255,255,.08);
  margin-bottom: 2px;
}
.emc-location-popover-head strong {
  display: block;
  color: #fff;
  font-size: 14px;
  font-weight: 950;
  margin-bottom: 4px;
}
.emc-location-popover-head span {
  display: block;
  color: var(--emc-muted);
  font-size: 12px;
  font-weight: 800;
  line-height: 1.45;
}
.emc-filter-pin {
  position: absolute;
  right: 22px;
  bottom: -17px;
  width: 34px;
  height: 34px;
  display: grid;
  place-items: center;
  border-radius: 50% 50% 46% 46%;
  border: 1px solid rgba(255,255,255,.18);
  background: linear-gradient(180deg, #f7fbff, #b8c2d0);
  color: #dbe2ec !important;
  box-shadow: 0 12px 30px rgba(0,0,0,.35);
  transform: rotate(-12deg);
  z-index: 2;
  opacity: 1;
  transition: opacity .18s ease, transform .18s ease, box-shadow .18s ease;
}
.emc-header-shell:not(.emc-filter-pinned):not(:hover):not(:focus-within) .emc-filter-pin {
  opacity: 0;
  pointer-events: none;
  transform: translateY(-8px) rotate(-12deg);
}
.emc-filter-pin span {
  position: relative;
  width: 13px;
  height: 13px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--emc-orange), var(--emc-orange2));
  box-shadow: inset 0 1px 0 rgba(255,255,255,.42);
}
.emc-filter-pin span:after {
  content: "";
  position: absolute;
  left: 50%;
  top: 11px;
  width: 2px;
  height: 15px;
  transform: translateX(-50%);
  border-radius: 999px;
  background: #d9e2ee;
}
.emc-filter-pin.emc-active {
  background: linear-gradient(180deg, #ff8a45, #ff3b00);
  color: #fff !important;
  border-color: rgba(255,255,255,.18);
  box-shadow: 0 10px 28px rgba(255,59,0,.24);
}
.emc-filter-pin.emc-active span { background: #fff; }
.emc-filter-pin.emc-active span:after { background: #fff0e9; }

.emc-btn,
.em-btn-primary,
.em-btn-secondary,
.em-btn-light,
.em-btn-ghost {
  border: 0;
  border-radius: 18px;
  padding: 13px 18px;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 900;
  transition: background .22s ease, border-color .22s ease, color .22s ease, box-shadow .22s ease;
}
.emc-btn:hover { transform: none; }
.emc-btn-primary, .em-btn-primary {
  background: linear-gradient(135deg, var(--emc-orange), var(--emc-orange2));
  color: #fff !important;
  box-shadow: 0 14px 42px rgba(255,59,0,.28);
}
.emc-btn-dark, .em-btn-secondary {
  background: rgba(255,255,255,.07);
  border: 1px solid var(--emc-line);
  color: #fff !important;
}
.emc-btn-light, .em-btn-light {
  background: #fff;
  color: #06080d !important;
}
.em-btn-ghost {
  background: transparent;
  border: 1px solid var(--emc-line);
  color: #dbe2ec !important;
}

.emc-hero { padding: 38px 0 22px; position: relative; z-index: 1; }
.emc-hero-grid { display: block; }
.emc-hero-main { display: flex; flex-direction: column; justify-content: center; }
.emc-event-hero { min-height: 78vh; padding: 148px 0 64px; display: flex; align-items: center; position: relative; z-index: 1; }
.emc-event-hero-grid { display: grid; grid-template-columns: minmax(0,1fr) 430px; gap: 54px; align-items: end; }
.emc-event-breadcrumb { display: flex; flex-wrap: wrap; gap: 8px; align-items: center; color: var(--emc-muted); font-size: 13px; font-weight: 850; margin-bottom: 28px; }
.emc-event-breadcrumb a:hover { color: #fff; }
.emc-event-breadcrumb strong { color: #fff; }
.emc-event-chip-row { display: flex; flex-wrap: wrap; gap: 9px; margin-bottom: 20px; }
.emc-event-date-line { color: #ffd0bf; font-size: 14px; font-weight: 950; letter-spacing: .12em; text-transform: uppercase; margin-bottom: 18px; }
.emc-event-hero h1 { font-size: clamp(44px, 6vw, 86px); line-height: .92; letter-spacing: -4px; font-weight: 950; margin: 0; max-width: 960px; }
.emc-event-location { margin-top: 24px; color: #dbe2ec; font-size: clamp(18px, 2vw, 24px); line-height: 1.45; font-weight: 850; max-width: 820px; }
.emc-event-subline { margin-top: 10px; color: var(--emc-muted); font-size: 14px; font-weight: 850; }
.emc-event-intro { margin-top: 28px; max-width: 760px; color: #cbd3df; font-size: 17px; line-height: 1.75; font-weight: 650; }
.emc-event-summary-card { background: linear-gradient(180deg,#111824,#090d15); border: 1px solid var(--emc-line); border-radius: 34px; padding: 24px; box-shadow: 0 24px 80px rgba(0,0,0,.30); }
.emc-event-summary-list { display: grid; gap: 10px; margin-top: 18px; }
.emc-event-summary-list div { display: flex; justify-content: space-between; gap: 16px; border: 1px solid rgba(255,255,255,.07); background: #0b1019; border-radius: 18px; padding: 12px 14px; }
.emc-event-summary-list span { color: var(--emc-muted); font-size: 12px; font-weight: 900; text-transform: uppercase; }
.emc-event-summary-list strong { color: #fff; font-size: 13px; font-weight: 900; text-align: right; }
.emc-event-actions { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 20px; }
.emc-event-note { color: #ffd0bf; font-size: 13px; font-weight: 850; margin-top: 14px; }
.emc-event-info-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 14px; }
.emc-event-info-item { background: #0b1019; border: 1px solid var(--emc-line); border-radius: 24px; padding: 18px; min-height: 104px; }
.emc-event-info-item span { display: block; color: var(--emc-muted); font-size: 11px; font-weight: 950; text-transform: uppercase; letter-spacing: .08em; margin-bottom: 12px; }
.emc-event-info-item strong { display: block; color: #fff; font-size: 16px; font-weight: 900; line-height: 1.3; }
.emc-event-detail-section { padding-top: 0; }
.emc-event-detail-grid { display: grid; grid-template-columns: minmax(0,1fr) 390px; gap: 24px; align-items: start; }
.emc-event-copy-card h2, .emc-event-cta h2 { color: #fff; font-size: clamp(30px, 3.4vw, 48px); line-height: 1; letter-spacing: -2px; font-weight: 950; margin-top: 10px; }
.emc-event-copy-card p { color: #cbd3df; line-height: 1.8; font-weight: 650; margin-top: 18px; }
.emc-event-copy-card small { display: inline-flex; margin-top: 18px; color: #ffd0bf; font-size: 13px; font-weight: 850; }
.emc-event-tags div { display: flex; flex-wrap: wrap; gap: 9px; margin-top: 18px; }
.emc-event-cta { overflow: hidden; position: relative; }
.emc-eyebrow {
  display: inline-flex;
  padding: 10px 15px;
  border-radius: 999px;
  background: rgba(255,59,0,.10);
  border: 1px solid rgba(255,59,0,.28);
  color: #ffc2ad;
  font-size: 13px;
  font-weight: 900;
  margin-bottom: 22px;
}
.emc-page h1 { font-size: clamp(50px, 7vw, 98px); line-height: .9; letter-spacing: -5.5px; font-weight: 900; margin: 0 0 26px; }
.emc-page h1 span { background: linear-gradient(135deg,#fff 0%,#ffd0bf 42%,#ff6e2d 82%); -webkit-background-clip: text; color: transparent; }
.emc-hero h1 { max-width: 980px; font-size: clamp(40px, 5vw, 70px); line-height: .92; letter-spacing: -3.8px; margin-bottom: 16px; }
.emc-hero-copy { max-width: 920px; color: #cbd3df; font-size: 18px; line-height: 1.55; margin-bottom: 0; }
.emc-hero-actions { display: flex; gap: 12px; flex-wrap: wrap; margin-top: 14px; margin-bottom: 0; }
.emc-trust { display: flex; gap: 10px; flex-wrap: wrap; }
.emc-trust span { background: rgba(255,255,255,.055); border: 1px solid var(--emc-line); border-radius: 999px; padding: 10px 13px; color: #dbe2ec; font-size: 13px; font-weight: 900; }
.emc-vehicle-strip { position: relative; z-index: 2; margin-top: -40px; padding-bottom: 26px; }
.emc-vehicle-inner {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
  border: 1px solid rgba(255,59,0,.28);
  border-radius: 26px;
  background: rgba(20,12,13,.94);
  box-shadow: 0 24px 80px rgba(255,59,0,.16), 0 18px 60px rgba(0,0,0,.34);
  padding: 15px 16px 15px 20px;
}
.emc-vehicle-inner > span {
  color: #ffd3c5;
  font-size: 12px;
  font-weight: 900;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.emc-vehicle-tabs { display: inline-flex; gap: 7px; border: 1px solid rgba(255,255,255,.12); border-radius: 20px; background: rgba(0,0,0,.34); padding: 6px; min-width: 360px; }
.emc-vehicle-tabs-compact { min-width: 280px; }
.emc-vehicle-tabs button {
  flex: 1;
  min-height: 38px;
  border: 0;
  border-radius: 14px;
  background: transparent;
  color: #eef2f7;
  padding: 0 18px;
  font-size: 13px;
  font-weight: 900;
  cursor: pointer;
  border: 1px solid transparent;
}
.emc-vehicle-tabs button.emc-active {
  background: linear-gradient(135deg, #ff3b00, #e10600);
  color: #fff;
  border-color: rgba(255,255,255,.18);
  box-shadow: 0 10px 28px rgba(225,6,0,.30);
}
.emc-hero-search {
  margin-top: 22px;
  display: grid;
  gap: 14px;
  max-width: 100%;
  padding: 16px;
  border: 1px solid var(--emc-line2);
  background:
    linear-gradient(180deg, rgba(18,24,35,.88), rgba(8,12,20,.88));
  backdrop-filter: blur(18px);
  border-radius: 30px;
  box-shadow: var(--emc-shadow);
}
.emc-hero-search .emc-btn { min-height: 64px; align-self: stretch; border-radius: 19px; }
.emc-hero-decision-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(260px, .78fr);
  gap: 12px;
  align-items: stretch;
}
.emc-control-label {
  display: block;
  margin: 0 0 8px 4px;
  color: #ffc7b5;
  font-size: 11px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.emc-vehicle-tabs-hero {
  width: 100%;
  min-width: 0;
  min-height: 58px;
  border-radius: 22px;
  background: rgba(0,0,0,.30);
}
.emc-hero-location-card {
  min-width: 0;
}
.emc-hero-location-actions {
  display: flex;
  gap: 8px;
}
.emc-location-trigger {
  min-height: 58px;
  flex: 1;
  min-width: 0;
  display: grid;
  grid-template-columns: 38px minmax(0, 1fr);
  column-gap: 11px;
  align-items: center;
  text-align: left;
  border: 1px solid rgba(255,255,255,.12);
  border-radius: 22px;
  padding: 7px 13px 7px 8px;
  background: rgba(255,255,255,.065);
  color: #fff;
}
.emc-location-trigger span {
  grid-row: span 2;
  width: 38px;
  height: 38px;
  display: grid;
  place-items: center;
  border-radius: 15px;
  background: linear-gradient(135deg, var(--emc-orange), var(--emc-orange2));
  box-shadow: 0 12px 28px rgba(255,59,0,.25);
}
.emc-location-trigger strong {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: 14px;
  font-weight: 950;
}
.emc-location-trigger small {
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--emc-muted);
  font-size: 12px;
  font-weight: 850;
}
.emc-location-clear {
  min-height: 58px;
  border: 1px solid var(--emc-line);
  border-radius: 18px;
  padding: 0 14px;
  background: rgba(255,255,255,.06);
  color: #fff;
  font-size: 12px;
  font-weight: 900;
}
.emc-location-inline-message {
  margin: 8px 0 0 4px;
  color: #ffd0bf;
  font-size: 12px;
  font-weight: 850;
}
.emc-hero-fields {
  display: grid;
  grid-template-columns: minmax(0, 1.25fr) minmax(120px, .72fr) minmax(120px, .72fr) minmax(140px, auto);
  gap: 10px;
}
.emc-field { background: #080c14; border: 1px solid rgba(255,255,255,.085); border-radius: 18px; padding: 14px 15px; }
.emc-field label { display: block; color: #8f9aab; font-size: 10px; text-transform: uppercase; letter-spacing: .9px; font-weight: 900; margin-bottom: 8px; }
.emc-field input, .emc-field select { width: 100%; background: transparent; border: 0; outline: 0; color: #fff; font-weight: 800; }
.emc-field input::placeholder { color: #697386; }
.emc-field option { background: #101522; color: #fff; }
.emc-hero-chips {
  display: flex;
  flex-wrap: wrap;
  gap: 10px;
  margin-top: 14px;
}
.emc-hero-chips button {
  border: 1px solid var(--emc-line);
  border-radius: 999px;
  background: rgba(255,255,255,.055);
  color: #dbe2ec !important;
  padding: 9px 12px;
  font-size: 12px;
  font-weight: 900;
  transition: background .2s ease, border-color .2s ease, color .2s ease;
}
.emc-hero-chips button:hover {
  background: rgba(255,59,0,.12);
  border-color: rgba(255,59,0,.30);
  color: #fff !important;
}
.emc-metrics-strip { display: grid; grid-template-columns: repeat(4, 1fr); gap: 12px; margin-top: 28px; }
.emc-metric { background: rgba(255,255,255,.055); border: 1px solid var(--emc-line); border-radius: 24px; padding: 18px; }
.emc-metric strong { display: block; font-size: 28px; letter-spacing: -1px; color: #fff; }
.emc-metric span { color: var(--emc-muted); font-size: 13px; font-weight: 900; }

.emc-north-star { background: linear-gradient(180deg,rgba(255,255,255,.12),rgba(255,255,255,.045)); border: 1px solid var(--emc-line2); border-radius: 42px; padding: 16px; box-shadow: var(--emc-shadow); }
.emc-zone-finder {
  min-height: 100%;
  display: flex;
  flex-direction: column;
  gap: 16px;
  padding: 22px;
  border-radius: 34px;
  border: 1px solid var(--emc-line2);
  background:
    radial-gradient(circle at 68% 28%, rgba(255,59,0,.16), transparent 30%),
    linear-gradient(180deg, rgba(17,24,36,.86), rgba(8,12,20,.92));
  box-shadow: var(--emc-shadow);
}
.emc-zone-finder-head {
  display: flex;
  justify-content: space-between;
  gap: 18px;
  align-items: flex-start;
}
.emc-zone-finder-head h2 {
  font-size: clamp(28px, 3.1vw, 42px);
  letter-spacing: -1.5px;
}
.emc-zone-finder-head span {
  max-width: 150px;
  padding: 10px 12px;
  border-radius: 999px;
  background: rgba(255,255,255,.07);
  border: 1px solid var(--emc-line);
  color: #dbe2ec;
  font-size: 12px;
  font-weight: 900;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.emc-product { background: #070a11; border: 1px solid rgba(255,255,255,.11); border-radius: 34px; overflow: hidden; }
.emc-product-top { height: 58px; background: #101724; display: flex; align-items: center; justify-content: space-between; padding: 0 18px; }
.emc-traffic { display: flex; gap: 7px; }
.emc-traffic i { width: 10px; height: 10px; border-radius: 50%; background: #424c5d; }
.emc-url { height: 29px; width: 58%; border-radius: 999px; background: #080d15; color: #6f7b8e; display: grid; place-items: center; font-size: 12px; font-weight: 900; }
.emc-product-body { display: grid; grid-template-columns: .88fr 1.12fr; gap: 14px; padding: 16px; }
.emc-mini-panel { background: #0d1420; border: 1px solid var(--emc-line); border-radius: 26px; padding: 16px; }
.emc-mini-head { display: flex; align-items: center; justify-content: space-between; margin-bottom: 14px; }
.emc-mini-head h3 { font-size: 16px; font-weight: 900; }
.emc-mini-head span { color: var(--emc-muted); font-size: 12px; font-weight: 900; }
.emc-micro-map { flex: 1; min-height: 300px; position: relative; border-radius: 28px; overflow: hidden; border: 1px solid var(--emc-line); background: radial-gradient(circle at 70% 34%,rgba(255,59,0,.28),transparent 18%), radial-gradient(circle at 42% 54%,rgba(75,163,255,.18),transparent 20%), linear-gradient(135deg,#121b2a,#070a11); }
.emc-micro-map:before {
  content: "";
  position: absolute;
  inset: 18px;
  border-radius: 20px;
  background-image:
    linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 30px 30px;
  mask-image: radial-gradient(circle at 50% 50%, black, transparent 78%);
}
.emc-micro-spain {
  position: absolute;
  left: 3%;
  right: 3%;
  top: 2%;
  bottom: 2%;
  width: 94%;
  height: 96%;
  object-fit: contain;
  opacity: .72;
  filter:
    brightness(.88)
    sepia(.08)
    saturate(.72)
    drop-shadow(0 20px 34px rgba(0,0,0,.36));
}
.emc-micro-dot { position: absolute; width: 46px; height: 46px; border-radius: 50%; display: grid; place-items: center; font-size: 13px; font-weight: 950; color: #fff !important; border: 2px solid #fff; transition: border-color .2s ease, box-shadow .2s ease, transform .2s ease; }
.emc-micro-dot:hover, .emc-micro-dot.emc-active { box-shadow: 0 0 0 6px rgba(255,255,255,.08), 0 0 26px rgba(255,255,255,.28); transform: translateY(-1px); }
.emc-zone-norte{left:33%;top:22%}
.emc-zone-centro{left:48%;top:40%}
.emc-zone-cataluna{left:72%;top:31%}
.emc-zone-levante{left:72%;top:49%}
.emc-zone-sur{left:49%;top:62%}
.emc-zone-canarias{left:22%;top:84%}
.emc-timeline { display: grid; gap: 10px; }
.emc-timeline-row { display: grid; grid-template-columns: 52px 1fr auto; gap: 11px; align-items: center; background: #0a1019; border: 1px solid var(--emc-line); border-radius: 20px; padding: 10px; transition: border-color .2s ease, background .2s ease; }
.emc-timeline-row:hover { background: #121928; border-color: rgba(255,255,255,.18); }
.emc-date-pill { width: 52px; height: 52px; border-radius: 17px; background: #fff; color: #080b11 !important; display: grid; place-items: center; font-weight: 900; }
.emc-timeline-row h4 { font-size: 13px; margin-bottom: 4px; font-weight: 900; color: #fff; }
.emc-timeline-row p { font-size: 12px; color: var(--emc-muted); font-weight: 700; }
.emc-status { font-size: 10px; font-weight: 900; max-width: 92px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
.emc-empty { color: var(--emc-muted); font-weight: 800; }

.emc-section { padding: 82px 0; position: relative; z-index: 1; scroll-margin-top: 112px; }
.emc-location-section { padding-top: 138px; padding-bottom: 20px; }
.emc-location-panel {
  padding: 28px;
  border-radius: 30px;
  border: 1px solid rgba(255,59,0,.24);
  background:
    radial-gradient(circle at 12% 0%, rgba(255,59,0,.26), transparent 30%),
    linear-gradient(180deg, rgba(21,26,36,.96), rgba(9,13,20,.92));
  box-shadow: 0 24px 80px rgba(255,59,0,.12), 0 20px 72px rgba(0,0,0,.30);
}
.emc-location-copy {
  display: flex;
  align-items: flex-start;
  gap: 18px;
}
.emc-location-icon {
  width: 52px;
  height: 52px;
  flex: 0 0 52px;
  display: grid;
  place-items: center;
  border-radius: 18px;
  color: #fff;
  background: linear-gradient(135deg, var(--emc-orange), var(--emc-orange2));
  font-size: 25px;
  font-weight: 900;
  box-shadow: 0 16px 42px rgba(255,59,0,.28);
}
.emc-location-copy h2 {
  font-size: clamp(34px, 3.7vw, 52px);
  letter-spacing: -2px;
  margin-bottom: 8px;
}
.emc-location-copy p {
  color: #cbd3df;
  font-size: 16px;
  font-weight: 750;
  line-height: 1.55;
}
.emc-location-copy small {
  display: block;
  margin-top: 8px;
  color: var(--emc-muted);
  font-size: 12px;
  font-weight: 800;
}
.emc-location-message {
  display: inline-flex;
  margin-top: 12px;
  color: #ffd0bf;
  font-size: 13px;
  font-weight: 850;
}
.emc-location-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 12px;
  margin-top: -52px;
}
.emc-location-chip {
  display: inline-flex;
  align-items: center;
  min-height: 46px;
  padding: 0 14px;
  border-radius: 999px;
  color: #aff8d5;
  background: rgba(24,216,137,.11);
  border: 1px solid rgba(24,216,137,.30);
  font-size: 13px;
  font-weight: 900;
}
.emc-nearby {
  margin-top: 24px;
  padding-top: 22px;
  border-top: 1px solid var(--emc-line);
}
.emc-nearby-head {
  display: flex;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 14px;
}
.emc-nearby-head strong {
  color: #fff;
  font-size: 22px;
  font-weight: 900;
  letter-spacing: -1px;
}
.emc-nearby-head span {
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 850;
}
.emc-nearby-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
}
.emc-nearby-card {
  display: grid;
  grid-template-columns: 72px 1fr;
  gap: 16px;
  padding: 16px;
  border-radius: 26px;
  border: 1px solid var(--emc-line);
  border-top: 2px solid var(--emc-card-accent);
  background: #0b1019;
  transition: background .22s ease, border-color .22s ease;
}
.emc-nearby-card:hover {
  background: #121928;
  border-color: rgba(255,255,255,.2);
}
.emc-nearby-card h3 {
  margin: 11px 0 7px;
  color: #fff;
  font-size: 18px;
  line-height: 1.16;
  font-weight: 900;
}
.emc-nearby-card p {
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 700;
}
.emc-nearby-meta,
.emc-result-meta {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 8px;
}
.emc-distance {
  color: #ffd0bf;
  font-size: 12px;
  font-weight: 900;
}
.emc-filter-status {
  margin-bottom: 20px;
  padding: 16px;
  border: 1px solid var(--emc-line);
  border-radius: 24px;
  background: rgba(8,12,20,.74);
  box-shadow: inset 0 1px 0 rgba(255,255,255,.04);
}
.emc-filter-status-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 18px;
  margin-bottom: 16px;
}
.emc-filter-status strong {
  display: block;
  margin-top: 4px;
  color: #fff;
  font-size: 19px;
  font-weight: 900;
  letter-spacing: -1px;
}
.emc-filter-status p {
  margin-top: 4px;
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 800;
}
.emc-explorer-section { padding-top: 28px; }
.emc-explorer-shell {
  padding: 22px;
  border-radius: 38px;
  border: 1px solid rgba(255,255,255,.14);
  background:
    radial-gradient(circle at 12% 0%, rgba(255,59,0,.14), transparent 28%),
    linear-gradient(180deg, rgba(15,22,34,.92), rgba(7,10,16,.94));
  box-shadow: 0 30px 90px rgba(0,0,0,.34);
}
.emc-explorer-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 24px;
  margin-bottom: 18px;
}
.emc-explorer-head h2 {
  font-size: clamp(34px, 4vw, 56px);
  letter-spacing: -2.4px;
  line-height: .95;
}
.emc-explorer-head p {
  max-width: 740px;
  margin-top: 10px;
  color: #aab3c3;
  font-size: 15px;
  font-weight: 750;
  line-height: 1.55;
}
.emc-view-tabs {
  display: inline-flex;
  gap: 7px;
  padding: 6px;
  border-radius: 20px;
  border: 1px solid rgba(255,255,255,.12);
  background: rgba(0,0,0,.30);
}
.emc-view-tabs button {
  min-height: 40px;
  min-width: 106px;
  border: 0;
  border-radius: 15px;
  background: transparent;
  color: #dbe2ec;
  padding: 0 16px;
  font-size: 13px;
  font-weight: 950;
}
.emc-view-tabs button.emc-active {
  color: #07090f;
  background: #fff;
  box-shadow: 0 12px 32px rgba(255,255,255,.10);
}
.emc-active-filter-bar {
  display: grid;
  grid-template-columns: auto minmax(0, 1fr) auto;
  align-items: center;
  gap: 12px;
  margin-bottom: 18px;
  padding: 12px 14px;
  border-radius: 22px;
  border: 1px solid rgba(255,59,0,.22);
  background: rgba(255,59,0,.08);
}
.emc-active-filter-bar span {
  color: #ffc7b5;
  font-size: 11px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.emc-active-filter-bar strong {
  overflow: hidden;
  color: #fff;
  font-size: 14px;
  font-weight: 900;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.emc-active-filter-bar button {
  border: 0;
  border-radius: 999px;
  background: #fff;
  color: #07090f;
  padding: 9px 12px;
  font-size: 12px;
  font-weight: 950;
}
.emc-list-view {
  display: grid;
  grid-template-columns: minmax(300px, .72fr) minmax(0, 1fr);
  gap: 18px;
}
.emc-featured-column {
  display: grid;
  align-content: start;
  gap: 12px;
}
.emc-list-section-title {
  padding: 18px;
  border-radius: 26px;
  border: 1px solid var(--emc-line);
  background: rgba(8,12,20,.70);
}
.emc-list-section-title span {
  display: block;
  color: var(--emc-orange);
  font-size: 11px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .10em;
  margin-bottom: 8px;
}
.emc-list-section-title strong {
  color: #fff;
  font-size: 24px;
  line-height: 1.05;
  letter-spacing: -1px;
  font-weight: 950;
}
.emc-featured-event {
  display: grid;
  grid-template-columns: 74px 1fr;
  gap: 14px;
  padding: 15px;
  border-radius: 24px;
  border: 1px solid var(--emc-line);
  border-top: 2px solid var(--emc-card-accent);
  background: rgba(8,12,20,.78);
  transition: background .2s ease, border-color .2s ease;
}
.emc-featured-event:hover {
  background: rgba(18,25,40,.92);
  border-color: rgba(255,255,255,.20);
}
.emc-featured-event h3 {
  margin: 10px 0 6px;
  color: #fff;
  font-size: 18px;
  line-height: 1.12;
  font-weight: 950;
}
.emc-featured-event p,
.emc-featured-event small {
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 800;
  line-height: 1.45;
}
.emc-event-list {
  display: grid;
  gap: 12px;
}
.emc-list-card {
  display: grid;
  grid-template-columns: 72px minmax(0, 1fr) auto;
  align-items: center;
  gap: 16px;
  min-height: 118px;
  padding: 16px;
  border-radius: 26px;
  border: 1px solid var(--emc-line);
  border-left: 3px solid var(--emc-card-accent);
  background: rgba(10,16,25,.82);
  transition: background .2s ease, border-color .2s ease;
}
.emc-list-card:hover {
  background: rgba(18,25,40,.94);
  border-color: rgba(255,255,255,.20);
}
.emc-list-card h3 {
  margin: 10px 0 6px;
  color: #fff;
  font-size: 21px;
  line-height: 1.08;
  letter-spacing: -.6px;
  font-weight: 950;
}
.emc-list-card p {
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 800;
}
.emc-map-view {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 360px;
  gap: 18px;
}
.emc-map-stage {
  min-height: 650px;
  position: relative;
  overflow: hidden;
  border-radius: 32px;
  border: 1px solid var(--emc-line);
  background:
    radial-gradient(circle at 69% 32%, rgba(255,59,0,.22), transparent 20%),
    radial-gradient(circle at 36% 52%, rgba(75,163,255,.16), transparent 24%),
    linear-gradient(135deg,#121b2a,#070a11);
}
.emc-map-stage:before {
  content: "";
  position: absolute;
  inset: 22px;
  border-radius: 26px;
  background-image:
    linear-gradient(rgba(255,255,255,.035) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255,255,255,.035) 1px, transparent 1px);
  background-size: 36px 36px;
  mask-image: radial-gradient(circle at 50% 50%, black, transparent 78%);
}
.emc-map-stage .emc-micro-dot {
  width: 58px;
  height: 58px;
  font-size: 15px;
}
.emc-zone-list {
  display: grid;
  align-content: start;
  gap: 10px;
}
.emc-zone-list button {
  display: grid;
  gap: 8px;
  min-height: 86px;
  padding: 16px;
  text-align: left;
  border-radius: 24px;
  border: 1px solid var(--emc-line);
  background: rgba(8,12,20,.72);
  color: #fff;
}
.emc-zone-list button.emc-active,
.emc-zone-list button:hover {
  border-color: rgba(255,59,0,.38);
  background: rgba(255,59,0,.10);
}
.emc-zone-list strong {
  font-size: 20px;
  font-weight: 950;
  letter-spacing: -.6px;
}
.emc-zone-list span {
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 850;
  line-height: 1.35;
}
.emc-calendar-embed {
  margin-top: 4px;
}
.emc-section-head { display: flex; align-items: flex-end; justify-content: space-between; gap: 34px; margin-bottom: 34px; }
.emc-kicker { font-size: 12px; text-transform: uppercase; letter-spacing: 1.2px; color: var(--emc-orange); font-weight: 900; margin-bottom: 10px; }
.emc-page h2 { font-size: clamp(36px, 4.8vw, 64px); line-height: 1; letter-spacing: -2.8px; font-weight: 900; }
.emc-section-head p { max-width: 570px; color: #aab3c3; line-height: 1.75; font-weight: 600; }
.emc-discovery-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 18px;
  margin-bottom: 24px;
  padding: 18px 20px;
  border-radius: 28px;
  border: 1px solid var(--emc-line);
  background: rgba(12,16,25,.82);
  box-shadow: 0 18px 60px rgba(0,0,0,.22);
}
.emc-discovery-bar strong {
  display: block;
  margin-top: 4px;
  color: #fff;
  font-size: 23px;
  font-weight: 900;
  letter-spacing: -1px;
}
.emc-discovery-bar p {
  margin-top: 4px;
  color: var(--emc-muted);
  font-size: 13px;
  font-weight: 800;
}
.emc-discovery-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 10px;
}
.emc-explorer { display: grid; grid-template-columns: 1.25fr .75fr; gap: 24px; }
.emc-panel { background: linear-gradient(180deg,#111824,#090d15); border: 1px solid var(--emc-line); border-radius: 40px; padding: 28px; box-shadow: 0 24px 80px rgba(0,0,0,.24); }
.emc-map-bg { position: absolute; inset: 0; background: radial-gradient(circle at 28% 20%,rgba(255,59,0,.25),transparent 20%), radial-gradient(circle at 74% 36%,rgba(75,163,255,.15),transparent 22%), radial-gradient(circle at 45% 76%,rgba(24,216,137,.10),transparent 22%), linear-gradient(135deg,#121a28,#070a11); }
.emc-zone-board { position: relative; min-height: 620px; overflow: hidden; }
.emc-zone-board-head, .emc-zone-card-grid, .emc-map-note { position: relative; z-index: 1; }
.emc-zone-board-head { display: flex; justify-content: space-between; gap: 24px; align-items: flex-end; margin-bottom: 28px; }
.emc-zone-board-head h3 { font-size: clamp(32px, 4vw, 54px); line-height: 1; letter-spacing: -2px; font-weight: 900; }
.emc-zone-board-head p { max-width: 420px; color: #aab3c3; line-height: 1.65; font-weight: 650; }
.emc-zone-card-grid { display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 14px; }
.emc-zone-card {
  min-height: 150px;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  gap: 18px;
  padding: 20px;
  border-radius: 28px;
  border: 1px solid rgba(255,255,255,.12);
  border-top: 2px solid var(--emc-zone-accent);
  background: rgba(8,12,20,.76);
  color: #fff !important;
  text-align: left;
  transition: background .2s ease, border-color .2s ease, box-shadow .2s ease;
}
.emc-zone-card-all { border-top-color: #fff; }
.emc-zone-card:hover, .emc-zone-card.emc-selected {
  background: rgba(18,25,40,.92);
  border-color: rgba(255,255,255,.24);
  box-shadow: inset 0 0 0 1px rgba(255,255,255,.04), 0 18px 55px rgba(0,0,0,.22);
}
.emc-zone-card-top { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; }
.emc-zone-card strong { display: block; font-size: 25px; letter-spacing: -1px; color: #fff; }
.emc-zone-card small { display: block; margin-top: 8px; color: #9ea8ba; font-size: 12px; font-weight: 800; line-height: 1.45; }
.emc-zone-count { min-width: 48px; height: 48px; display: grid; place-items: center; border-radius: 16px; background: #fff; color: #07090f !important; font-size: 20px; font-weight: 900; }
.emc-zone-card-action { color: #ffc1ad; font-size: 13px; font-weight: 900; }
.emc-map-note { margin-top: 22px; max-width: 470px; background: rgba(8,11,18,.76); border: 1px solid var(--emc-line); backdrop-filter: blur(16px); border-radius: 24px; padding: 16px; color: #cbd3df; font-size: 13px; line-height: 1.6; font-weight: 700; }
.emc-cluster:hover { transform: none; }
.emc-cluster:hover .emc-main { stroke: rgba(255,255,255,.9); filter: drop-shadow(0 0 18px rgba(255,59,0,.45)); }

.emc-side-stack { display: grid; gap: 16px; }
.emc-segmented { display: grid; grid-template-columns: repeat(2, 1fr); gap: 10px; }
.emc-segment { background: #0b1019; border: 1px solid var(--emc-line); color: #dbe2ec !important; border-radius: 18px; padding: 13px; font-weight: 900; text-align: left; transition: background .2s ease, color .2s ease, border-color .2s ease; }
.emc-segment.emc-active, .emc-segment:hover { background: #fff; color: #07090f !important; border-color: #fff; }
.emc-summary-grid { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; margin-top: 18px; }
.emc-summary { background: #0b1019; border: 1px solid var(--emc-line); border-radius: 22px; padding: 18px; }
.emc-summary strong { display: block; font-size: 28px; letter-spacing: -1px; margin-bottom: 5px; color: #fff; }
.emc-summary span { color: var(--emc-muted); font-size: 13px; font-weight: 900; }
.emc-zone-detail h3 { font-size: 30px; letter-spacing: -1.2px; margin-bottom: 10px; font-weight: 900; }
.emc-zone-detail p { color: var(--emc-muted); line-height: 1.7; font-weight: 600; }
.emc-zone-events { display: grid; gap: 10px; margin-top: 18px; }
.emc-zone-event { display: flex; justify-content: space-between; gap: 12px; background: #0b1019; border: 1px solid var(--emc-line); border-radius: 18px; padding: 13px; transition: border-color .2s ease, background .2s ease; }
.emc-zone-event:hover { background: #121928; border-color: rgba(255,255,255,.18); }
.emc-zone-event strong { font-size: 14px; color: #fff; }
.emc-zone-event span { color: var(--emc-muted); font-size: 12px; font-weight: 800; }

.emc-calendar-wrap { display: grid; grid-template-columns: 1.08fr .92fr; gap: 24px; scroll-margin-top: 112px; align-items: start; }
.emc-calendar-panel { padding: 22px; }
.emc-calendar-filter-panel { margin-bottom: 24px; }
.emc-calendar-filter-head {
  display: flex;
  align-items: flex-end;
  justify-content: space-between;
  gap: 16px;
  margin-bottom: 16px;
}
.emc-calendar-filter-head h3 {
  color: #fff;
  font-size: 25px;
  font-weight: 900;
  letter-spacing: -1px;
}
.emc-calendar-filter-actions {
  display: flex;
  flex-wrap: wrap;
  justify-content: flex-end;
  gap: 10px;
}
.emc-calendar-fields {
  display: grid;
  grid-template-columns: 1.2fr .9fr .9fr;
  gap: 10px;
}
.emc-calendar-vehicle-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  margin-bottom: 10px;
}
.emc-calendar-vehicle-row > span {
  color: #ffc7b5;
  font-size: 11px;
  font-weight: 950;
  text-transform: uppercase;
  letter-spacing: .08em;
}
.emc-vehicle-tabs-calendar {
  min-width: 300px;
  background: rgba(0,0,0,.24);
}
.emc-calendar-toolbar { display: flex; justify-content: space-between; gap: 14px; align-items: center; margin-bottom: 18px; padding-top: 4px; }
.emc-month-title h3 { font-size: 30px; letter-spacing: -1.2px; font-weight: 900; }
.emc-month-title p { color: var(--emc-muted); font-weight: 700; margin-top: 4px; }
.emc-month-actions { display: flex; gap: 8px; }
.emc-icon { width: 42px; height: 42px; border-radius: 14px; border: 1px solid var(--emc-line); background: #0b1019; color: #fff !important; font-weight: 900; }
.emc-icon:hover { background: #121928; border-color: rgba(255,255,255,.18); }
.emc-weekdays, .emc-month { display: grid; grid-template-columns: repeat(7, 1fr); gap: 9px; }
.emc-weekdays { margin-bottom: 9px; }
.emc-weekdays div { text-align: center; color: #758095; font-size: 12px; font-weight: 900; }
.emc-day { min-height: 86px; background: #0b1019; border: 1px solid var(--emc-line); border-radius: 18px; padding: 10px; color: #9aa6ba !important; font-weight: 900; position: relative; transition: background .2s ease, border-color .2s ease; text-align: left; }
.emc-day:hover { background: #121928; border-color: rgba(255,255,255,.18); }
.emc-day.emc-has { background: linear-gradient(180deg,rgba(255,59,0,.16),#0b1019); border-color: rgba(255,59,0,.32); color: #fff !important; }
.emc-day.emc-focus { outline: 2px solid var(--emc-orange); background: linear-gradient(180deg,rgba(255,59,0,.25),#0b1019); }
.emc-day.emc-today {
  border-color: rgba(255,181,71,.78);
  color: #fff !important;
  background:
    radial-gradient(circle at 82% 18%, rgba(255,181,71,.30), transparent 28%),
    linear-gradient(180deg, rgba(255,59,0,.22), #0b1019 72%);
  box-shadow:
    inset 0 0 0 1px rgba(255,255,255,.08),
    inset 0 18px 38px rgba(255,181,71,.08),
    0 0 0 1px rgba(255,181,71,.12),
    0 18px 44px rgba(255,59,0,.18);
}
.emc-day small { position: absolute; right: 9px; top: 9px; color: #cbd3df; font-size: 10px; }
.emc-dots { position: absolute; left: 10px; right: 10px; bottom: 10px; display: flex; gap: 5px; flex-wrap: wrap; }
.emc-edot { width: 7px; height: 7px; border-radius: 50%; }
.emc-agenda { display: grid; gap: 12px; }
.emc-agenda-head { display: flex; align-items: flex-start; justify-content: space-between; gap: 16px; margin-bottom: 18px; }
.emc-agenda-head h3 { font-size: 27px; letter-spacing: -1px; font-weight: 900; }
.emc-badge { display: inline-flex; padding: 8px 11px; border-radius: 999px; background: rgba(255,59,0,.12); border: 1px solid rgba(255,59,0,.25); color: #ffc1ad !important; font-size: 12px; font-weight: 900; }
.emc-event-row { display: grid; grid-template-columns: 78px 1fr auto; gap: 14px; align-items: center; background: #0b1019; border: 1px solid var(--emc-line); border-radius: 24px; padding: 14px; transition: background .2s ease, border-color .2s ease; }
.emc-event-row:hover { background: #121928; border-color: rgba(255,255,255,.18); transform: none; }
.emc-datebox { background: #fff; color: #07090f !important; border-radius: 18px; padding: 10px; text-align: center; font-weight: 900; }
.emc-datebox small { display: block; color: #626b7b; font-size: 11px; margin-top: 2px; }
.emc-event-row h4 { font-size: 17px; margin-bottom: 5px; font-weight: 900; color: #fff; }
.emc-event-row p { color: var(--emc-muted); font-size: 13px; font-weight: 700; }
.emc-event-actions { display: flex; flex-direction: column; gap: 8px; align-items: flex-end; }
.emc-ticket-action { display: inline-flex; border-radius: 999px; border: 1px solid rgba(255,59,0,.35); background: rgba(255,59,0,.12); color: #ffc1ad !important; padding: 8px 12px; font-size: 12px; font-weight: 900; }
.emc-agenda-empty { border: 1px dashed rgba(255,255,255,.16); border-radius: 24px; padding: 18px; background: rgba(255,255,255,.035); }
.emc-agenda-empty h4 { color: #fff; font-size: 18px; font-weight: 900; margin-bottom: 6px; }
.emc-agenda-empty p { color: var(--emc-muted); font-size: 13px; font-weight: 700; margin-bottom: 14px; }
.emc-event-row-compact { grid-template-columns: 66px 1fr auto; }

.emc-intent-grid { display: grid; grid-template-columns: repeat(4, 1fr); gap: 18px; }
.emc-intent-card { position: relative; min-height: 240px; background: linear-gradient(180deg,#111824,#090d15); border: 1px solid var(--emc-line); border-radius: 32px; padding: 24px; overflow: hidden; transition: background .25s ease, border-color .25s ease, box-shadow .25s ease; text-align: left; color: #fff !important; }
.emc-intent-card:hover { background: linear-gradient(180deg,#151f30,#0b1019); border-color: rgba(255,255,255,.2); box-shadow: 0 28px 75px rgba(0,0,0,.33); transform: none; }
.emc-intent-card:after { content: ""; position: absolute; width: 150px; height: 150px; right: -45px; bottom: -45px; border-radius: 50%; background: rgba(255,255,255,.045); }
.emc-intent-icon { width: 58px; height: 58px; border-radius: 20px; display: grid; place-items: center; font-size: 20px; font-weight: 900; margin-bottom: 32px; background: rgba(255,255,255,.08); border: 1px solid var(--emc-line); }
.emc-intent-card h3 { font-size: 25px; letter-spacing: -1px; margin-bottom: 10px; font-weight: 900; }
.emc-intent-card p { color: var(--emc-muted); line-height: 1.6; font-size: 14px; }
.emc-intent-number { position: absolute; right: 20px; bottom: 18px; font-size: 44px; font-weight: 900; color: rgba(255,255,255,.08); }

.emc-results-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 18px; }
.emc-result-card { display: grid; grid-template-columns: 72px 1fr; gap: 16px; background: linear-gradient(180deg,#111824,#090d15); border: 1px solid var(--emc-line); border-top: 2px solid var(--emc-card-accent); border-radius: 28px; padding: 18px; transition: background .22s ease, border-color .22s ease; }
.emc-result-card:hover { background: linear-gradient(180deg,#151f30,#0b1019); border-color: rgba(255,255,255,.2); transform: none; }
.emc-result-date { height: 72px; border-radius: 20px; background: #fff; color: #07090f !important; display: grid; place-items: center; text-align: center; font-size: 26px; font-weight: 900; }
.emc-result-date small { display: block; font-size: 11px; color: #626b7b; }
.emc-result-card h3 { margin: 12px 0 8px; font-size: 19px; font-weight: 900; line-height: 1.15; color: #fff; }
.emc-result-card p { color: var(--emc-muted); font-size: 13px; font-weight: 700; }
.emc-card-action { display: inline-flex; margin-top: 14px; border-radius: 999px; background: #fff; color: #07090f !important; padding: 8px 12px; font-size: 12px; font-weight: 900; }

.emc-pro-panel { padding: 46px; display: grid; grid-template-columns: 1fr .9fr; gap: 34px; align-items: center; overflow: hidden; position: relative; }
.emc-pro-panel:before { content: ""; position: absolute; width: 380px; height: 380px; right: -110px; top: -120px; border-radius: 50%; background: rgba(255,59,0,.12); filter: blur(20px); }
.emc-pro-copy { color: var(--emc-muted); line-height: 1.75; margin-top: 18px; font-weight: 600; }
.emc-pro-actions { margin-top: 24px; display: flex; gap: 12px; flex-wrap: wrap; }
.emc-checks { display: grid; grid-template-columns: repeat(2, 1fr); gap: 12px; position: relative; }
.emc-check { background: #0b1019; border: 1px solid var(--emc-line); border-radius: 22px; padding: 18px; }
.emc-check strong { display: block; font-size: 26px; letter-spacing: -1px; margin-bottom: 6px; color: #fff; }
.emc-check span { color: var(--emc-muted); font-size: 13px; font-weight: 900; }
.emc-footer { border-top: 1px solid var(--emc-line); padding: 52px 0; color: var(--emc-muted); position: relative; z-index: 1; }
.emc-footer-grid { display: flex; justify-content: space-between; gap: 24px; flex-wrap: wrap; }
.emc-footer p { margin-top: 14px; max-width: 470px; line-height: 1.7; }

@media (max-width: 1180px) {
  .emc-hero-grid, .emc-event-hero-grid, .emc-event-detail-grid, .emc-explorer, .emc-calendar-wrap, .emc-pro-panel { grid-template-columns: 1fr; }
  .emc-list-view, .emc-map-view { grid-template-columns: 1fr; }
  .emc-filter-rail { align-items: stretch; }
  .emc-product-body { grid-template-columns: 1fr; }
  .emc-intent-grid, .emc-results-grid, .emc-nearby-grid, .emc-event-info-grid { grid-template-columns: repeat(2, 1fr); }
  .emc-hero-fields, .emc-calendar-fields { grid-template-columns: 1fr 1fr; }
  .emc-location-actions { justify-content: flex-start; margin-top: 20px; }
}
@media (max-width: 980px) {
  .emc-navlinks { display: none; }
  .emc-nav { padding-left: 16px; }
  .emc-filter-rail { flex-wrap: wrap; }
  .emc-location-menu { margin-left: auto; }
}
@media (max-width: 760px) {
  .emc-navlinks, .emc-nav-actions .emc-btn-dark { display: none; }
  .emc-header-shell { top: 10px; border-radius: 24px; }
  .emc-nav { min-height: 50px; padding-left: 6px; }
  .emc-filter-rail { display: grid; grid-template-columns: 1fr; gap: 9px; }
  .emc-location-menu { margin-left: 0; }
  .emc-location-menu summary { width: 100%; min-width: 0; }
  .emc-location-popover { left: 0; right: auto; width: 100%; }
  .emc-nav-actions .emc-btn-primary { padding: 11px 13px; }
  .emc-brand-logo { min-height: 42px; padding: 5px 9px; }
  .em-logo-horizontal { height: 36px; max-width: 178px; }
  .em-logo-mark { height: 34px; width: 34px; }
  .emc-hero { padding-top: 24px; }
  .emc-location-section { padding-top: 170px; }
  .emc-event-hero { padding-top: 130px; }
  .emc-event-hero h1 { letter-spacing: -3px; }
  .emc-page h1 { letter-spacing: -3px; }
  .emc-hero-copy { font-size: 17px; }
  .emc-metrics-strip, .emc-summary-grid, .emc-intent-grid, .emc-checks, .emc-hero-fields, .emc-hero-decision-row, .emc-results-grid, .emc-zone-card-grid, .emc-nearby-grid, .emc-event-info-grid { grid-template-columns: 1fr; }
  .emc-event-summary-card, .emc-event-info-item { border-radius: 24px; }
  .emc-location-panel { padding: 20px; border-radius: 28px; }
  .emc-location-copy { display: block; }
  .emc-location-icon { margin-bottom: 14px; }
  .emc-location-actions { display: grid; grid-template-columns: 1fr; }
  .emc-location-actions .emc-btn, .emc-location-chip { width: 100%; justify-content: center; }
  .emc-nearby-head { display: block; }
  .emc-nearby-card { grid-template-columns: 1fr; }
  .emc-section-head, .emc-zone-board-head { display: block; }
  .emc-discovery-bar { display: block; }
  .emc-discovery-actions { justify-content: stretch; margin-top: 14px; }
  .emc-discovery-actions .emc-btn { width: 100%; }
  .emc-filter-status-head { display: block; }
  .emc-explorer-head { display: block; }
  .emc-view-tabs { width: 100%; margin-top: 16px; display: grid; grid-template-columns: repeat(3, 1fr); }
  .emc-view-tabs button { min-width: 0; }
  .emc-active-filter-bar { grid-template-columns: 1fr; }
  .emc-list-card { grid-template-columns: 1fr; }
  .emc-featured-event { grid-template-columns: 1fr; }
  .emc-map-stage { min-height: 420px; }
  .emc-map-stage .emc-micro-dot { width: 42px; height: 42px; font-size: 12px; }
  .emc-vehicle-inner { display: block; }
  .emc-vehicle-tabs-compact { min-width: 0; width: 100%; }
  .emc-vehicle-tabs { display: grid; grid-template-columns: repeat(3, 1fr); margin-top: 10px; }
  .emc-vehicle-tabs button { padding: 0 10px; }
  .emc-filter-status .emc-btn { width: 100%; }
  .emc-calendar-filter-head { display: block; }
  .emc-calendar-filter-actions { justify-content: stretch; margin-top: 14px; }
  .emc-calendar-filter-actions .emc-btn { flex: 1; }
  .emc-calendar-vehicle-row { display: block; }
  .emc-calendar-vehicle-row .emc-vehicle-tabs { margin-top: 8px; }
  .emc-vehicle-tabs-calendar { min-width: 0; width: 100%; }
  .emc-calendar-fields { grid-template-columns: 1fr; }
  .emc-calendar-toolbar { display: block; }
  .emc-month-actions { margin-top: 14px; flex-wrap: wrap; }
  .emc-zone-finder { padding: 16px; border-radius: 28px; }
  .emc-zone-finder-head { display: block; }
  .emc-zone-finder-head span { display: inline-flex; margin-top: 10px; max-width: 100%; }
  .emc-micro-map { min-height: 360px; }
  .emc-micro-dot { width: 40px; height: 40px; font-size: 12px; }
  .emc-section-head p, .emc-zone-board-head p { margin-top: 16px; }
  .emc-zone-board { min-height: auto; }
  .emc-day { min-height: 58px; padding: 8px; }
  .emc-event-row { grid-template-columns: 1fr; }
  .emc-event-actions { align-items: stretch; }
  .emc-event-actions .emc-card-action, .emc-event-actions .emc-ticket-action { justify-content: center; }
  .emc-status { display: none; }
}
`
    }, void 0, false, {
        fileName: "[project]/components/public/concept/ConceptStyles.tsx",
        lineNumber: 3,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/event-classification.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "VEHICLE_TYPE_LABELS",
    ()=>VEHICLE_TYPE_LABELS,
    "VEHICLE_TYPE_OPTIONS",
    ()=>VEHICLE_TYPE_OPTIONS,
    "getVehicleType",
    ()=>getVehicleType,
    "matchesVehicleFilter",
    ()=>matchesVehicleFilter
]);
const VEHICLE_TYPE_OPTIONS = [
    "moto",
    "coche",
    "mixto",
    "karting",
    "otros"
];
const VEHICLE_TYPE_LABELS = {
    moto: "Moto",
    coche: "Coche",
    mixto: "Mixto",
    karting: "Karting",
    otros: "Otros"
};
const MOTO_TERMS = [
    "fim",
    "fim world championship",
    "fim juniorgp",
    "fim europe",
    "fim enduro",
    "fim motocross",
    "fim trial",
    "fim supermoto",
    "fim minivelocidad",
    "fim moto",
    "rfme",
    "motogp",
    "superbike",
    "esbk",
    "motocross",
    "enduro",
    "trial",
    "supermoto",
    "minivelocidad",
    "mototurismo",
    "motociclismo",
    "moto",
    "moto-ocasion",
    "concentracionesdemotos",
    "concentracion motera",
    "concentracion de motos",
    "motos",
    "motera",
    "moteras",
    "motero",
    "moteros",
    "motoristas",
    "motoalmuerzo",
    "matinal motera",
    "ruta motera",
    "biker",
    "bikers",
    "motoclub",
    "harley",
    "vespa",
    "scooter",
    "custom",
    "tandas para motos",
    "worldsbk",
    "juniorgp"
];
const COCHE_TERMS = [
    "automovilismo",
    "gt winter series",
    "racing weekend",
    "rfeda",
    "rally",
    "rallye",
    "rallysprint",
    "drift",
    "tuning",
    "4x4",
    "coches",
    "turismos",
    "gt",
    "subida",
    "montana",
    "trackday coche",
    "todoterreno"
];
const KARTING_TERMS = [
    "karting",
    "kart"
];
const MIXTO_TERMS = [
    "coches y motos clasicos",
    "coches y motos",
    "vehiculos clasicos",
    "vehiculos clasicos y tuneados",
    "coches clasicos",
    "retro matinal clasicos",
    "concentracion de vehiculos"
];
function normalizeText(value) {
    return value.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function isVehicleType(value) {
    return Boolean(value && VEHICLE_TYPE_OPTIONS.includes(value));
}
function includesAny(text, terms) {
    return terms.some((term)=>{
        const normalizedTerm = normalizeText(term);
        if (/^[a-z0-9]+$/.test(normalizedTerm)) {
            return new RegExp(`(^|[^a-z0-9])${normalizedTerm}([^a-z0-9]|$)`).test(text);
        }
        return text.includes(normalizedTerm);
    });
}
function hasAll(text, terms) {
    return terms.every((term)=>text.includes(term));
}
function getVehicleType(event) {
    const explicitType = normalizeText(String(event.vehicleType || event.vehicle_type || "").trim());
    const titleText = normalizeText(String(event.title || ""));
    const tagsText = normalizeText(Array.isArray(event.tags) ? event.tags.join(" ") : "");
    const sourceText = normalizeText(String(event.source || ""));
    const searchableText = normalizeText([
        event.title,
        event.championship,
        event.discipline,
        event.source,
        tagsText
    ].filter(Boolean).join(" "));
    const isKarting = includesAny(searchableText, KARTING_TERMS);
    const isCanalDifusionMixed = sourceText.includes("canal difusion") && hasAll(tagsText, [
        "coches",
        "motos",
        "clasicos"
    ]);
    const isMixto = includesAny(`${titleText} ${tagsText}`, MIXTO_TERMS) || isCanalDifusionMixed;
    const isMoto = includesAny(searchableText, MOTO_TERMS);
    const isCoche = includesAny(searchableText, COCHE_TERMS);
    if (isVehicleType(explicitType)) {
        if (explicitType === "moto" && isCoche && !isMoto) return "coche";
        if (explicitType === "coche" && isMoto && !isCoche) return "moto";
        return explicitType;
    }
    if (isKarting) return "karting";
    if (isMixto) return "mixto";
    if (isCoche) return "coche";
    if (isMoto) return "moto";
    return "otros";
}
function matchesVehicleFilter(event, filter) {
    if (filter === "todos") {
        return true;
    }
    const vehicleType = getVehicleType(event);
    return vehicleType === filter || vehicleType === "mixto";
}
}),
"[project]/lib/normalizers.ts [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "normalizeRemoteEvent",
    ()=>normalizeRemoteEvent,
    "normalizeRemoteEvents",
    ()=>normalizeRemoteEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-classification.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-ssr] (ecmascript)");
;
;
;
function slugify(text) {
    return String(text || "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
}
function normalizeRemoteEvent(raw, index) {
    if (!raw || typeof raw !== "object") return null;
    const record = raw;
    const title = String(record.title || record.name || "").trim();
    const start = String(record.start || record.startDate || record.date || "").slice(0, 10);
    const endCandidate = String(record.end || record.endDate || record.finishDate || start).slice(0, 10);
    if (!title || !(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isDateText"])(start)) return null;
    const discipline = String(record.discipline || record.category || "Motociclismo").trim();
    const venue = String(record.venue || record.location || "Por confirmar").trim();
    const city = String(record.city || record.locality || "Por confirmar").trim();
    const province = String(record.province || record.state || "Por confirmar").trim();
    const event = {
        id: String(record.id || `${slugify(title)}-${start}-${index}`),
        slug: String(record.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createEventSlug"])(title, start)),
        title,
        championship: String(record.championship || record.series || discipline),
        discipline,
        start,
        end: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isDateText"])(endCandidate) ? endCandidate : start,
        venue,
        city,
        province,
        region: String(record.region || record.community || province),
        level: String(record.level || "Publicado"),
        source: String(record.source || record.feedName || "Fuente externa"),
        sourceUrl: String(record.sourceUrl || record.url || ""),
        ticketUrl: String(record.ticketUrl || record.ticketsUrl || ""),
        tags: Array.isArray(record.tags) ? record.tags.map(String) : [
            discipline
        ],
        vehicleType: String(record.vehicleType || record.vehicle_type || ""),
        vehicle_type: String(record.vehicle_type || record.vehicleType || ""),
        featured: Boolean(record.featured)
    };
    const vehicleType = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["getVehicleType"])(event);
    return {
        ...event,
        vehicleType,
        vehicle_type: vehicleType
    };
}
function normalizeRemoteEvents(payload) {
    const list = Array.isArray(payload) ? payload : typeof payload === "object" && payload !== null && Array.isArray(payload.events) ? payload.events : [];
    const seen = new Set();
    return list.map((item, index)=>normalizeRemoteEvent(item, index)).filter((event)=>Boolean(event)).filter((event)=>{
        const key = `${event.title}-${event.start}-${event.venue}`.toLowerCase();
        if (seen.has(key)) return false;
        seen.add(key);
        return true;
    }).sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(a.start).getTime() - (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(b.start).getTime());
}
}),
"[project]/components/public/concept/ConceptHomePage.tsx [app-ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ConceptHomePage
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptCalendar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptCalendar.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptEventExplorer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptEventExplorer.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptFooter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptFooter.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptHeader.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptHero$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptHero.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptLocationPanel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptLocationPanel.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptResults$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptResults.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptStyles$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/ConceptStyles.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/date-utils.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-classification.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/geo.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$normalizers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/normalizers.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/public/concept/concept-model.ts [app-ssr] (ecmascript)");
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
const ALL_ZONES = "Toda España";
function ConceptHomePage() {
    const [events, setEvents] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [query, setQuery] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    const [discipline, setDiscipline] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("Todas");
    const [zone, setZone] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(ALL_ZONES);
    const [vehicleFilter, setVehicleFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("todos");
    const [view, setView] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("lista");
    const [month, setMonth] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].getMonth());
    const [year, setYear] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].getFullYear());
    const [selectedDay, setSelectedDay] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [userLocation, setUserLocation] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [locationMessage, setLocationMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])("");
    async function refreshEvents() {
        try {
            const response = await fetch(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["API_EVENTS_URL"], {
                cache: "no-store"
            });
            if (!response.ok) {
                throw new Error("No se pudieron cargar eventos");
            }
            setEvents((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$normalizers$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["normalizeRemoteEvents"])(await response.json()));
        } catch  {
            setEvents([]);
        }
    }
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        refreshEvents();
        const timer = window.setInterval(refreshEvents, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AUTO_REFRESH_MS"]);
        return ()=>window.clearInterval(timer);
    }, []);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        setUserLocation((0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptLocationPanel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["readStoredLocation"])());
    }, []);
    const vehicleEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return events.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$classification$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["matchesVehicleFilter"])(event, vehicleFilter));
    }, [
        events,
        vehicleFilter
    ]);
    const upcoming = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return vehicleEvents.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["statusOf"])(event) !== "finalizado").sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(a.start).getTime() - (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(b.start).getTime());
    }, [
        vehicleEvents
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (upcoming[0]) {
            const date = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(upcoming[0].start);
            setMonth(date.getMonth());
            setYear(date.getFullYear());
            setSelectedDay(date);
        }
    }, [
        upcoming
    ]);
    const disciplines = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["unique"])(vehicleEvents.map((event)=>event.discipline)), [
        vehicleEvents
    ]);
    const zones = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["buildZones"])(vehicleEvents), [
        vehicleEvents
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        if (discipline !== "Todas" && !disciplines.includes(discipline)) {
            setDiscipline("Todas");
        }
    }, [
        discipline,
        disciplines
    ]);
    const filtered = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const q = query.trim().toLowerCase();
        const zoneTerms = zones.find((item)=>item.name === zone)?.terms || [];
        const dateSortedEvents = vehicleEvents.filter((event)=>{
            const okQuery = q === "" || (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["eventText"])(event).includes(q);
            const okDiscipline = discipline === "Todas" || event.discipline === discipline;
            const okZone = zone === ALL_ZONES || (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["matchesTerms"])(event, zoneTerms);
            return okQuery && okDiscipline && okZone && (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["statusOf"])(event) !== "finalizado";
        }).sort((a, b)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(a.start).getTime() - (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(b.start).getTime());
        return userLocation ? (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$geo$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["sortEventsByDistance"])(dateSortedEvents, userLocation) : dateSortedEvents;
    }, [
        discipline,
        query,
        userLocation,
        vehicleEvents,
        zone,
        zones
    ]);
    const highlightedEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const featured = filtered.filter((event)=>event.featured);
        return (featured.length ? featured : filtered).slice(0, 4);
    }, [
        filtered
    ]);
    const days = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["daysForMonth"])(year, month), [
        month,
        year
    ]);
    const monthEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        return filtered.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(event.start).getMonth() === month || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(event.end).getMonth() === month);
    }, [
        filtered,
        month
    ]);
    const agendaDay = selectedDay || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["parseDate"])(filtered[0]?.start || new Date().toISOString().slice(0, 10));
    const selectedDayEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>filtered.filter((event)=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["isOnDay"])(event, agendaDay)), [
        agendaDay,
        filtered
    ]);
    const hasActiveFilters = vehicleFilter !== "todos" || query.trim() !== "" || discipline !== "Todas" || zone !== ALL_ZONES;
    const activeLabel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useMemo"])(()=>{
        const parts = [];
        if (vehicleFilter !== "todos") parts.push(vehicleFilter === "moto" ? "Motos" : "Coches");
        if (zone !== ALL_ZONES) parts.push(zone);
        if (discipline !== "Todas") parts.push(discipline);
        if (query.trim()) parts.push(`"${query.trim()}"`);
        return parts.length ? parts.join(" / ") : "Todos los próximos eventos";
    }, [
        discipline,
        query,
        vehicleFilter,
        zone
    ]);
    function scrollToCalendar() {
        document.getElementById("calendario")?.scrollIntoView({
            behavior: "smooth",
            block: "start"
        });
    }
    function selectVehicle(nextFilter) {
        setVehicleFilter(nextFilter);
        setDiscipline("Todas");
    }
    function requestLocation() {
        setLocationMessage("");
        if (!("geolocation" in navigator)) {
            setLocationMessage("Ubicación no disponible en este navegador.");
            return;
        }
        navigator.geolocation.getCurrentPosition((position)=>{
            const location = {
                lat: position.coords.latitude,
                lng: position.coords.longitude
            };
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptLocationPanel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["saveLocation"])(location);
            setUserLocation(location);
            setLocationMessage("");
        }, ()=>{
            setLocationMessage("No se ha podido activar la ubicación.");
        }, {
            enableHighAccuracy: false,
            maximumAge: 1000 * 60 * 30,
            timeout: 10000
        });
    }
    function clearLocation() {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptLocationPanel$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["removeStoredLocation"])();
        setUserLocation(null);
        setLocationMessage("");
    }
    function selectHeroZone(nextZone) {
        setZone(nextZone);
    }
    function selectHeroDiscipline(nextDiscipline) {
        setDiscipline(nextDiscipline);
    }
    function showThisMonth() {
        setMonth(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].getMonth());
        setYear(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$date$2d$utils$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["TODAY"].getFullYear());
        setView("calendario");
        scrollToCalendar();
    }
    function clearFilters() {
        setVehicleFilter("todos");
        setZone(ALL_ZONES);
        setQuery("");
        setDiscipline("Todas");
        scrollToCalendar();
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "emc-page",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptStyles$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                lineNumber: 219,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptHeader$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                onCalendar: scrollToCalendar
            }, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                lineNumber: 220,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptHero$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                zones: zones,
                disciplines: disciplines,
                query: query,
                discipline: discipline,
                zone: zone,
                vehicleFilter: vehicleFilter,
                locationLabel: userLocation ? "Eventos cercanos primero" : zone,
                locationMessage: locationMessage,
                userLocationActive: Boolean(userLocation),
                onSearch: scrollToCalendar,
                onQuery: setQuery,
                onDiscipline: selectHeroDiscipline,
                onZone: selectHeroZone,
                onVehicle: selectVehicle,
                onUseLocation: requestLocation,
                onClearLocation: clearLocation
            }, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                lineNumber: 221,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptEventExplorer$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                        activeLabel: userLocation ? `${activeLabel} / más cercanos primero` : activeLabel,
                        calendar: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptCalendar$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {
                            year: year,
                            month: month,
                            setMonth: setMonth,
                            days: days,
                            agendaDay: agendaDay,
                            selectedDayEvents: selectedDayEvents,
                            fallbackEvents: highlightedEvents,
                            monthEventCount: monthEvents.length,
                            monthDisciplineCount: (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$concept$2d$model$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["unique"])(monthEvents.map((event)=>event.discipline)).length,
                            filtered: filtered,
                            activeLabel: userLocation ? `${activeLabel} / más cercanos primero` : activeLabel,
                            hasActiveFilters: hasActiveFilters,
                            query: query,
                            discipline: discipline,
                            zone: zone,
                            vehicleFilter: vehicleFilter,
                            disciplines: disciplines,
                            zones: zones,
                            setQuery: setQuery,
                            setDiscipline: selectHeroDiscipline,
                            onVehicle: selectVehicle,
                            onZoneSelect: selectHeroZone,
                            onThisMonth: showThisMonth,
                            onDay: setSelectedDay,
                            onClearFilters: clearFilters
                        }, void 0, false, {
                            fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                            lineNumber: 243,
                            columnNumber: 13
                        }, this),
                        filtered: filtered,
                        hasActiveFilters: hasActiveFilters,
                        userLocation: userLocation,
                        view: view,
                        zone: zone,
                        zones: zones,
                        onClearFilters: clearFilters,
                        onView: setView,
                        onZone: selectHeroZone
                    }, void 0, false, {
                        fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                        lineNumber: 240,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptResults$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                        fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                        lineNumber: 281,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                lineNumber: 239,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$public$2f$concept$2f$ConceptFooter$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
                lineNumber: 283,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/public/concept/ConceptHomePage.tsx",
        lineNumber: 218,
        columnNumber: 5
    }, this);
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0.-krq0._.js.map