module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/lib/scrapers/rfme.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "cleanText",
    ()=>cleanText,
    "normalizeDisciplineFromText",
    ()=>normalizeDisciplineFromText,
    "parseSpanishDate",
    ()=>parseSpanishDate,
    "scrapeRfmeEvents",
    ()=>scrapeRfmeEvents
]);
const RFME_SOURCE = "RFME";
const RFME_SOURCE_ID = "rfme";
const RFME_CHAMPIONSHIP_PAGES = [
    {
        url: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike"
    },
    {
        url: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross"
    },
    {
        url: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad"
    },
    {
        url: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        championship: "Campeonato de España de Trial",
        discipline: "Trial"
    },
    {
        url: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro"
    },
    {
        url: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad"
    },
    {
        url: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        championship: "Copa de España de Mototurismo",
        discipline: "Mototurismo"
    }
];
const MONTHS = {
    enero: "01",
    febrero: "02",
    marzo: "03",
    abril: "04",
    mayo: "05",
    junio: "06",
    julio: "07",
    agosto: "08",
    septiembre: "09",
    setiembre: "09",
    octubre: "10",
    noviembre: "11",
    diciembre: "12"
};
const DISCIPLINES = [
    [
        "hard enduro",
        "Hard Enduro"
    ],
    [
        "cross country",
        "Cross Country"
    ],
    [
        "mini velocidad",
        "MiniVelocidad"
    ],
    [
        "minivelocidad",
        "MiniVelocidad"
    ],
    [
        "mototurismo",
        "Mototurismo"
    ],
    [
        "motocross",
        "Motocross"
    ],
    [
        "superbike",
        "Superbike"
    ],
    [
        "supermoto",
        "Supermoto"
    ],
    [
        "velocidad",
        "Velocidad"
    ],
    [
        "enduro",
        "Enduro"
    ],
    [
        "trial",
        "Trial"
    ],
    [
        "rally",
        "Rally"
    ],
    [
        "moto4",
        "Moto4"
    ],
    [
        "moto5",
        "Moto5"
    ],
    [
        "mx",
        "Motocross"
    ]
];
function decodeHtmlEntities(value) {
    return value.replace(/&nbsp;/gi, " ").replace(/&amp;/gi, "&").replace(/&quot;/gi, '"').replace(/&#039;|&apos;/gi, "'").replace(/&ndash;|&mdash;/gi, "-").replace(/&[a-z]+;/gi, " ");
}
function cleanText(value) {
    return decodeHtmlEntities(value).replace(/<script[\s\S]*?<\/script>/gi, " ").replace(/<style[\s\S]*?<\/style>/gi, " ").replace(/<(br|\/p|\/div|\/li|\/tr|\/h[1-6])\b[^>]*>/gi, "\n").replace(/<\/t[dh]>/gi, " | ").replace(/<[^>]+>/g, " ").replace(/\s*\|\s*/g, " | ").replace(/[ \t]+/g, " ").replace(/\n\s+/g, "\n").replace(/\n{2,}/g, "\n").trim();
}
function normalizeForSearch(value) {
    return cleanText(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
}
function toIsoDate(year, month, day) {
    return `${year}-${month.padStart(2, "0")}-${day.padStart(2, "0")}`;
}
function parseSpanishDate(value) {
    const text = cleanText(value).toLowerCase();
    const numericDate = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b/);
    if (numericDate) {
        return toIsoDate(numericDate[3], numericDate[2], numericDate[1]);
    }
    const longDate = text.match(/\b(\d{1,2})(?:\s*(?:de)?\s+|\s*[-/]\s*)(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)(?:\s*(?:de)?\s+|\s+)(20\d{2})\b/);
    if (longDate) {
        return toIsoDate(longDate[3], MONTHS[longDate[2]], longDate[1]);
    }
    return null;
}
function parseSpanishDateRange(value) {
    const text = cleanText(value).toLowerCase();
    const numericRange = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\s*(?:-|al|a)\s*(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b/);
    if (numericRange) {
        return {
            start: toIsoDate(numericRange[3], numericRange[2], numericRange[1]),
            end: toIsoDate(numericRange[6], numericRange[5], numericRange[4]),
            rest: text.slice(numericRange.index + numericRange[0].length).trim()
        };
    }
    const sameMonthRange = text.match(/\b(\d{1,2})\s*(?:-|al|a|y)\s*(\d{1,2})\s*(?:de)?\s+(enero|febrero|marzo|abril|mayo|junio|julio|agosto|septiembre|setiembre|octubre|noviembre|diciembre)\s*(?:de)?\s+(20\d{2})\b/);
    if (sameMonthRange) {
        return {
            start: toIsoDate(sameMonthRange[4], MONTHS[sameMonthRange[3]], sameMonthRange[1]),
            end: toIsoDate(sameMonthRange[4], MONTHS[sameMonthRange[3]], sameMonthRange[2]),
            rest: text.slice(sameMonthRange.index + sameMonthRange[0].length).trim()
        };
    }
    const numericDate = text.match(/\b(\d{1,2})[/-](\d{1,2})[/-](20\d{2})\b/);
    if (numericDate) {
        const date = toIsoDate(numericDate[3], numericDate[2], numericDate[1]);
        return {
            start: date,
            end: date,
            rest: text.slice(numericDate.index + numericDate[0].length).trim()
        };
    }
    const start = parseSpanishDate(text);
    return start ? {
        start,
        end: start,
        rest: ""
    } : null;
}
function normalizeDisciplineFromText(value) {
    const text = normalizeForSearch(value);
    const match = DISCIPLINES.find(([needle])=>text.includes(needle));
    return match?.[1] || "Motociclismo";
}
function getCalendarLines(html) {
    const lines = cleanText(html).split("\n").map((line)=>line.trim()).filter(Boolean);
    const calendarStart = lines.findIndex((line)=>normalizeForSearch(line) === "calendario");
    if (calendarStart === -1) {
        return [];
    }
    const stopIndex = lines.findIndex((line, index)=>{
        if (index <= calendarStart) {
            return false;
        }
        const normalized = normalizeForSearch(line);
        return /^(archivos|documentos|resultados|clasificaciones|reglas|informacion)/.test(normalized);
    });
    return lines.slice(calendarStart + 1, stopIndex === -1 ? undefined : stopIndex);
}
function removeLeadingDiscipline(value, discipline) {
    const normalizedDiscipline = discipline.replace(/([.*+?^${}()|\[\]\\])/g, "\\$1");
    return value.replace(new RegExp(`^${normalizedDiscipline}\\b`, "i"), "").replace(/^\s*\([A-Z]{2,3}\)\s*/i, "").replace(/^\s*-\s*/, "").trim();
}
function normalizeTitle(value) {
    return value.replace(/\s+/g, " ").replace(/\s+-\s+/g, " - ").trim();
}
function extractVenue(value) {
    const text = normalizeTitle(value);
    const parts = text.split(" - ").map((part)=>part.trim()).filter(Boolean);
    if (parts.length > 1) {
        return parts.at(-1);
    }
    return text || undefined;
}
function parseCalendarLine(line, page) {
    const dates = parseSpanishDateRange(line);
    if (!dates || !dates.rest) {
        return null;
    }
    const inferredDiscipline = normalizeDisciplineFromText(`${page.discipline} ${dates.rest}`);
    const discipline = inferredDiscipline === "Motociclismo" ? page.discipline : inferredDiscipline;
    const eventText = normalizeTitle(removeLeadingDiscipline(dates.rest, discipline));
    if (!eventText || /^fecha\s+disciplina\s+prueba/i.test(eventText)) {
        return null;
    }
    const venue = extractVenue(eventText);
    const title = eventText.toLowerCase().includes(page.championship.toLowerCase()) ? eventText : `${page.championship} - ${eventText}`;
    return {
        title,
        championship: page.championship,
        discipline,
        start: dates.start,
        end: dates.end,
        venue,
        province: undefined,
        level: "Nacional",
        source: RFME_SOURCE,
        sourceId: RFME_SOURCE_ID,
        sourceUrl: page.url,
        ticketUrl: "",
        tags: [
            discipline,
            RFME_SOURCE
        ],
        featured: false
    };
}
function dedupeRawEvents(events) {
    const seen = new Set();
    const deduped = [];
    for (const event of events){
        const key = [
            event.title,
            event.start,
            event.venue || ""
        ].map((value)=>normalizeForSearch(value)).join("|");
        if (seen.has(key)) {
            continue;
        }
        seen.add(key);
        deduped.push(event);
    }
    return deduped;
}
async function fetchChampionshipPage(page) {
    const response = await fetch(page.url, {
        headers: {
            accept: "text/html",
            "user-agent": "EventoMotor sync bot (+https://eventomotor.local)"
        },
        next: {
            revalidate: 60 * 60
        }
    });
    if (!response.ok) {
        throw new Error(`${response.status} ${response.statusText}`);
    }
    return response.text();
}
function parseChampionshipPage(html, page) {
    const lines = getCalendarLines(html);
    const events = lines.map((line)=>parseCalendarLine(line, page)).filter((event)=>Boolean(event));
    if (!events.length) {
        console.warn(`RFME scraper warning: no parseable calendar events found at ${page.url}`);
    }
    return events;
}
async function scrapeRfmeEvents() {
    const events = [];
    for (const page of RFME_CHAMPIONSHIP_PAGES){
        try {
            const html = await fetchChampionshipPage(page);
            events.push(...parseChampionshipPage(html, page));
        } catch (error) {
            const message = error instanceof Error ? error.message : String(error);
            console.warn(`RFME scraper warning: ${page.url} skipped (${message})`);
        }
    }
    return dedupeRawEvents(events);
}
}),
"[project]/lib/sync/dedupe-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "dedupeEvents",
    ()=>dedupeEvents
]);
function dedupeKey(event) {
    return [
        event.title,
        event.start_date,
        event.venue || ""
    ].map((value)=>value.trim().toLowerCase()).join("|");
}
function dedupeEvents(events) {
    const seen = new Set();
    const deduped = [];
    for (const event of events){
        const key = dedupeKey(event);
        if (seen.has(key)) {
            continue;
        }
        seen.add(key);
        deduped.push(event);
    }
    return deduped;
}
}),
"[project]/lib/slug.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/sync/normalize-sync-event.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "normalizeSyncEvent",
    ()=>normalizeSyncEvent
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
function normalizeText(value) {
    return value.trim().replace(/\s+/g, " ");
}
function slugify(value) {
    return normalizeText(value).toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 80);
}
function buildEventId(event) {
    if (event.id) {
        return event.id;
    }
    const source = slugify(event.source || "external");
    const title = slugify(event.title);
    const start = slugify(event.start);
    const venue = slugify(event.venue || "venue-pending");
    return [
        source,
        title,
        start,
        venue
    ].filter(Boolean).join("-");
}
function normalizeSyncEvent(event) {
    const title = normalizeText(event.title);
    const discipline = event.discipline?.trim() || "Motociclismo";
    const venue = event.venue?.trim() || "Por confirmar";
    const tags = event.tags?.map((tag)=>tag.trim()).filter(Boolean);
    return {
        id: buildEventId({
            ...event,
            title,
            discipline,
            venue
        }),
        slug: (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(title, event.start),
        title,
        championship: event.championship?.trim() || discipline,
        discipline,
        start_date: event.start,
        end_date: event.end || event.start,
        venue,
        city: event.city?.trim() || null,
        province: event.province?.trim() || null,
        region: event.region?.trim() || event.province?.trim() || null,
        level: event.level?.trim() || "Publicado",
        source: event.source.trim(),
        source_id: event.sourceId?.trim() || null,
        source_url: event.sourceUrl?.trim() || "",
        ticket_url: event.ticketUrl?.trim() || "",
        tags: tags?.length ? tags : [
            discipline
        ],
        featured: Boolean(event.featured),
        visible: true,
        import_method: "scraper-rfme",
        data_quality: "draft",
        notes: null,
        updated_at: new Date().toISOString()
    };
}
}),
"[project]/lib/supabase.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-route] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-route] (ecmascript)");
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/lib/sync/upsert-events.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "upsertEvents",
    ()=>upsertEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-route] (ecmascript)");
;
async function upsertEvents(events) {
    if (!events.length) {
        return 0;
    }
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        throw new Error("Supabase is not configured. Set NEXT_PUBLIC_SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY.");
    }
    const { data, error } = await supabase.from("events").upsert(events, {
        onConflict: "id"
    }).select("id");
    if (error) {
        throw new Error(error.message);
    }
    return data?.length ?? 0;
}
}),
"[project]/app/api/sync-events/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$scrapers$2f$rfme$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/scrapers/rfme.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$dedupe$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/dedupe-events.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$normalize$2d$sync$2d$event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/normalize-sync-event.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$upsert$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sync/upsert-events.ts [app-route] (ecmascript)");
;
;
;
;
function jsonResponse(body, status = 200) {
    return Response.json(body, {
        status
    });
}
function validateCronSecret(request) {
    const cronSecret = process.env.CRON_SECRET;
    if (!cronSecret) {
        return {
            ok: false,
            status: 500,
            error: "CRON_SECRET is not configured. Add CRON_SECRET to your environment."
        };
    }
    const authorization = request.headers.get("authorization");
    if (authorization !== `Bearer ${cronSecret}`) {
        return {
            ok: false,
            status: 401,
            error: "Unauthorized. Send Authorization: Bearer CRON_SECRET."
        };
    }
    return {
        ok: true
    };
}
async function GET(request) {
    const auth = validateCronSecret(request);
    if (!auth.ok) {
        return jsonResponse({
            ok: false,
            sources: [],
            insertedOrUpdated: 0,
            errors: [
                auth.error
            ]
        }, auth.status);
    }
    const sources = [];
    const errors = [];
    let insertedOrUpdated = 0;
    try {
        sources.push("rfme");
        const rawEvents = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$scrapers$2f$rfme$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["scrapeRfmeEvents"])();
        const normalizedEvents = rawEvents.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$normalize$2d$sync$2d$event$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["normalizeSyncEvent"]);
        const dedupedEvents = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$dedupe$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["dedupeEvents"])(normalizedEvents);
        if (dedupedEvents.length) {
            insertedOrUpdated = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sync$2f$upsert$2d$events$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["upsertEvents"])(dedupedEvents);
        }
    } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        errors.push(message);
    }
    return jsonResponse({
        ok: errors.length === 0,
        sources,
        insertedOrUpdated,
        errors
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__12ky~9u._.js.map