module.exports = [
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[project]/app/favicon.ico (static in ecmascript, tag client)", ((__turbopack_context__) => {

__turbopack_context__.v("/_next/static/media/favicon.0x3dzn~oxb6tn.ico" + (globalThis["NEXT_CLIENT_ASSET_SUFFIX"] || ''));}),
"[project]/app/favicon.ico.mjs { IMAGE => \"[project]/app/favicon.ico (static in ecmascript, tag client)\" } [app-rsc] (structured image object, ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__ = __turbopack_context__.i("[project]/app/favicon.ico (static in ecmascript, tag client)");
;
const __TURBOPACK__default__export__ = {
    src: __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$favicon$2e$ico__$28$static__in__ecmascript$2c$__tag__client$29$__["default"],
    width: 256,
    height: 256
};
}),
"[project]/components/EventBadge.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventBadge
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
const BADGE_STYLES = {
    MotoGP: "border-red-500/25 bg-red-500/10 text-red-100",
    Superbike: "border-orange-400/25 bg-orange-400/10 text-orange-100",
    Velocidad: "border-amber-400/25 bg-amber-400/10 text-amber-100",
    Motocross: "border-lime-400/25 bg-lime-400/10 text-lime-100",
    Trial: "border-emerald-400/25 bg-emerald-400/10 text-emerald-100",
    Enduro: "border-green-400/25 bg-green-400/10 text-green-100",
    MiniVelocidad: "border-sky-400/25 bg-sky-400/10 text-sky-100",
    Mototurismo: "border-violet-400/25 bg-violet-400/10 text-violet-100",
    Motociclismo: "border-white/[0.08] bg-white/[0.035] text-zinc-200"
};
function EventBadge({ discipline }) {
    const color = BADGE_STYLES[discipline] || BADGE_STYLES.Motociclismo;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: `rounded-full border px-2 py-1 text-[11px] font-semibold ${color}`,
        children: discipline
    }, void 0, false, {
        fileName: "[project]/components/EventBadge.tsx",
        lineNumber: 17,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/brand/EventomotorLogo.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventomotorLogo
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function EventomotorLogo({ className = "", markClassName = "", compact = false, iconOnly = false }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `inline-flex items-center gap-3 ${className}`,
        "aria-label": "EventoMotor",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `relative grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-xl border border-white/[0.10] bg-[#15161A] shadow-[0_18px_45px_rgba(0,0,0,0.38)] ${markClassName}`,
                "aria-hidden": "true",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute inset-0 bg-[radial-gradient(circle_at_80%_18%,rgba(225,6,0,0.34),transparent_36%)]"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 20,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute -right-3 top-2 h-2 w-10 rotate-[-18deg] rounded-full bg-[#E10600]"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 21,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute left-2 top-3 h-1 w-7 rounded-full bg-white/85"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 22,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute left-3 top-[1.15rem] h-1 w-5 rounded-full bg-[#E10600]"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 23,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "absolute left-2 bottom-3 h-1 w-8 rounded-full bg-white/18"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 24,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "relative mt-1 flex items-baseline font-black leading-none tracking-[-0.16em]",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[1.5rem] text-white",
                                children: "E"
                            }, void 0, false, {
                                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                                lineNumber: 26,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: "text-[1.5rem] text-[#E10600]",
                                children: "M"
                            }, void 0, false, {
                                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                                lineNumber: 27,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 25,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                lineNumber: 16,
                columnNumber: 7
            }, this),
            compact || iconOnly ? null : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "flex items-baseline text-lg font-black uppercase tracking-[0.08em] text-white sm:text-xl",
                children: [
                    "EVENTO",
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "text-[#E10600]",
                        children: "MOTOR"
                    }, void 0, false, {
                        fileName: "[project]/components/brand/EventomotorLogo.tsx",
                        lineNumber: 33,
                        columnNumber: 17
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/brand/EventomotorLogo.tsx",
                lineNumber: 32,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/brand/EventomotorLogo.tsx",
        lineNumber: 15,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/ui/primitives.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Button",
    ()=>Button,
    "Card",
    ()=>Card,
    "Chip",
    ()=>Chip,
    "SearchInput",
    ()=>SearchInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
;
function cx(...classes) {
    return classes.filter(Boolean).join(" ");
}
function Button({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
        className: cx("inline-flex min-h-12 items-center justify-center rounded-md bg-[#E10600] px-6 py-3 text-sm font-black uppercase tracking-[0.16em] text-white shadow-[0_18px_38px_rgba(225,6,0,0.2)] transition hover:bg-[#ff1710] focus:outline-none focus:ring-2 focus:ring-[#E10600] focus:ring-offset-2 focus:ring-offset-[#0D0D0F] disabled:cursor-not-allowed disabled:opacity-55", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
function Card({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: cx("rounded-lg border border-white/10 bg-[#15161A] shadow-[0_26px_80px_rgba(0,0,0,0.36)]", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, this);
}
function Chip({ className, children, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
        className: cx("inline-flex items-center rounded-full border border-white/10 bg-white/[0.035] px-3.5 py-1.5 text-[0.68rem] font-bold uppercase tracking-[0.18em] text-[#A6A6A6]", className),
        ...props,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 54,
        columnNumber: 5
    }, this);
}
function SearchInput({ className, ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        className: cx("min-h-12 w-full rounded-md border border-white/10 bg-[#15161A] px-4 text-sm text-white outline-none transition placeholder:text-[#A6A6A6]/70 focus:border-[#E10600] focus:ring-2 focus:ring-[#E10600]/25", className),
        type: "search",
        ...props
    }, void 0, false, {
        fileName: "[project]/components/ui/primitives.tsx",
        lineNumber: 68,
        columnNumber: 5
    }, this);
}
}),
"[project]/components/UnderConstruction.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>UnderConstruction
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/brand/EventomotorLogo.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ui/primitives.tsx [app-rsc] (ecmascript)");
;
;
;
const STATUS_ITEMS = [
    "Diseño en progreso",
    "Carga de eventos en marcha",
    "Lanzamiento próximamente"
];
function UnderConstruction() {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen overflow-hidden bg-[#0D0D0F] text-white",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
            className: "relative isolate flex min-h-screen items-center px-4 py-10 sm:px-6 lg:px-8",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-20 bg-[#0D0D0F]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 14,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-10 bg-[radial-gradient(circle_at_24%_22%,rgba(225,6,0,0.18),transparent_28%),radial-gradient(circle_at_86%_62%,rgba(225,6,0,0.12),transparent_24%),linear-gradient(135deg,rgba(255,255,255,0.045),transparent_38%)]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 15,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute inset-0 -z-10 opacity-[0.045] bg-[linear-gradient(90deg,rgba(255,255,255,0.82)_1px,transparent_1px),linear-gradient(0deg,rgba(255,255,255,0.82)_1px,transparent_1px)] bg-[size:76px_76px]"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 16,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute left-[6%] top-[14%] -z-10 hidden h-px w-64 bg-gradient-to-r from-transparent via-[#E10600]/45 to-transparent lg:block"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 17,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute right-[8%] top-[22%] -z-10 hidden h-px w-48 bg-gradient-to-r from-transparent via-white/20 to-transparent lg:block"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 18,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "absolute bottom-0 left-0 -z-10 h-40 w-full bg-gradient-to-t from-black/45 to-transparent"
                }, void 0, false, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 19,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "relative mx-auto grid w-full max-w-6xl gap-12 lg:grid-cols-[1.05fr_0.95fr] lg:items-center",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "max-w-3xl",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$brand$2f$EventomotorLogo$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 23,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-12 flex flex-wrap gap-2.5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Chip"], {
                                            children: "Motor España"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 26,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Chip"], {
                                            className: "border-[#E10600]/25 bg-[#E10600]/[0.06] text-white",
                                            children: "Modo construcción"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 27,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 25,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                    className: "mt-7 max-w-4xl text-4xl font-black leading-[0.97] tracking-tight text-white sm:text-6xl lg:text-[4.7rem]",
                                    children: "EventoMotor está calentando motores"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 32,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-6 max-w-2xl text-lg leading-8 text-white/85 sm:text-xl",
                                    children: "Estamos preparando el calendario definitivo para descubrir eventos del motor en España."
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 35,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "mt-4 max-w-2xl text-base leading-7 text-[#A6A6A6]",
                                    children: "Trackdays, motocross, concentraciones, ferias, competiciones y mucho más. Muy pronto, todos los eventos en un solo sitio."
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 39,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "mt-9",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Button"], {
                                        type: "button",
                                        children: "Vuelve pronto"
                                    }, void 0, false, {
                                        fileName: "[project]/components/UnderConstruction.tsx",
                                        lineNumber: 44,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 43,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UnderConstruction.tsx",
                            lineNumber: 22,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ui$2f$primitives$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["Card"], {
                            className: "relative overflow-hidden p-6 sm:p-8",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-[#E10600]/70 to-transparent"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 49,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "absolute -right-16 -top-16 h-44 w-44 rounded-full bg-[#E10600]/10 blur-3xl"
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 50,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative flex items-center justify-between border-b border-white/10 pb-6",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-black uppercase tracking-[0.3em] text-[#A6A6A6]",
                                                    children: "Estado"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 53,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                                    className: "mt-2 text-3xl font-black tracking-tight text-white",
                                                    children: "En boxes"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 56,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 52,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "flex h-8 w-8 items-center justify-center rounded-full border border-[#E10600]/30 bg-[#E10600]/10",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: "h-2.5 w-2.5 rounded-full bg-[#E10600] shadow-[0_0_22px_rgba(225,6,0,0.75)]"
                                            }, void 0, false, {
                                                fileName: "[project]/components/UnderConstruction.tsx",
                                                lineNumber: 59,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 58,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 51,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-6 space-y-3",
                                    children: STATUS_ITEMS.map((item, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-center gap-4 rounded-md border border-white/[0.08] bg-[#0D0D0F]/70 px-4 py-4 transition hover:border-white/15",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                    className: "grid h-9 w-9 shrink-0 place-items-center rounded-md border border-[#E10600]/30 bg-[#E10600]/10 text-xs font-black text-[#E10600]",
                                                    children: [
                                                        "0",
                                                        index + 1
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 69,
                                                    columnNumber: 19
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "font-bold text-zinc-100",
                                                    children: item
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 72,
                                                    columnNumber: 19
                                                }, this)
                                            ]
                                        }, item, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 65,
                                            columnNumber: 17
                                        }, this))
                                }, void 0, false, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 63,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-8",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex items-end justify-between gap-4",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs font-black uppercase tracking-[0.24em] text-[#A6A6A6]",
                                                    children: "Preparación"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 79,
                                                    columnNumber: 17
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-sm font-black text-white",
                                                    children: "68%"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/UnderConstruction.tsx",
                                                    lineNumber: 82,
                                                    columnNumber: 17
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 78,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "mt-3 h-2 overflow-hidden rounded-full bg-white/10",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-full w-[68%] rounded-full bg-gradient-to-r from-[#E10600] to-[#ff3b34] shadow-[0_0_20px_rgba(225,6,0,0.42)]"
                                            }, void 0, false, {
                                                fileName: "[project]/components/UnderConstruction.tsx",
                                                lineNumber: 85,
                                                columnNumber: 17
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 84,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 77,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "relative mt-8 border-t border-white/10 pt-5",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "absolute right-0 top-5 h-px w-24 bg-gradient-to-r from-[#E10600]/70 to-transparent"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 90,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: "text-xs font-black uppercase tracking-[0.24em] text-[#A6A6A6]",
                                            children: "Próxima salida: muy pronto"
                                        }, void 0, false, {
                                            fileName: "[project]/components/UnderConstruction.tsx",
                                            lineNumber: 91,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/UnderConstruction.tsx",
                                    lineNumber: 89,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/UnderConstruction.tsx",
                            lineNumber: 48,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/UnderConstruction.tsx",
                    lineNumber: 21,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/components/UnderConstruction.tsx",
            lineNumber: 13,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/components/UnderConstruction.tsx",
        lineNumber: 12,
        columnNumber: 5
    }, this);
}
}),
"[project]/lib/slug.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createEventSlug",
    ()=>createEventSlug,
    "slugify",
    ()=>slugify
]);
const MAX_SLUG_LENGTH = 96;
function slugify(value) {
    return value.trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, MAX_SLUG_LENGTH).replace(/-+$/g, "");
}
function createEventSlug(title, start) {
    const titleSlug = slugify(title);
    const dateSlug = slugify(start);
    return [
        titleSlug,
        dateSlug
    ].filter(Boolean).join("-");
}
}),
"[project]/lib/event-listing-slugs.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DISCIPLINE_SLUGS",
    ()=>DISCIPLINE_SLUGS,
    "getDisciplineSlug",
    ()=>getDisciplineSlug,
    "getListingLinks",
    ()=>getListingLinks,
    "getRegionSlug",
    ()=>getRegionSlug,
    "resolveEventListing",
    ()=>resolveEventListing
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
const DISCIPLINE_SLUGS = {
    motogp: "MotoGP",
    motocross: "Motocross",
    trial: "Trial",
    enduro: "Enduro",
    superbike: "Superbike",
    velocidad: "Velocidad",
    minivelocidad: "MiniVelocidad",
    mototurismo: "Mototurismo"
};
const REGION_ALIASES = {
    andalucia: [
        "andalucia",
        "andalusia"
    ],
    catalunya: [
        "catalunya",
        "cataluna",
        "catalonia"
    ],
    aragon: [
        "aragon"
    ],
    navarra: [
        "navarra"
    ],
    valencia: [
        "valencia",
        "comunitat-valenciana",
        "comunidad-valenciana"
    ],
    murcia: [
        "murcia",
        "region-de-murcia"
    ]
};
function getDisciplineSlug(name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function getRegionSlug(name) {
    const slug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
    const alias = Object.entries(REGION_ALIASES).find(([, values])=>values.includes(slug));
    return alias?.[0] || slug;
}
function sameDiscipline(event, name) {
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(event.discipline) === (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(name);
}
function sameRegion(event, slug) {
    const candidates = [
        event.region,
        event.province
    ].map(getRegionSlug);
    const aliases = REGION_ALIASES[slug] || [
        slug
    ];
    return candidates.some((candidate)=>candidate === slug || aliases.includes(candidate));
}
function resolveEventListing(slug, events) {
    const normalizedSlug = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["slugify"])(slug);
    const disciplineName = DISCIPLINE_SLUGS[normalizedSlug];
    if (disciplineName) {
        const listingEvents = events.filter((event)=>sameDiscipline(event, disciplineName));
        return listingEvents.length ? {
            kind: "discipline",
            slug: normalizedSlug,
            name: disciplineName,
            events: listingEvents
        } : null;
    }
    const regionEvents = events.filter((event)=>sameRegion(event, normalizedSlug));
    if (!regionEvents.length) {
        return null;
    }
    return {
        kind: "region",
        slug: normalizedSlug,
        name: regionEvents[0].region,
        events: regionEvents
    };
}
function getListingLinks(events) {
    const disciplineLinks = Object.entries(DISCIPLINE_SLUGS).map(([slug, name])=>({
            kind: "discipline",
            slug,
            name,
            count: events.filter((event)=>sameDiscipline(event, name)).length
        })).filter((link)=>link.count > 0);
    const regionMap = new Map();
    for (const event of events){
        const slug = getRegionSlug(event.region);
        const current = regionMap.get(slug);
        if (current) {
            current.count += 1;
        } else {
            regionMap.set(slug, {
                kind: "region",
                slug,
                name: event.region,
                count: 1
            });
        }
    }
    return {
        disciplines: disciplineLinks,
        regions: [
            ...regionMap.values()
        ].sort((a, b)=>a.name.localeCompare(b.name))
    };
}
}),
"[project]/lib/supabase.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "createSupabaseServerClient",
    ()=>createSupabaseServerClient,
    "isSupabaseConfigured",
    ()=>isSupabaseConfigured,
    "mapEventRowToEventItem",
    ()=>mapEventRowToEventItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/@supabase/supabase-js/dist/index.mjs [app-rsc] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
;
function isSupabaseConfigured() {
    return Boolean(("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co") && process.env.SUPABASE_SERVICE_ROLE_KEY);
}
function createSupabaseServerClient() {
    const url = ("TURBOPACK compile-time value", "https://lovhbsxihpggrwnunjcz.supabase.co");
    const serviceRoleKey = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !serviceRoleKey) {
        return null;
    }
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$supabase$2f$supabase$2d$js$2f$dist$2f$index$2e$mjs__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__$3c$locals$3e$__["createClient"])(url, serviceRoleKey, {
        auth: {
            persistSession: false,
            autoRefreshToken: false
        }
    });
}
function mapEventRowToEventItem(row) {
    return {
        id: row.id,
        slug: row.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEventSlug"])(row.title, row.start_date),
        title: row.title,
        championship: row.championship || row.discipline || "Motociclismo",
        discipline: row.discipline || "Motociclismo",
        start: row.start_date,
        end: row.end_date || row.start_date,
        venue: row.venue || "Por confirmar",
        city: row.city || "Por confirmar",
        province: row.province || "Por confirmar",
        region: row.region || row.province || "Por confirmar",
        level: row.level || "Publicado",
        source: row.source || "Supabase",
        sourceUrl: row.source_url || "",
        ticketUrl: row.ticket_url || "",
        tags: row.tags?.length ? row.tags : [
            row.discipline || "Motociclismo"
        ],
        featured: Boolean(row.featured),
        visible: row.visible !== false,
        importMethod: row.import_method || "",
        dataQuality: row.data_quality === "draft" || row.data_quality === "reviewed" || row.data_quality === "published" || row.data_quality === "cancelled" || row.data_quality === "pending_date" ? row.data_quality : "reviewed",
        notes: row.notes || ""
    };
}
}),
"[project]/lib/sources.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "SOURCES",
    ()=>SOURCES,
    "SOURCE_FEEDS",
    ()=>SOURCE_FEEDS
]);
const SOURCES = {
    RFME: "https://rfme.com/calendario-campeonatos/",
    MotoGP: "https://www.motogp.com/es/calendar/2026",
    CircuitCat: "https://www.circuitcat.com/",
    MotorLand: "https://www.motorlandaragon.com/",
    RicardoTormo: "https://entradas.circuitvalencia.com/circuitvalencia/events"
};
const SOURCE_FEEDS = [
    {
        id: "rfme",
        name: "RFME",
        url: SOURCES.RFME,
        type: "Calendario oficial"
    },
    {
        id: "motogp",
        name: "MotoGP",
        url: SOURCES.MotoGP,
        type: "Calendario oficial"
    },
    {
        id: "circuitcat",
        name: "Circuit de Barcelona-Catalunya",
        url: SOURCES.CircuitCat,
        type: "Circuito"
    },
    {
        id: "motorland",
        name: "MotorLand Aragón",
        url: SOURCES.MotorLand,
        type: "Circuito"
    },
    {
        id: "ricardotormo",
        name: "Circuit Ricardo Tormo",
        url: SOURCES.RicardoTormo,
        type: "Entradas"
    }
];
}),
"[project]/lib/fallback-events.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "FALLBACK_EVENTS",
    ()=>FALLBACK_EVENTS
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/sources.ts [app-rsc] (ecmascript)");
;
const FALLBACK_EVENTS = [
    {
        id: "motogp-jerez-2026",
        title: "Gran Premio de España de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-04-24",
        end: "2026-04-26",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Mundial",
        source: "MotoGP",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotoGP,
        ticketUrl: "https://www.circuitodejerez.com/",
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-catalunya-2026",
        title: "Gran Premi de Catalunya de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-05-15",
        end: "2026-05-17",
        venue: "Circuit de Barcelona-Catalunya",
        city: "Montmeló",
        province: "Barcelona",
        region: "Catalunya",
        level: "Mundial",
        source: "Circuit de Barcelona-Catalunya",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].CircuitCat,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-aragon-2026",
        title: "Gran Premio de Aragón de MotoGP",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-08-28",
        end: "2026-08-30",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Mundial",
        source: "MotorLand Aragón",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MotoGP",
            "velocidad"
        ],
        featured: true
    },
    {
        id: "motogp-valencia-2026",
        title: "Gran Premio Motul de la Comunitat Valenciana",
        championship: "MotoGP World Championship",
        discipline: "MotoGP",
        start: "2026-11-27",
        end: "2026-11-29",
        venue: "Circuit Ricardo Tormo",
        city: "Cheste",
        province: "Valencia",
        region: "Comunitat Valenciana",
        level: "Mundial",
        source: "Circuit Ricardo Tormo",
        sourceUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].RicardoTormo,
        tags: [
            "MotoGP",
            "final"
        ],
        featured: true
    },
    {
        id: "esbk-navarra-2026",
        title: "ESBK Navarra",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-05-07",
        end: "2026-05-10",
        venue: "Circuito de Navarra",
        city: "Los Arcos",
        province: "Navarra",
        region: "Navarra",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: "https://www.circuitodenavarra.com/",
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: true
    },
    {
        id: "esbk-motorland-2026",
        title: "ESBK MotorLand Aragón",
        championship: "Campeonato de España de Superbike",
        discipline: "Superbike",
        start: "2026-07-16",
        end: "2026-07-19",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-superbike/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "ESBK",
            "superbike"
        ],
        featured: false
    },
    {
        id: "copa-velocidad-jerez-2026",
        title: "Copa de España de Velocidad - Jerez",
        championship: "Copa de España de Velocidad",
        discipline: "Velocidad",
        start: "2026-05-29",
        end: "2026-05-31",
        venue: "Circuito de Jerez - Ángel Nieto",
        city: "Jerez de la Frontera",
        province: "Cádiz",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-velocidad/",
        ticketUrl: "",
        tags: [
            "velocidad"
        ],
        featured: false
    },
    {
        id: "mx-osuna-2026",
        title: "Campeonato de España de Motocross - Osuna",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-05-02",
        end: "2026-05-03",
        venue: "Circuito de Osuna",
        city: "Osuna",
        province: "Sevilla",
        region: "Andalucía",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: "",
        tags: [
            "MX",
            "offroad"
        ],
        featured: true
    },
    {
        id: "mx-motorland-2026",
        title: "Campeonato de España de Motocross - MotorLand",
        championship: "Campeonato de España de Motocross",
        discipline: "Motocross",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "MotorLand Aragón",
        city: "Alcañiz",
        province: "Teruel",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-motocross/",
        ticketUrl: __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$sources$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["SOURCES"].MotorLand,
        tags: [
            "MX",
            "offroad"
        ],
        featured: false
    },
    {
        id: "trial-gironella-2026",
        title: "Campeonato de España de Trial - Gironella",
        championship: "Campeonato de España de Trial",
        discipline: "Trial",
        start: "2026-05-30",
        end: "2026-05-31",
        venue: "Gironella",
        city: "Gironella",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-trial/",
        ticketUrl: "",
        tags: [
            "trial"
        ],
        featured: false
    },
    {
        id: "enduro-orista-2026",
        title: "Campeonato de España de Enduro - Oristà",
        championship: "Campeonato de España de Enduro",
        discipline: "Enduro",
        start: "2026-09-19",
        end: "2026-09-20",
        venue: "Torre d'Oristà",
        city: "Oristà",
        province: "Barcelona",
        region: "Catalunya",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/campeonato-de-espana-de-enduro/",
        ticketUrl: "",
        tags: [
            "enduro"
        ],
        featured: false
    },
    {
        id: "mini-cartagena-2026",
        title: "Copa de España de MiniVelocidad - Cartagena",
        championship: "Copa de España de MiniVelocidad",
        discipline: "MiniVelocidad",
        start: "2026-05-01",
        end: "2026-05-03",
        venue: "Circuito de Cartagena",
        city: "Cartagena",
        province: "Murcia",
        region: "Región de Murcia",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-minivelocidad/",
        ticketUrl: "https://www.circuitocartagena.com/",
        tags: [
            "minivelocidad"
        ],
        featured: false
    },
    {
        id: "tour-penitentes-2026",
        title: "RFME Mototurismo Touring - Penitentes",
        championship: "RFME Mototurismo Touring Challenge",
        discipline: "Mototurismo",
        start: "2026-05-01",
        end: "2026-05-01",
        venue: "Penitentes",
        city: "Pirineo aragonés",
        province: "Huesca",
        region: "Aragón",
        level: "Nacional",
        source: "RFME",
        sourceUrl: "https://rfme.com/campeonatos/copa-de-espana-de-mototurismo/",
        ticketUrl: "",
        tags: [
            "mototurismo"
        ],
        featured: false
    }
];
}),
"[project]/lib/public-events.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getVisibleEvents",
    ()=>getVisibleEvents
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/supabase.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/fallback-events.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/slug.ts [app-rsc] (ecmascript)");
;
;
;
function fallbackVisibleEvents() {
    return __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$fallback$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["FALLBACK_EVENTS"].filter((event)=>event.visible !== false).map((event)=>({
            ...event,
            slug: event.slug || (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$slug$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createEventSlug"])(event.title, event.start)
        }));
}
async function getVisibleEvents() {
    const supabase = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["createSupabaseServerClient"])();
    if (!supabase) {
        return fallbackVisibleEvents();
    }
    const { data, error } = await supabase.from("events").select("*").eq("visible", true).order("start_date", {
        ascending: true
    });
    if (error || !data) {
        return fallbackVisibleEvents();
    }
    const events = data.map(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$supabase$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["mapEventRowToEventItem"]);
    return events.length ? events : fallbackVisibleEvents();
}
}),
"[project]/lib/site-url.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "getSiteUrl",
    ()=>getSiteUrl
]);
function getSiteUrl() {
    const configuredUrl = ("TURBOPACK compile-time value", "https://www.eventomotor.com");
    const vercelUrl = process.env.VERCEL_URL;
    if ("TURBOPACK compile-time truthy", 1) {
        return configuredUrl.replace(/\/$/, "");
    }
    //TURBOPACK unreachable
    ;
}
}),
"[project]/lib/under-construction.ts [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "isUnderConstruction",
    ()=>isUnderConstruction
]);
function isUnderConstruction() {
    return ("TURBOPACK compile-time value", "true") === "true";
}
}),
"[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>EventosMotoPage,
    "generateMetadata",
    ()=>generateMetadata
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/rsc/react-jsx-dev-runtime.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.react-server.js [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/EventBadge.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$UnderConstruction$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/UnderConstruction.tsx [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/event-listing-slugs.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/public-events.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/site-url.ts [app-rsc] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$under$2d$construction$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/under-construction.ts [app-rsc] (ecmascript)");
;
;
;
;
;
;
;
;
async function generateMetadata() {
    const url = `${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSiteUrl"])()}/eventos-moto`;
    const description = "Calendario de eventos de motociclismo en Espana por disciplina y region: MotoGP, motocross, trial, enduro, superbike y mas.";
    return {
        title: "Eventos de moto en Espana | EventoMotor",
        description,
        alternates: {
            canonical: url
        },
        openGraph: {
            title: "Eventos de moto en Espana | EventoMotor",
            description,
            url,
            siteName: "EventoMotor",
            type: "website"
        }
    };
}
async function EventosMotoPage() {
    if ((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$under$2d$construction$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["isUnderConstruction"])()) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$UnderConstruction$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
            fileName: "[project]/app/eventos-moto/page.tsx",
            lineNumber: 33,
            columnNumber: 12
        }, this);
    }
    const events = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$public$2d$events$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getVisibleEvents"])();
    const links = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$event$2d$listing$2d$slugs$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getListingLinks"])(events);
    const siteUrl = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$site$2d$url$2e$ts__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["getSiteUrl"])();
    const itemList = {
        "@context": "https://schema.org",
        "@type": "ItemList",
        name: "Eventos de moto en Espana",
        itemListElement: events.map((event, index)=>({
                "@type": "ListItem",
                position: index + 1,
                name: event.title,
                url: `${siteUrl}/evento/${event.slug}`
            }))
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("main", {
        className: "min-h-screen bg-zinc-950 px-4 py-8 text-white sm:px-6 lg:px-8",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("script", {
                type: "application/ld+json",
                dangerouslySetInnerHTML: {
                    __html: JSON.stringify(itemList)
                }
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 53,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mx-auto max-w-6xl",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        className: "text-sm font-bold text-orange-200 hover:text-orange-100",
                        href: "/",
                        children: "Volver al calendario"
                    }, void 0, false, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("header", {
                        className: "mt-8 border-b border-white/10 pb-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-bold uppercase tracking-widest text-orange-200",
                                children: "EventoMotor"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 63,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                className: "mt-3 text-4xl font-black leading-tight sm:text-6xl",
                                children: "Eventos de moto en Espana"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 66,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-4 max-w-3xl text-lg leading-8 text-zinc-300",
                                children: "Listados SEO de eventos visibles por disciplina y region, con fichas indexables para cada prueba."
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 69,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 62,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-8 grid gap-4 md:grid-cols-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ListingGroup, {
                                title: "Por disciplina",
                                items: links.disciplines
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 76,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(ListingGroup, {
                                title: "Por region",
                                items: links.regions
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 77,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 75,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
                        className: "mt-10",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-2xl font-black",
                                children: "Ultimos eventos visibles"
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 81,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "mt-4 grid gap-3 md:grid-cols-2",
                                children: events.slice(0, 12).map((event)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                        className: "rounded-2xl border border-white/10 bg-white/5 p-4 hover:bg-white/10",
                                        href: `/evento/${event.slug}`,
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "mb-2",
                                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$EventBadge$2e$tsx__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                                                    discipline: event.discipline
                                                }, void 0, false, {
                                                    fileName: "[project]/app/eventos-moto/page.tsx",
                                                    lineNumber: 90,
                                                    columnNumber: 19
                                                }, this)
                                            }, void 0, false, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 89,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                className: "font-black text-white",
                                                children: event.title
                                            }, void 0, false, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 92,
                                                columnNumber: 17
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "mt-1 text-sm text-zinc-400",
                                                children: [
                                                    event.start,
                                                    " - ",
                                                    event.city,
                                                    ", ",
                                                    event.province
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/eventos-moto/page.tsx",
                                                lineNumber: 93,
                                                columnNumber: 17
                                            }, this)
                                        ]
                                    }, event.id, true, {
                                        fileName: "[project]/app/eventos-moto/page.tsx",
                                        lineNumber: 84,
                                        columnNumber: 15
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/eventos-moto/page.tsx",
                                lineNumber: 82,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 80,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 57,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/eventos-moto/page.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
function ListingGroup({ title, items }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("section", {
        className: "rounded-2xl border border-white/10 bg-white/5 p-5",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-black",
                children: title
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 114,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 flex flex-wrap gap-2",
                children: items.map((item)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$rsc$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$react$2d$server$2e$js__$5b$app$2d$rsc$5d$__$28$ecmascript$29$__["default"], {
                        className: "rounded-full border border-white/10 bg-black/20 px-3 py-2 text-sm font-bold text-zinc-200 hover:bg-white/10",
                        href: `/eventos-moto/${item.slug}`,
                        children: [
                            item.name,
                            " (",
                            item.count,
                            ")"
                        ]
                    }, item.slug, true, {
                        fileName: "[project]/app/eventos-moto/page.tsx",
                        lineNumber: 117,
                        columnNumber: 11
                    }, this))
            }, void 0, false, {
                fileName: "[project]/app/eventos-moto/page.tsx",
                lineNumber: 115,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/eventos-moto/page.tsx",
        lineNumber: 113,
        columnNumber: 5
    }, this);
}
}),
"[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript, Next.js Server Component)", ((__turbopack_context__) => {

__turbopack_context__.n(__turbopack_context__.i("[project]/app/eventos-moto/page.tsx [app-rsc] (ecmascript)"));
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__0ya4_og._.js.map